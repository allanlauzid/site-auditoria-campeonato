# INTELIGÊNCIA ESTRATÉGICA — BENCHMARK INTERNACIONAL DE CAMPEONATOS ESPORTIVOS
### Consolidação de 3 pesquisas (CrossFit, HYROX, Spartan, Ironman, Maratonas, Powerlifting, Weightlifting, IKO World League, Kettlebell Sport)
### Documento base oficial para o projeto do Campeonato Brasileiro de Kettlebell Sport

---

## NOTA METODOLÓGICA — LEITURA CRÍTICA DAS TRÊS PESQUISAS

Antes de qualquer recomendação, é preciso deixar claro o que é **fato observado no benchmark** e o que é **inferência estratégica** (interpretação, extrapolação ou opinião de consultoria construída a partir dos fatos, mas não comprovada diretamente por eles). As três pesquisas em si já fazem essa mistura — muitas de suas conclusões vêm marcadas como "inferência estratégica" pelo próprio Perplexity — e este relatório preserva essa distinção, tornando-a explícita em cada seção.

**Convergências entre as três pesquisas**
As três pesquisas concordam em um núcleo duro: os campeonatos mais fortes vendem *pertencimento, identidade e progressão*, não apenas uma vaga; usam *escassez organizada* (waitlist, ballot, early bird) como mecanismo de desejo; e dependem de *prova social via atletas* para aquecer a comunidade antes da inscrição. A Pesquisa 1 traz os fatos primários (cases reais, com links). A Pesquisa 2 reprocessa esses fatos em princípios e already assume a lente do Kettlebell Sport brasileiro. A Pesquisa 3 é puramente inferencial — não traz fatos novos do benchmark internacional, e sim uma tese sobre a vantagem de um evento menor. Isso é relevante: a Pesquisa 3 deve ser lida como *hipótese estratégica de consultoria*, não como benchmark comprovado.

**Divergências e tensões**
Há uma tensão real entre a Pesquisa 1/2 (que valorizam escala, produção de mídia, live announcements, ecossistema de marca) e a Pesquisa 3 (que argumenta que a escala é uma limitação, não um ativo, e que eventos menores têm vantagem estrutural em intimidade). Nenhuma das duas está "errada" — mas aplicá-las ao mesmo tempo sem critério gera contradição: não dá para tentar imitar o "evento dentro do evento" do CrossFit (que exige audiência global e aparato de mídia) e ao mesmo tempo se posicionar como "clube de elite íntimo". É preciso escolher em qual eixo o Kettlebell Sport brasileiro compete.

**Lacunas do benchmark**
As pesquisas são fortes em *aquisição pré-inscrição* (como conseguir leads e conversões) e fracas em: retenção pós-evento, monetização recorrente, parcerias/patrocínio, política de preço, estrutura de premiação, e o que acontece quando a escassez é falsa ou mal calibrada (risco reputacional). Também há pouquíssimo dado sobre CAC, taxas de conversão reais, ou benchmarks financeiros — tudo é qualitativo/criativo, não há nenhum número de performance de campanha nas três pesquisas.

**Viés a declarar**
As fontes são majoritariamente posts de Instagram/Facebook e páginas de registro — ou seja, o benchmark captura *comunicação de superfície* (o que a marca posta), não a estratégia completa por trás (briefings internos, testes A/B, funis pagos, CRM). Boa parte do que a Pesquisa 2 e 3 chamam de "princípio" é, na prática, uma leitura interpretativa de poucos posts — robusta como direção, frágil como prova estatística. Este relatório assume isso e trata os "princípios" como hipóteses de alta plausibilidade, não leis comprovadas.

---

## 1. RESUMO EXECUTIVO

O benchmark confirma um padrão consistente entre os maiores campeonatos do mundo: a inscrição nunca é vendida como ato transacional isolado. Ela é embalada como entrada em uma *jornada* — de status (CrossFit), de progressão (weightlifting, kettlebell), de identidade pessoal (Spartan), de conquista corporal (Ironman/maratonas) ou de acessibilidade performática (HYROX). O mecanismo comum é: captura de interesse antecipada → nutrição com prova social → abertura com gatilho de escassez/urgência → contato contínuo.

Para o Kettlebell Sport no Brasil, a oportunidade real não está em replicar o aparato de mídia de CrossFit ou HYROX (que exige escala inexistente hoje), mas em explorar a vantagem estrutural identificada na Pesquisa 3: um evento menor pode operar com intimidade, memória relacional e ritual pessoal — dimensões que nenhum dos grandes players consegue entregar na mesma intensidade. A tese central deste relatório é: **o Kettlebell Sport brasileiro não deve competir em escala, deve competir em profundidade de pertencimento.**

Isso muda o critério de decisão para todas as escolhas de marketing daqui para frente: qualquer tática do benchmark que dependa de volume/produção massiva deve ser adaptada ou descartada; qualquer tática que dependa de proximidade, narrativa pessoal e progressão visível deve ser priorizada e ampliada.

---

## 2. PRINCÍPIOS QUE APARECEM REPETIDAMENTE

*(Fato: observado de forma recorrente nas três pesquisas)*

1. Escassez organizada e transparente (waitlist, ballot, early bird, "limited spots").
2. Prova social protagonizada por atletas (não pela organização).
3. Narrativa de jornada/progressão em vez de evento pontual.
4. Captura de lead antes da abertura oficial de inscrições.
5. Contato recorrente (nutrição) entre o cadastro de interesse e a abertura.
6. Linguagem de status e avanço ("prove it", "qualify", "leaderboard", "ranked").
7. Transformar a abertura de inscrição em um marco/evento próprio (live announcement, ballot day, countdown).
8. Redução de fricção com microcompromissos (lead magnet, sorteio, cadastro simples).

## 3. PRINCÍPIOS QUE FUNCIONAM INDEPENDENTEMENTE DA MODALIDADE

*(Fato + inferência: aparecem em modalidades muito diferentes entre si, o que sugere robustez)*

- Lista de interesse/waitlist antes da venda.
- Atleta como protagonista da comunicação (não a marca).
- Promessa de progressão/status como gatilho psicológico central.
- Contato contínuo até a conversão.
- Deadline claro e comunicado (mesmo em nichos pequenos como powerlifting local).

Esses princípios não dependem de orçamento de mídia, tamanho de audiência ou tradição histórica — são replicáveis em qualquer escala, inclusive na estreia de um evento novo.

## 4. PRINCÍPIOS QUE DEPENDEM DO CONTEXTO

*(Inferência estratégica: exigem pré-condições que o Kettlebell Sport brasileiro ainda não tem)*

- **Live announcement de mídia (CrossFit):** exige base global, aparato de produção e um calendário competitivo já consolidado. Sem isso, tende a parecer artificial/forçado.
- **Ballot/lottery de maratonas:** só funciona quando há demanda real superando a capacidade — escassez fingida é perceptível e corrosiva.
- **Tom "for every body" da HYROX:** exige infraestrutura padronizada e replicável em várias praças; sem isso, a promessa de acessibilidade soa vazia.
- **Narrativa de superação extrema da Spartan ("embrace the hard way"):** funciona porque é a identidade histórica da marca; importada sem lastro, soa caricata.
- **Autoridade esportiva formal do weightlifting (critérios de elegibilidade, timeline oficial):** exige uma estrutura federativa madura para não parecer burocracia vazia.

## 5. ERROS MAIS COMUNS

*(Inferência estratégica derivada da comparação entre cases fortes e fracos no benchmark)*

1. Comunicar inscrição como ato isolado, sem camada simbólica de identidade.
2. Escassez sem mecanismo transparente — gera desconfiança em vez de desejo.
3. Depender só de demanda já existente (fala só com quem já ia se inscrever).
4. Terminar a comunicação no pagamento, sem nutrir a comunidade depois.
5. Linguagem intimidadora para iniciantes, elitizando o acesso.
6. Falta de tradução técnica (a modalidade fica "fechada" para quem não entende).
7. Ausência de ritual — o evento vira só uma data no calendário, não um marco pessoal.

## 6. O QUE DEFINITIVAMENTE NÃO DEVEMOS COPIAR

*(Inferência estratégica — aplicação direta ao caso do Kettlebell Sport no Brasil)*

- **Aparato de live announcement em escala CrossFit** — sem audiência e verba compatível, o formato quebra a promessa e expõe a diferença de porte.
- **Sistema de ballot/lottery de maratona** — simular fila artificial num esporte de nicho é facilmente percebido como encenação, e destrói credibilidade.
- **Tom de urgência agressiva de powerlifting genérico** ("last call", "registration ends tomorrow" sem storytelling) — funciona só quando o público já está maduro; aplicado cedo demais, parece spam.
- **Padronização rígida estilo HYROX** — replicar controle de operação idêntico em todas as praças, sem adaptar à cultura local, anula justamente a vantagem competitiva de proximidade.
- **Linguagem seletiva de weightlifting olímpico** (regras/elegibilidade em primeiro plano) — pode afastar o público que ainda está descobrindo o esporte.

## 7. OPORTUNIDADES AINDA NÃO EXPLORADAS

*(Inferência estratégica, com maior peso vindo da Pesquisa 3)*

1. Um campeonato que seja, ao mesmo tempo, competição + encontro anual + identidade cultural — nenhum case do benchmark faz isso de forma plena.
2. Sistema de "camadas de pertencimento" (atleta, coach, box, cidade, federação) desenhado deliberadamente, não apenas comunidade genérica.
3. Sistema de reputação anual do atleta — memória de evolução, não só ranking pontual.
4. Ritual completo do campeonato (inscrição, weigh-in, desfile, honrarias, retorno anual) como marca própria, não emprestado de outro esporte.
5. Conteúdo de bastidor técnico-educativo para leigos (nenhum case do benchmark investe fortemente nisso).
6. Trilha de onboarding estruturada para iniciantes com marcos intermediários.
7. Tratar o campeonato como "casa" (identidade, retorno, memória) em vez de "evento" (data, ingresso).

## 8. VANTAGENS DE UM CAMPEONATO BRASILEIRO POR SER MENOR

*(Fato interpretativo da Pesquisa 3 + inferência)*

- Reconhecimento pessoal real de atletas, técnicos, boxes e cidades — impossível em escala CrossFit/HYROX/Ironman.
- Velocidade para testar formatos, ritos e premiações sem o peso de uma marca global padronizada.
- Proximidade cultural e linguística — símbolos, humor e referências locais que uma marca internacional só acessa de forma superficial.
- Capacidade de personalizar a jornada do atleta (cronograma, reconhecimento, contato) em vez de tratá-lo como número de inscrição.
- Menor risco reputacional ao inovar — um evento pequeno pode errar e ajustar rápido; um evento global carrega expectativa de consistência.

## 9. VANTAGENS ESPECÍFICAS DO KETTLEBELL SPORT

*(Combinação de fato — a IKO World League usa ranking/temporada/times — com inferência)*

- Modalidade já naturalmente estruturada em lógica de temporada, pontos e ranking (herdada do modelo IKO), o que facilita criar "calendário afetivo" contínuo.
- Alto conteúdo técnico e visualmente distintivo — a excelência é claramente visível (técnica, forma, disciplina), o que favorece storytelling de progressão e prestígio.
- Comunidade ainda pequena e não fragmentada por múltiplas federações concorrentes fortes no Brasil, o que permite construir identidade única sem disputar narrativa com um concorrente já consolidado.
- Esporte pouco compreendido pelo público geral — isso é risco (barreira de entrada), mas também oportunidade: quem entende primeiro se torna "early adopter" com forte senso de pertencimento e status de descoberta.
- Formato compatível tanto com competição presencial quanto online (como visto no case "Kettlebell in the Air"), ampliando o alcance sem depender só de logística de arena.

## 10. RISCOS

*(Inferência estratégica)*

1. **Risco de soar elitista** se a linguagem técnica não for traduzida para iniciantes.
2. **Risco de soar genérico** se a comunidade não vir camadas reais de pertencimento e ficar "mais um evento de nicho".
3. **Risco de escassez artificial** — anunciar "vagas limitadas" sem lastro real em um esporte pequeno é facilmente desmascarado e custa credibilidade.
4. **Risco de imitação desproporcional** — copiar formatos de mídia de marcas muito maiores (live announcement, ballot) sem capacidade de sustentá-los.
5. **Risco de dependência de eventos únicos** — se a comunicação para só na inscrição, o campeonato não constrói comunidade, só transação.
6. **Risco de fadiga de mensagem** — repetir "inscreva-se" sem variar a camada narrativa cansa uma base pequena mais rápido do que uma base global.
7. **Risco financeiro/operacional não coberto pelo benchmark** — nenhuma das pesquisas trata custo de aquisição, ticket médio ou sustentabilidade financeira; decisões de marketing não podem ignorar essa lacuna quando o projeto avançar para execução.

---

## 11. MATRIZ — COPIAR / ADAPTAR / EVITAR / OPORTUNIDADE

| Elemento do benchmark | Classificação | Justificativa breve |
|---|---|---|
| Lista de interesse/waitlist antes da abertura | **Deve copiar** | Funciona em qualquer escala, baixo custo, alto retorno |
| Atleta como protagonista da comunicação | **Deve copiar** | Universal, gratuito, gera prova social autêntica |
| Contato recorrente (nutrição) até a abertura | **Deve copiar** | Reduz atrito, mantém intenção viva |
| Linguagem de status/progressão (ranking, pontos) | **Deve copiar** | Já é nativa do Kettlebell Sport via modelo IKO |
| Deadline claro e comunicado | **Deve copiar** | Simples, eficaz, sem exigir grande estrutura |
| Sistema de temporada/pontos/circuito | **Deve adaptar** | Adaptar escala e frequência à realidade nacional |
| Escassez organizada (waitlist real) | **Deve adaptar** | Só usar se houver demanda genuína — não simular |
| Onboarding para iniciantes | **Deve adaptar** | Benchmark pouco explora isso — construir do zero, inspirado em tom HYROX |
| Comunidade por cidade/box/coach | **Deve adaptar** | Inspirado em Spartan/CrossFit, mas com formato próprio e mais íntimo |
| Live announcement estilo CrossFit | **Deve evitar** (por ora) | Exige escala e produção incompatíveis com o estágio atual |
| Ballot/lottery estilo maratona | **Deve evitar** | Risco alto de parecer encenação em esporte de nicho |
| Padronização rígida estilo HYROX | **Deve evitar** | Anula a vantagem competitiva de proximidade local |
| Linguagem regulatória/seletiva de weightlifting | **Deve evitar** | Pode intimidar público iniciante, que é maioria do mercado potencial |
| Campeonato como "casa"/identidade cultural anual | **Excelente oportunidade** | Nenhum benchmark faz isso plenamente; alto potencial diferencial |
| Sistema de reputação/memória anual do atleta | **Excelente oportunidade** | Não existe de forma robusta em nenhum case pesquisado |
| Ritual completo e autoral do evento | **Excelente oportunidade** | Cria propriedade intelectual de marca difícil de copiar |
| Reconhecimento pessoal/individualizado do atleta | **Excelente oportunidade** | Vantagem estrutural exclusiva de eventos menores |

---

## 12. MATRIZ — IMPACTO (ALTO / MÉDIO / BAIXO)

| Iniciativa | Impacto | Observação |
|---|---|---|
| Lista de interesse pré-abertura | **Alto** | Base de todo o funil; sem ela, tudo o mais perde eficácia |
| Atleta como protagonista/storytelling pessoal | **Alto** | Gera prova social gratuita e alta identificação |
| Sistema de ranking/temporada contínua | **Alto** | Já nativo do esporte; mantém engajamento entre eventos |
| Camadas de pertencimento (atleta/coach/box/cidade) | **Alto** | Base da vantagem competitiva de evento menor |
| Ritual próprio do campeonato | **Alto** | Diferenciação de marca de longo prazo, difícil de copiar |
| Onboarding estruturado para iniciantes | **Médio-Alto** | Amplia mercado, mas exige investimento de conteúdo |
| Contato recorrente/nutrição por e-mail ou WhatsApp | **Médio** | Importante, mas operacional — exige disciplina, não é diferencial em si |
| Countdown/contagem regressiva com marcos | **Médio** | Reforça urgência, mas efeito limitado sem narrativa por trás |
| Deadline claro de inscrição | **Médio** | Necessário, mas commodity — todo evento faz isso |
| Escassez organizada (se aplicável) | **Médio** | Alto potencial, mas depende de demanda real para funcionar |
| Reconhecimento individualizado (cronograma pessoal, menções) | **Médio** | Forte para retenção, mas de impacto mais silencioso na aquisição |
| Lead magnet estilo Ironman (sorteio, brinde) | **Baixo-Médio** | Bom para captar e-mail, mas pouco alinhado à identidade técnica do esporte |
| Formato de vídeo/live announcement de mídia | **Baixo** (no estágio atual) | Impacto potencial alto no futuro, mas hoje sem escala para sustentar |
| Linguagem regulatória/formal de elegibilidade | **Baixo** | Relevante só para o público já competidor avançado |

---

## 13. INSIGHTS ESTRATÉGICOS (50+)

1. Inscrição não é o produto — pertencimento é o produto; inscrição é só o ticket de entrada.
2. O funil vencedor do benchmark é sempre: capturar → nutrir → provar socialmente → converter com urgência.
3. Escassez só funciona quando é verdadeira; escassez encenada é o erro mais caro do mercado.
4. Live announcement é conteúdo, não só operação — vira ritual de mídia próprio.
5. HYROX venceu ao dizer "para todo mundo" sem perder ar de performance — equilíbrio raro.
6. Spartan transforma inscrito em personagem: "Why I Race" é storytelling, não propaganda.
7. Ironman reduz risco de decisão com microcompromisso (sorteio) antes da venda.
8. Maratonas ensinam que transparência do processo de seleção é tão importante quanto a escassez em si.
9. Powerlifting mostra que urgência crua funciona — mas só em público já maduro e pequeno.
10. Weightlifting usa autoridade esportiva (regras, timeline) como gatilho de prestígio.
11. IKO World League já entrega, nativamente, a lógica de temporada que outros esportes precisam construir do zero.
12. Nenhum dos benchmarks resolve bem retenção pós-evento — é um vácuo competitivo.
13. Nenhum benchmark cria "memória emocional" de longo prazo do atleta — outro vácuo.
14. O maior ativo de um evento pequeno é o nome próprio do atleta sendo dito, lembrado e celebrado.
15. Ranking e progressão substituem, psicologicamente, o desejo de "vencer" pelo desejo de "evoluir" — isso retém mais gente.
16. Comunidade genérica cansa rápido; comunidade em camadas (atleta/coach/box/cidade) sustenta engajamento.
17. Onboarding de iniciante é o maior espaço vazio do mercado pesquisado — quase ninguém investe nisso de forma sistemática.
18. Tornar a inscrição um "marco" (e não um formulário) aumenta desejo mesmo sem aparato de mídia caro.
19. Countdown funciona melhor quando tem marco real por trás (não é só "faltam X dias").
20. O tom "acessível mas com cara de performance" da HYROX é replicável em qualquer escala.
21. Autoimagem ("sou alguém que enfrenta o difícil") é gatilho mais forte que desconto ou preço.
22. Todo benchmark forte usa o atleta como mídia — a marca só amplifica.
23. Waitlist bem comunicada transforma frustração de fila em desejo de pertencer.
24. Nenhuma das marcas pesquisadas comunica bem "o que muda na vida do atleta depois do evento" — oportunidade de storytelling pós-evento.
25. Kettlebell Sport tem vantagem visual (técnica, forma, disciplina) pouco explorada em conteúdo educativo.
26. O público leigo brasileiro provavelmente não entende as regras do kettlebell sport — isso é barreira e oportunidade de conteúdo simultaneamente.
27. Um evento pequeno pode prometer (e cumprir) reconhecimento individual que eventos grandes não conseguem.
28. "Casa" é um conceito semântico mais forte que "evento" para reter comunidade ano após ano.
29. Ritual de abertura (weigh-in, desfile, cerimônia) cria propriedade de marca difícil de copiar.
30. Sistema de honrarias/reconhecimento contínuo mantém o atleta emocionalmente ligado fora de temporada de prova.
31. A vantagem de ser pequeno é velocidade — pode-se testar formatos que grandes marcas não arriscam.
32. Consistência de marca é prioridade para gigantes; personalização radical é prioridade possível para pequenos.
33. Nenhum benchmark documenta CAC ou ROI — decisões de mídia paga precisarão ser testadas, não copiadas.
34. A comunicação "every level belongs" (CrossFit Open) é um modelo replicável de ampliação de base sem perder prestígio.
35. Grandes marcas dependem de histórico e tradição para sustentar hype; eventos novos precisam substituir tradição por intimidade.
36. Newsletter pós-registro (HYROX) é tática barata e replicável desde o dia 1 do projeto.
37. QR code e confirmação instantânea reduzem ansiedade do inscrito — baixo custo, alto ganho de confiança.
38. O "primeiro passo rumo ao campeonato" (linguagem CrossFit) pode ser adaptado como narrativa de qualificação/ranking no kettlebell.
39. Early bird funciona melhor como recompensa de compromisso do que como desconto puro.
40. Comunidade que se vê representada (cidade, box, técnico) tem retenção maior que comunidade anônima.
41. Um sistema de "reputação anual" pode ser o ativo de dados mais valioso do projeto a médio prazo.
42. Bastidores técnicos (como treinar, como julgar, como pontuar) educam e ao mesmo tempo geram desejo de pertencer.
43. Excesso de linguagem regulatória (regras, elegibilidade) afasta o público que ainda está descobrindo o esporte.
44. Kettlebell Sport pode se posicionar como "esporte oficial em ascensão no Brasil" — gatilho de prestígio + novidade.
45. Formato online (como "Kettlebell in the Air") amplia alcance geográfico sem depender de logística de arena.
46. Escassez em nicho pequeno deve ser comunicada com transparência radical, ou o público desconfia imediatamente.
47. O maior erro estratégico possível é tratar a inscrição como fim da jornada de comunicação, não como início.
48. Reconhecimento público (mencionar nomes, histórias, conquistas) é a tática de retenção mais barata e mais subutilizada do mercado.
49. Times/equipes (como na IKO) criam pressão social positiva que aumenta taxa de conversão e permanência.
50. Um campeonato pequeno que documenta e celebra a evolução de cada atleta ano após ano constrói um ativo que nenhuma marca grande consegue replicar rapidamente.
51. A jornada do atleta deve ter marcos visíveis mesmo fora de temporada de prova, para sustentar o "calendário afetivo".
52. Conteúdo estruturado por nível de experiência (iniciante, intermediário, avançado) evita que a comunicação seja genérica demais para uns e intimidadora demais para outros.

---

## 14. SÍNTESE FINAL — 20 PRINCÍPIOS MESTRES

Estes 20 princípios são a base oficial do restante do projeto. Combinam os fatos mais robustos do benchmark com as inferências estratégicas de maior consistência entre as três pesquisas.

1. A inscrição vende pertencimento e progressão — nunca é só uma vaga.
2. Construir lista de interesse antes de abrir inscrições é inegociável, em qualquer escala.
3. O atleta é o protagonista da comunicação; a organização é a coadjuvante que amplifica.
4. Escassez só é usada quando é real e sempre com processo transparente.
5. A jornada de comunicação não termina na inscrição — continua na experiência, no evento e depois dele.
6. Progressão, ranking e status são a linguagem central, aproveitando o que o Kettlebell Sport já herda do modelo IKO.
7. O Kettlebell Sport brasileiro compete em profundidade de pertencimento, não em escala de produção.
8. Formatos que exigem grande audiência ou aparato de mídia (live announcement, ballot) são adiados até haver base compatível.
9. Camadas de pertencimento — atleta, coach, box, cidade — são desenhadas deliberadamente, não deixadas ao acaso.
10. O campeonato deve ser tratado como "casa": identidade, retorno, memória — não apenas um evento com data.
11. Todo iniciante precisa de uma trilha de entrada clara; a modalidade não pode intimidar quem ainda está descobrindo.
12. Excelência técnica deve ser traduzida em linguagem acessível, sem perder prestígio.
13. Reconhecimento individual (nomes, histórias, trajetórias) é o principal ativo competitivo de um evento menor.
14. Um sistema de reputação e memória anual do atleta é construído desde a primeira edição, como ativo de longo prazo.
15. Rituais próprios do campeonato (abertura, weigh-in, honrarias) são criados como propriedade de marca, não emprestados de outro esporte.
16. A comunidade precisa de motivos para voltar sem comprar outra vaga imediatamente: ranking, títulos, memória, times.
17. Nenhuma tática é copiada sem antes verificar se a pré-condição estrutural existe (audiência, verba, tradição, demanda real).
18. Contato recorrente e nutrição contínua substituem grandes campanhas pontuais como motor principal de conversão.
19. O calendário do campeonato é tratado como calendário afetivo, com marcos entre uma edição e outra, não apenas na semana do evento.
20. Toda decisão de marketing é avaliada por um critério simples: isso aumenta a intimidade e o pertencimento, ou apenas imita escala que não temos?

---

*Documento de inteligência estratégica — base oficial para as próximas etapas do projeto. Nenhuma campanha, slogan, cronograma ou conteúdo foi criado nesta fase, conforme escopo definido.*
