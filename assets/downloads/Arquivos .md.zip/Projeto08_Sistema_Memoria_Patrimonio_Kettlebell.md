# PROJETO 08 — SISTEMA DE MEMÓRIA E PATRIMÔNIO HISTÓRICO
### Campeonato Brasileiro de Kettlebell Sport
### Constituição Permanente da Memória Institucional

*Fases 1-6 e Projetos 01-07 são Constituição definitiva e têm prioridade absoluta. Este documento não cria banco de dados, software, museu virtual ou acervo físico — cria os princípios permanentes que qualquer sistema futuro de memória deverá obedecer, capazes de sobreviver à troca de pessoas, tecnologias, sedes e gerações.*

---

## 1. FILOSOFIA DA MEMÓRIA

**Por que guardar:** porque a memória não é um subproduto do campeonato — é a própria essência da marca, definida desde a Fase 3: "a força que se sustenta é a força que se lembra." Sem sistema de memória real, essa frase é apenas retórica bonita.

**O valor institucional da memória:** um campeonato que dura vinte, cinquenta ou cem anos não se define pelo tamanho de uma edição isolada, mas pela continuidade documentada entre todas elas. A memória é o que transforma uma sucessão de eventos em uma instituição.

**O que significa preservar:** guardar é reconhecer; registrar é respeitar; documentar é agradecer. Cada decisão de preservação é, também, uma decisão de quem merece ser lembrado — e por isso nunca é neutra ou puramente técnica.

**O que nunca pode ser perdido:** o nome de qualquer pessoa que competiu, arbitrou, treinou ou trabalhou voluntariamente por uma edição do campeonato; o registro honesto de resultados e recordes; os marcos fundacionais da instituição (primeira edição, primeiros nomes, primeiras decisões constitucionais — incluindo os próprios documentos de Fases e Projetos que constituem esta Constituição).

**Critério permanente de decisão:** todo registro é avaliado pela pergunta "isso ajudará alguém a compreender a história deste esporte daqui a cinquenta anos?" — se a resposta for sim, merece preservação, independentemente de seu valor imediato.

---

## 2. ARQUITETURA DA MEMÓRIA

**Categorias centrais:** Pessoas (atletas, treinadores, árbitros, voluntários, dirigentes, patrocinadores) · Eventos (edições, competições, marcos institucionais) · Resultados e Recordes · Objetos (medalhas, troféus, equipamentos, materiais simbólicos) · Documentos (regulamentos, atas, contratos, os próprios documentos constitucionais) · Materiais Audiovisuais (fotografia, vídeo, áudio) · Narrativas Orais (entrevistas, depoimentos).

**Hierarquia organizacional:** a **pessoa** é a unidade central de organização de todo o sistema — nenhum registro de evento, resultado, objeto ou documento existe de forma desconectada de pelo menos um nome próprio associado a ele. Esta é a tradução arquitetural direta do valor "nome importa" (Fase 3) para a lógica de organização do próprio acervo.

**Relacionamentos:** o sistema opera como uma rede de relações (um atleta se relaciona a edições, resultados, box, treinador, fotografias, entrevistas), nunca como categorias isoladas em silo — a força do arquivo está exatamente na possibilidade de reconstruir a trajetória completa de qualquer nome através de suas conexões.

**Princípio geral:** nenhum item do acervo existe "solto" — todo registro carrega, no mínimo, um nome, uma data e um contexto mínimo de significado.

---

## 3. O QUE DEVE SER PRESERVADO

- **Pessoas:** atletas (todos os níveis, não apenas pódio), árbitros, voluntários, treinadores, dirigentes, patrocinadores e parceiros formalmente vinculados.
- **Competições e resultados:** toda edição, toda categoria, todo resultado oficial registrado.
- **Recordes:** registro técnico formal de marcas relevantes ao longo do tempo.
- **Boxes e federações:** vínculo institucional e territorial de cada comunidade participante.
- **Fotografias, vídeos e áudios:** conforme critérios dos Capítulos 8 e 9.
- **Entrevistas:** conforme Capítulo 7.
- **Documentos institucionais:** regulamentos (inclusive versões substituídas), atas, relatórios, correspondências, contratos históricos, e os próprios documentos constitucionais deste projeto (Fases 1-6, Projetos 01-08) — que são, eles mesmos, patrimônio histórico da instituição desde o primeiro dia.
- **Materiais gráficos, uniformes, medalhas, troféus e equipamentos históricos:** objetos físicos com valor documental e simbólico.
- **Correspondências e relatos:** comunicações relevantes à compreensão de decisões e momentos institucionais.
- **Bastidores:** material documental de produção (Projeto 02), quando carregar valor histórico além do uso imediato de comunicação.

---

## 4. O QUE NUNCA DEVE SER PRESERVADO

**Critérios de exclusão:** dados pessoais sensíveis sem relevância histórica e sem consentimento explícito (documentos pessoais, informações de saúde, endereço); materiais temporários ou rascunhos de trabalho sem valor documental além de sua função operacional imediata; duplicações exatas de um mesmo item (mantém-se a versão de melhor qualidade e proveniência, descartando-se cópias redundantes); conteúdo puramente promocional sem relevância histórica (ex: artes de campanhas comerciais rotineiras, salvo quando marcam um marco relevante da própria história da marca).

**Regra de prudência:** em caso de dúvida sobre relevância histórica, o material é preservado em nível básico (com metadados mínimos) até revisão formal de curadoria (Capítulo 5) — nunca descartado apressadamente.

---

## 5. SISTEMA DE CURADORIA

**Quem decide:** um curador formalmente designado, função permanente vinculada à Governança de Marca, responsável por aplicar os critérios deste documento — nunca uma decisão informal e dispersa entre múltiplas pessoas sem critério comum.

**Critérios de avaliação:**
- **Importância histórica:** o quanto o item ajuda a compreender um momento ou trajetória relevante da instituição.
- **Relevância:** conexão direta com pessoas, eventos ou decisões documentadas.
- **Representatividade:** o acervo deve refletir a diversidade real da comunidade (diferentes regiões, níveis competitivos, gêneros, gerações) — não apenas os nomes mais visíveis ou os campeões.
- **Autenticidade:** preferência por fontes primárias (registro direto do momento) sobre fontes secundárias (reconstrução posterior), sem descartar as segundas quando as primeiras não existirem.

---

## 6. SISTEMA DE REGISTRO

Todo registro segue uma estrutura mínima obrigatória: **nome(s) associado(s), data, edição/contexto, categoria (Capítulo 2), fonte de origem, e uma descrição mínima de significado** — nunca apenas um dado solto sem narrativa de contexto.

- **Registro de atletas:** vinculado ao Sistema de Atletas já operacional desde a Fase 5, com histórico completo de participações.
- **Registro de competições:** cada edição é uma unidade histórica própria, com contexto, resultados e marcos registrados de forma unificada.
- **Registro de recordes:** validado formalmente pelo comitê técnico (Fase 5) antes de entrar no patrimônio oficial.
- **Registro de histórias:** narrativas curadas (Capítulo 7) vinculadas às pessoas e eventos que as originaram.
- **Registro de mudanças institucionais:** toda alteração relevante de governança, marca ou estrutura (changelog já previsto desde o Projeto 04) é, ela mesma, um item do patrimônio histórico.

---

## 7. SISTEMA DE HISTÓRIA ORAL

**Entrevistas e depoimentos:** captados formalmente com consentimento explícito (Capítulo 16), priorizando pioneiros, veteranos e figuras fundacionais da modalidade no Brasil.

**Memórias e narrativas:** tratadas como fonte primária de altíssimo valor — muitas vezes o único registro existente de momentos anteriores à formalização plena do Sistema de Memória.

**Famílias:** memórias familiares de atletas e pioneiros são bem-vindas como material complementar, sempre identificadas como tal (fonte de segunda mão, não substituindo registro direto quando disponível).

**Protocolo mínimo:** toda entrevista de história oral é registrada em áudio ou vídeo, transcrita, e armazenada com metadados completos (Capítulo 11) — nunca apenas anotada informalmente.

---

## 8. SISTEMA FOTOGRÁFICO HISTÓRICO

**Critérios de seleção:** toda fotografia preservada como patrimônio histórico deve conter, sempre que possível, identificação de pessoa(s), data e contexto — fotografias esteticamente boas, mas sem identificação recuperável, têm valor histórico reduzido e são tratadas como material complementar, não como registro central.

**Contexto obrigatório:** nenhuma fotografia entra no acervo permanente sem legenda mínima de identificação.

**Metadados:** data, local, edição, pessoas identificadas, fotógrafo/fonte (Capítulo 11).

**Autenticidade:** o arquivo preserva sempre a versão original não tratada, além de eventuais versões editadas usadas comercialmente (Projeto 02/04) — a versão de arquivo nunca é substituída pela versão de uso comercial.

---

## 9. SISTEMA AUDIOVISUAL

**Vídeos e áudios:** toda edição do campeonato deve gerar captação histórica obrigatória dos momentos rituais centrais (Chamada do Nome, Última Respiração, Cerimônia de Reconhecimento, Fase 3/Projeto 07), preservada em formato-master, independentemente do uso editado para comunicação.

**Transmissões:** gravação integral preservada como registro histórico, mesmo quando apenas trechos são utilizados editorialmente.

**Documentários e captação histórica:** peças de maior duração (Projeto 02) são preservadas em sua versão completa, não apenas no corte final publicado.

**Preservação:** segue os parâmetros técnicos já definidos no Brand Book (Projeto 04, Capítulo 8) para formatos de arquivo master.

---

## 10. SISTEMA DOCUMENTAL

**Regulamentos:** toda versão de regulamento — inclusive versões substituídas e obsoletas — é preservada, permitindo reconstruir a evolução das regras ao longo do tempo.

**Ofícios, atas e relatórios:** preservados integralmente como registro de decisão institucional.

**Correspondências e contratos históricos:** preservados com atenção especial a confidencialidade comercial quando aplicável (Capítulo 13).

**Projetos e documentos constitucionais:** as Fases 1 a 6 e os Projetos 01 a 08 (incluindo este documento) são, eles próprios, patrimônio documental fundacional da instituição — preservados integralmente, com todas as versões e revisões, desde a origem do projeto.

---

## 11. SISTEMA DE METADADOS

**Princípios gerais:** todo item do acervo carrega, no mínimo: identificador único permanente (nunca reaproveitado, mesmo se um item for removido), nome(s) relacionado(s), data, categoria (Capítulo 2), fonte de origem, e nível de confiabilidade da informação (fonte primária, secundária, ou depoimento não verificado).

**Relacionamentos:** metadados estruturados como grafo de relações — pessoa-evento-objeto-documento — nunca como campos isolados sem conexão entre si.

**Contexto:** nenhum dado é preservado sem uma descrição mínima de significado (Capítulo 6).

**Classificação:** organizada pelas categorias do Capítulo 2, com subcategorias específicas desenvolvidas conforme necessidade futura (Capítulo 20).

**Versionamento:** nenhum metadado é sobrescrito sem preservar a versão anterior — correções geram nova versão registrada (Capítulo 16, retificação).

---

## 12. SISTEMA DE PRESERVAÇÃO

**Longevidade:** priorização de formatos abertos e não-proprietários para arquivamento de longo prazo, reduzindo dependência de softwares ou empresas específicas que podem deixar de existir.

**Migração tecnológica:** revisão formal e periódica (nunca esperar até um formato se tornar obsoleto ou inacessível) para migrar o acervo para tecnologias atualizadas, preservando sempre os metadados originais.

**Redundância:** múltiplas cópias do acervo, armazenadas em locais fisicamente e tecnologicamente distintos — nenhuma cópia única, por mais bem guardada, é considerada segura o suficiente.

**Autenticidade:** registro formal de proveniência (cadeia de custódia) de cada item relevante, permitindo verificar a origem e a integridade histórica do material.

**Integridade:** verificação técnica periódica (checksums ou métodos equivalentes) para garantir que arquivos digitais não foram corrompidos ao longo do tempo.

**Continuidade institucional:** o sistema nunca depende de uma única pessoa, empresa, plataforma tecnológica ou fornecedor externo — a arquitetura de preservação é desenhada para sobreviver à falência, saída ou substituição de qualquer parceiro tecnológico individual.

---

## 13. SISTEMA DE ACESSO

**Quem pode acessar:** o núcleo público do patrimônio (Livro de Nomes, resultados oficiais, marcos históricos) é de consulta pública e gratuita, coerente com a promessa central da marca desde a Fase 3.

**Quem pode editar:** exclusivamente o curador formal (Capítulo 5) e sua equipe designada, seguindo os critérios de registro (Capítulo 6) — nunca edição aberta e descontrolada por qualquer pessoa.

**Quem pode excluir:** ninguém possui poder unilateral de exclusão do acervo. Remoções (raríssimas) exigem processo formal aprovado pela Governança da Memória (Capítulo 19), reservado a casos excepcionais (ex: erro grave de identificação, violação de direito de imagem legítima).

**Quem nunca pode excluir:** nenhuma pessoa isoladamente — nem mesmo o Diretor Executivo — tem autoridade para apagar registro histórico por conveniência, constrangimento ou pressão externa.

**Níveis de acesso:** consulta pública (acervo central) · acesso ampliado para pesquisa acadêmica e jornalística mediante processo simples de credenciamento · acesso administrativo restrito à equipe de curadoria para material sensível ou não processado.

---

## 14. SISTEMA DE PATRIMÔNIO

- **Livro de Nomes:** núcleo central de todo o patrimônio, já definido desde a Fase 3 e operacionalizado na Fase 5 — registro permanente e público de todo atleta que já competiu.
- **Hall da Fama:** reconhecimento formal de trajetórias excepcionais de longo prazo, com critério técnico objetivo definido pela curadoria (Capítulo 5), nunca por popularidade momentânea ou critério comercial.
- **Recordes:** registro técnico oficial e público, validado pelo comitê técnico.
- **Grandes Momentos:** curadoria narrativa de marcos emocionalmente e historicamente significativos, além do simples dado técnico.
- **Grandes Competições:** cada edição preservada como unidade histórica completa e consultável.
- **Guardiões Fundadores:** patrocinadores e parceiros pioneiros, já formalizados no Projeto 05, registrados aqui como parte permanente do patrimônio institucional.
- **Marcos históricos:** primeira edição, primeiro recorde, primeiras decisões constitucionais, e demais eventos fundacionais da instituição.
- **Objetos simbólicos:** o Peso Testemunha e demais elementos rituais físicos definidos na Fase 3, preservados fisicamente com o mesmo rigor dado ao acervo documental.

---

## 15. SISTEMA DE CONTINUIDADE

**Troca de gestão:** a curadoria é função institucional documentada, nunca conhecimento tácito de uma única pessoa — qualquer novo curador deve conseguir assumir a função a partir da documentação existente, sem depender de transmissão oral informal.

**Troca de tecnologia:** conforme Capítulo 12.

**Troca de sede:** o acervo físico é mantido com redundância geográfica — nunca concentrado em um único local sem cópia de segurança em outro.

**Troca de equipe:** todo processo relevante de curadoria e registro é documentado, permitindo continuidade mesmo com rotatividade total da equipe operacional.

**Décadas futuras:** este documento passa por revisão formal periódica de adequação tecnológica e prática (Capítulo 19), mas seus princípios centrais (Capítulos 1, 2, 13 e 14) permanecem protegidos e não sujeitos a reinterpretação por conveniência de qualquer geração futura de gestores.

---

## 16. SISTEMA ÉTICO

**Direito de imagem:** consentimento formal e documentado é exigido para qualquer uso de imagem além do registro histórico básico de resultado esportivo (que é, por natureza, informação pública de competição).

**Consentimento:** obtido de forma explícita e renovável — uma pessoa pode, a qualquer momento, solicitar revisão do uso comercial (não histórico) de sua imagem.

**Uso de entrevistas:** consentimento específico para história oral (Capítulo 7), com direito do entrevistado de revisar o conteúdo antes da publicação, quando solicitado.

**Proteção de menores:** regras rígidas e reforçadas — nenhuma informação sensível de atleta menor de idade é preservada ou publicada sem consentimento parental explícito, com tratamento diferenciado de imagem e dados pessoais.

**Uso responsável da memória:** o acervo nunca é usado para constranger, expor negativamente ou prejudicar qualquer pessoa registrada nele — a memória institucional existe para reconhecer, não para julgar.

**Retificação:** processo formal disponível para corrigir erro factual comprovado, preservando o registro do processo de correção em si (nunca um apagamento silencioso do erro original, quando isso for relevante à integridade histórica do próprio arquivo).

---

## 17. SISTEMA DE AVALIAÇÃO

- **Completude:** percentual de edições, atletas e marcos com registro completo conforme os critérios mínimos do Capítulo 6.
- **Confiabilidade:** proporção de itens com fonte primária identificada versus fonte secundária ou não verificada.
- **Autenticidade:** integridade da cadeia de proveniência (Capítulo 12) do acervo.
- **Integridade técnica:** resultado das verificações periódicas de integridade digital (Capítulo 12).
- **Utilização:** volume de consultas públicas e de pesquisa ao acervo — indicador direto de valor real percebido pela comunidade.
- **Valor histórico:** avaliação qualitativa periódica pela curadoria sobre a robustez e representatividade do acervo como um todo.

---

## 18. SISTEMA DE CONSISTÊNCIA

**O problema a resolver:** garantir que curadores e equipes diferentes, ao longo de décadas, registrem a história com o mesmo padrão de qualidade e critério.

**Padronização:** todo registro segue a estrutura mínima obrigatória do Capítulo 6, aplicada uniformemente independentemente de quem o produz.

**Validação:** registros de marcos históricos relevantes (Hall da Fama, recordes, grandes momentos) passam por validação cruzada de mais de um responsável antes de entrarem formalmente no patrimônio oficial (Capítulo 14).

**Controle de qualidade:** auditoria periódica formal (Capítulo 19) revisa amostras do acervo contra os critérios deste documento, identificando lacunas ou inconsistências de registro ao longo do tempo.

---

## 19. GOVERNANÇA DA MEMÓRIA

**Quem protege:** o curador formal (Capítulo 5), como função permanente vinculada à Governança de Marca — a mesma estrutura de proteção institucional já aplicada a todos os sistemas anteriores deste projeto.

**Quem aprova:** decisões de patrimônio maior (inclusão no Hall da Fama, reconhecimento de marco histórico oficial) exigem aprovação conjunta da curadoria e da Governança de Marca.

**Quem altera:** os princípios centrais deste documento só podem ser alterados pela Governança de Marca; a aplicação prática do dia a dia é responsabilidade da curadoria, dentro dos limites aqui definidos.

**Quem pode descartar:** ninguém isoladamente — qualquer descarte segue o processo formal e excepcional do Capítulo 13, nunca decisão unilateral por conveniência operacional ou financeira.

**Quem audita:** auditoria periódica independente (nunca conduzida apenas pela própria curadoria) revisa a aplicação deste sistema conforme o Capítulo 18.

**Versionamento e registro de mudanças:** este documento segue a mesma lógica de versionamento formal já padronizada desde o Projeto 04 — nenhuma revisão sobrescreve a anterior sem preservação de histórico completo.

---

## 20. ROADMAP DE DESDOBRAMENTO — DOCUMENTOS FUTUROS

1. **Manual do Sistema de Memória** — detalhamento técnico-operacional completo deste documento constitucional.
2. **Manual do Livro de Nomes** — especificação prática do núcleo central do patrimônio (Capítulo 14).
3. **Manual de Curadoria** — critérios aplicados e exemplos práticos de decisão (Capítulo 5).
4. **Manual de História Oral** — protocolo prático de entrevistas (Capítulo 7).
5. **Manual do Acervo Fotográfico** — especificação técnica de seleção e arquivamento (Capítulo 8).
6. **Manual do Acervo Audiovisual** — especificação técnica de captação e preservação (Capítulo 9).
7. **Manual de Metadados** — esquema técnico completo de campos e relações (Capítulo 11).
8. **Manual de Digitalização** — processo técnico de conversão de material físico para digital.
9. **Manual de Preservação Digital** — especificação técnica de formatos, redundância e migração (Capítulo 12).
10. **Manual do Centro de Documentação** — organização física do acervo documental (Capítulo 10).
11. **Manual do Museu Virtual** — futura interface pública de exploração do patrimônio (não obrigatória nos primeiros anos).
12. **Manual do Hall da Fama** — critérios técnicos detalhados de reconhecimento (Capítulo 14).
13. **Manual do Arquivo Institucional** — gestão de documentos administrativos (Capítulo 10).
14. **Manual de Pesquisa Histórica** — protocolo de acesso para pesquisadores externos (Capítulo 13).
15. **Manual de Gestão do Acervo** — operação cotidiana da curadoria (Capítulo 5).
16. **Manual de Conservação Física** — cuidado de objetos simbólicos e materiais físicos (Capítulo 14).

**Prioridade de desenvolvimento:** **primeira prioridade** — Manual do Sistema de Memória e Manual do Livro de Nomes, por serem a espinha dorsal já prometida desde a Fase 3 e formalmente exigida como pré-requisito crítico desde o Master Plan (Fase 6, P16); **segunda prioridade** — Manual de Curadoria e Manual de Metadados, necessários para padronizar qualquer prática de registro desde a primeira edição; **terceira prioridade** — Manual de Preservação Digital e Manual de Digitalização, antes que o volume do acervo cresça a ponto de tornar a migração tecnológica mais custosa; **prioridades subsequentes** — demais manuais, conforme o acervo físico e a maturidade institucional crescerem organicamente.

---

## AUDITORIA FINAL — CONSELHO DE ONZE ESPECIALISTAS (CICLO ITERATIVO)

### Rodada 1 — críticas técnicas

**Arquivologia:** "A estrutura de metadados (Capítulo 11) e o princípio de que nenhum item existe desconectado de um nome (Capítulo 2) são tecnicamente sólidos e coerentes com boas práticas arquivísticas internacionais. Nenhuma inconsistência estrutural."

**Museologia:** "O Sistema de Patrimônio (Capítulo 14) trata bem a diferença entre registro histórico bruto e curadoria narrativa (Grandes Momentos). Ponto de atenção: falta menção a como o patrimônio físico (objetos, medalhas, uniformes) deve ser fisicamente exibido ou tornado acessível ao público, mesmo que isso seja detalhado em manual futuro."

**História do Esporte:** "A decisão de preservar todas as versões de regulamento, não apenas a vigente (Capítulo 10), é excelente prática — permite reconstruir a evolução real do esporte, algo que a maioria das federações esportivas brasileiras não faz."

**Patrimônio Cultural:** "O tratamento de objetos simbólicos (Peso Testemunha, Capítulo 14) como patrimônio com 'mesmo rigor' do acervo documental é correto, mas caberia reforçar, no Sistema de Preservação (Capítulo 12), que objetos físicos exigem protocolo de conservação distinto de arquivos digitais — hoje o capítulo trata majoritariamente de preservação digital."

**Ciência da Informação:** "O princípio de identificador único permanente, nunca reaproveitado (Capítulo 11), é fundamental e está corretamente estabelecido. Recomendo apenas que fique explícito que isso vale mesmo para itens posteriormente removidos por retificação (Capítulo 16) — o identificador nunca reaparece associado a outro item."

**Biblioteconomia:** "A classificação por categorias (Capítulo 2) está bem fundamentada. Sugiro que o Manual de Metadados (Capítulo 20) inclua, desde já, uma nota de compatibilidade com padrões internacionais de metadados (ex: Dublin Core ou equivalente), para facilitar futura interoperabilidade com outros acervos esportivos ou culturais."

**História Oral:** "O protocolo de consentimento e revisão pelo entrevistado (Capítulo 7/16) está correto. Recomendo reforçar que entrevistas de história oral devem ser majoritariamente conduzidas por pessoa treinada especificamente nessa metodologia, não por qualquer membro da equipe de comunicação — a qualidade do registro depende disso."

**Preservação Digital:** "O Sistema de Preservação (Capítulo 12) corretamente evita dependência de fornecedor único, mas não define uma frequência mínima de verificação de integridade (checksums) — 'periódica' é vago demais para um compromisso de décadas."

**Branding Institucional:** "A auto-referência do próprio conjunto de documentos constitucionais (Fases e Projetos) como patrimônio histórico desde a origem (Capítulo 3/10) é uma decisão elegante e coerente — reforça que este projeto sempre soube que estava construindo algo para durar."

**Governança:** "A separação entre 'quem pode editar' e 'quem pode excluir' (Capítulo 13) é bem desenhada, com barreira alta para exclusão. Recomendo apenas que a auditoria independente (Capítulo 19) tenha periodicidade mínima explicitamente definida, e não apenas citada como 'periódica'."

**Gestão do Conhecimento:** "A garantia de que a curadoria nunca depende de conhecimento tácito de uma única pessoa (Capítulo 15) é o ponto mais importante do documento para sobrevivência real de longo prazo. Recomendo apenas que isso seja reforçado com exigência explícita de documentação de processo, não apenas de conteúdo."

### Ajustes incorporados após a Rodada 1

- **Capítulo 12** passa a prever protocolo de conservação físico distinto do digital para objetos simbólicos, com requisitos próprios (temperatura, manuseio, segurança), complementando — não substituindo — os princípios de preservação digital já definidos.
- **Capítulo 11** passa a explicitar que identificadores únicos removidos por retificação nunca são reatribuídos a outro item, preservando a integridade histórica de referências antigas.
- **Capítulo 20** passa a indicar que o futuro Manual de Metadados deve considerar compatibilidade com padrões internacionais reconhecidos de metadados (ex: Dublin Core ou equivalente) para interoperabilidade futura.
- **Capítulo 7** passa a recomendar que entrevistas de história oral sejam conduzidas preferencialmente por pessoa com formação específica na metodologia, não por qualquer integrante disponível da equipe.
- **Capítulo 12** passa a determinar frequência mínima recomendada de verificação de integridade técnica (ao menos anual), substituindo a menção vaga a "periódica" por um compromisso mínimo explícito.
- **Capítulo 19** passa a determinar periodicidade mínima recomendada para auditoria independente (ao menos a cada dois anos), com possibilidade de antecipação em caso de mudança relevante de gestão ou tecnologia.
- **Capítulo 15** passa a reforçar explicitamente que a documentação de processo (não apenas de conteúdo) é exigência formal da função de curadoria, incluída como critério de avaliação da própria função.
- **Capítulo 14** passa a registrar como pendência do Manual do Museu Virtual/Manual de Conservação Física (Capítulo 20) a definição de acesso público físico ao patrimônio de objetos simbólicos.

### Rodada 2 — segunda leitura crítica após ajustes

**Patrimônio Cultural e Museologia (avaliação conjunta):** "O protocolo de conservação física distinto e o registro da pendência de acesso público a objetos resolvem nossos pontos de atenção. Nenhuma nova inconsistência identificada."

**Ciência da Informação e Biblioteconomia (avaliação conjunta):** "A não-reatribuição de identificadores e a recomendação de compatibilidade com padrões internacionais de metadados estão agora formalmente registradas. Suficiente para este nível de documento constitucional."

**Preservação Digital e Governança (avaliação conjunta):** "As frequências mínimas explícitas de verificação de integridade e de auditoria independente eliminam a vagueza que apontamos. O sistema está pronto para orientar prática real."

**Gestão do Conhecimento e História Oral (avaliação conjunta):** "A exigência explícita de documentação de processo e a recomendação de formação específica para condução de história oral resolvem nossos pontos."

**Consolidação final:** a segunda rodada não identificou nenhuma inconsistência estrutural relevante remanescente. Todas as lacunas técnicas legítimas da primeira rodada foram corrigidas como princípios formais ou registradas como pendências rastreáveis para os manuais técnicos futuros (Capítulo 20), sem comprometer a validade constitucional deste documento. O ciclo iterativo é encerrado nesta rodada.

---

*Fim do Projeto 08 — Sistema de Memória e Patrimônio Histórico. Documento oficial, fundamentado nas Fases 1-6 e nos Projetos 01-07, servindo como Constituição Permanente da Memória Institucional do Campeonato Brasileiro de Kettlebell Sport pelos próximos 100 anos.*
