# PROJETO 02 — SISTEMA CRIATIVO
### Campeonato Brasileiro de Kettlebell Sport
### Manual Oficial do Sistema Criativo

*Fases 1 a 6 e Projeto 01 (Sistema de Comunicação) tratados como Constituição definitiva. Este documento não cria campanhas, peças ou identidade visual — cria o sistema do qual toda peça criativa futura deve nascer, independentemente de quem a produza.*

---

## 1. FILOSOFIA CRIATIVA

Uma boa ideia, para esta marca, nunca nasce de um conceito abstrato de campanha — nasce de algo real: um nome, um esforço sustentado, um instante de controle sob pressão. O ponto de partida criativo nunca é "o que podemos inventar para chamar atenção", e sim "o que já está acontecendo aqui que merece ser mostrado com mais precisão".

**Princípios que orientam toda criação:**
- **Realidade antes de encenação.** A marca já tem material dramático genuíno (o esforço sustentado da prova); inventar drama artificial é sempre um sinal de que a ideia partiu do lugar errado.
- **Contenção é força criativa, não limitação.** Cortar é uma decisão criativa tão importante quanto adicionar — a melhor peça é frequentemente a mais simples, não a mais elaborada.
- **Nome próprio é ingrediente criativo central**, não apenas informação factual — uma peça sem nome real por trás é, por definição, mais fraca do que poderia ser.
- **Silêncio é um recurso, não um vazio.** A tensão da pausa, da respiração, do momento antes da ação, é tão criativa quanto qualquer movimento.

---

## 2. DNA CRIATIVO — O QUE TORNA UMA PEÇA RECONHECÍVEL

- **Presença de pessoas reais, nomeadas** — nunca atores, nunca modelos genéricos, nunca "atleta sem identidade".
- **Ritmo contido** — cortes de edição pausados, sem aceleração artificial ou frenesi visual.
- **Silêncio como elemento ativo** — presença deliberada de pausas sonoras e visuais, em vez de preenchimento constante de estímulo.
- **Peso como motivo visual recorrente** — o ato de segurar, sustentar, carregar, aparece como imagem-conceito central, mesmo fora de contextos literais de competição.
- **Ausência de clichês de hype** — nenhuma peça usa contagem regressiva dramática, textos em caixa alta gritada, ou trilha sonora de tensão artificial genérica.
- **Textura documental, não publicitária** — mesmo em peças mais produzidas, a estética se aproxima do registro real, não da encenação polida de comercial de fitness padrão.

Uma peça só é reconhecível como pertencente à marca quando pelo menos a maioria destes elementos está presente simultaneamente — nenhum deles isoladamente é suficiente.

---

## 3. GRANDES TERRITÓRIOS CRIATIVOS

**"O Peso do Tempo"** — visualização do ato de sustentar algo por um período prolongado (literal ou metafórico). *Quando usar:* conteúdo de descoberta e campanhas de posicionamento central. *Quando evitar:* comunicação técnica-educativa, onde a clareza deve prevalecer sobre a metáfora. *Emoção:* tensão contemplativa, admiração.

**"Nome Próprio"** — retrato e identidade individual como centro da peça. *Quando usar:* qualquer conteúdo de reconhecimento, legado ou prova social. *Quando evitar:* peças de pura descoberta inicial, onde o público ainda não tem contexto para se importar com um nome específico. *Emoção:* orgulho, conexão pessoal.

**"Respiração Contida"** — foco sonoro e visual na tensão fisiológica real da competição. *Quando usar:* conteúdo documental/dramático central da marca. *Quando evitar:* comunicação institucional para patrocinadores, onde clareza informativa deve prevalecer. *Emoção:* tensão, empatia física.

**"Bastidor Técnico"** — desconstrução educativa de regras, julgamento, treino. *Quando usar:* conteúdo para iniciantes e imprensa. *Quando evitar:* peças de impacto emocional puro, onde excesso de explicação técnica dilui a força dramática. *Emoção:* fascínio, compreensão.

**"Arquivo Vivo"** — estética de memória, revisitação, continuidade histórica. *Quando usar:* conteúdo de legado, aniversários de trajetória, retorno de atletas. *Quando evitar:* conteúdo de primeiro contato, onde ainda não existe história compartilhada para revisitar. *Emoção:* nostalgia orgulhosa, continuidade.

**"Origem"** — herança histórica e cultural do kettlebell. *Quando usar:* esporadicamente, como camada de profundidade cultural, nunca como base de uma campanha inteira. *Quando evitar:* como ferramenta de aquisição de público amplo — risco de dissonância cultural já identificado na Fase 2. *Emoção:* reverência.

---

## 4. FRAMEWORK DE GERAÇÃO DE IDEIAS (DO BRIEFING AO CONCEITO)

1. **Ancoragem constitucional:** qual promessa da marca (Fase 3, Capítulo 10) esta peça está a serviço de cumprir?
2. **Ponto de partida real:** qual pessoa, nome ou momento real inspira o conceito? Nenhuma ideia avança sem essa resposta.
3. **Escolha de território criativo:** qual dos territórios do Capítulo 3 é o mais adequado à função e ao público desta peça?
4. **Redução:** o que pode ser cortado sem perder a ideia central? A pergunta é feita ativamente, não apenas ao final.
5. **Teste de essência:** a ideia comunica, de alguma forma, "sustentar" e/ou "guardar" — os dois verbos centrais da Big Idea?
6. **Teste de qualidade:** avaliação pela matriz do Capítulo 5.
7. **Teste de diferenciação:** avaliação pelo checklist do Capítulo 6.
8. **Aprovação:** checklist final do Capítulo 13 antes de qualquer produção começar.

---

## 5. CRITÉRIOS DE QUALIDADE — MATRIZ OBJETIVA

| Critério | Pergunta-teste | Nota mínima aceitável (0–5) |
|---|---|---|
| Autenticidade | O peso, o esforço ou a emoção mostrados são reais, não encenados? | 4 |
| Contenção | A peça poderia ser mais simples sem perder força? Se sim, ainda não está pronta. | 4 |
| Nome presente | Existe uma pessoa real, nomeada, no centro da peça (quando aplicável ao formato)? | 4 |
| Diferenciação | Um espectador confundiria isso com CrossFit/HYROX/Spartan/fitness genérico? | 5 (quanto menor a confusão, melhor) |
| Emoção genuína | A emoção nasce da situação real ou foi artificialmente adicionada (trilha, texto, edição)? | 4 |
| Compatibilidade de voz | O tom está de acordo com o Capítulo 5 do Sistema de Comunicação (Projeto 01)? | 5 |

Uma ideia só avança para produção se atingir a nota mínima em todos os critérios simultaneamente — pontuação alta em apenas alguns critérios não compensa uma nota baixa em outro.

---

## 6. DIFERENCIAÇÃO — COMO EVITAR PARECER OUTRA MARCA

- **Frente ao CrossFit:** evitar espetáculo de intensidade, gritos, linguagem de "prova extrema" e estética de leaderboard competitivo explícito como centro visual.
- **Frente ao HYROX:** evitar imagética de massa genérica "para todo mundo" sem foco em identidade individual — a marca sempre nomeia, nunca generaliza.
- **Frente ao Spartan:** evitar estética de lama, obstáculo, guerreiro primitivo e linguagem de sofrimento como prova de valor.
- **Frente ao Ironman/endurance:** evitar clichês de paisagem épica e jornada de vida genérica descolada da tensão específica e contida do kettlebell sport.
- **Frente a fitness genérico:** evitar frases motivacionais soltas, estética de academia comercial polida, iluminação de estúdio artificial excessiva.

Toda peça deve passar pelo teste simples: **se o nome da marca fosse removido, ainda seria possível reconhecer que essa peça pertence a este campeonato e não a outro?** Se a resposta for não, a peça não está pronta.

---

## 7. STORYTELLING VISUAL — ESTRUTURAS QUE FUNCIONAM

- **O plano contínuo:** narrativa construída em um único take ou sensação de continuidade ininterrupta, espelhando a natureza real da prova (série contínua sem pausa) — estrutura mais fiel ao território "Respiração Contida".
- **Silêncio-para-nome:** a peça começa anônima (sem identificar quem está em cena) e só revela o nome no fim — estrutura eficaz para o território "Nome Próprio".
- **Antes/depois com o mesmo enquadramento:** justapõe o mesmo atleta ou cena em momentos diferentes no tempo, reforçando trajetória e memória — estrutura natural para "Arquivo Vivo".
- **Pergunta sem resposta imediata:** a peça apresenta uma tensão ou questão real (o que sustenta alguém por dez minutos contínuos?) sem resolvê-la de forma explicativa, convidando o público a buscar a resposta — estrutura eficaz para conteúdo de descoberta.

---

## 8. DIREÇÃO CRIATIVA (SEM DEFINIR IDENTIDADE VISUAL)

- **Fotografia:** luz natural sempre que possível, proximidade real com o sujeito, evitar poses artificiais ou excesso de retoque — o objetivo é registro, não composição publicitária polida.
- **Vídeo:** câmera estável mas não excessivamente produzida, preferência por captação de áudio real (respiração, ambiente) sobre trilha sonora artificial constante.
- **Documentário:** abordagem observacional, evitar narração em voz over que force interpretação emocional — deixar a imagem e o som reais comunicarem por si.
- **Motion design:** uso contido, nunca como espetáculo visual central; quando usado, reforça dados ou trajetória (ex: visualização de arquivo histórico), nunca substitui imagem real.
- **Ilustração:** uso esporádico, mais associado ao território "Arquivo Vivo" (linha do tempo, marcos históricos) do que a comunicação de descoberta ou hype.
- **Bastidores:** estética deliberadamente menos polida, reforçando autenticidade — bastidor nunca deve parecer "produzido" da mesma forma que a peça principal.
- **Retratos:** contato visual direto, legenda com nome sempre presente — nunca um retrato anônimo em material de reconhecimento.

---

## 9. SISTEMA DE CAMPANHAS — COMO NASCE, COMO EVOLUI

Uma campanha nunca nasce de um calendário vazio a ser preenchido — nasce de um momento real disponível no Sistema de Memória (Fase 5) ou de um marco genuíno do calendário competitivo. As etapas são:

1. **Identificação do momento real** que justifica a campanha (uma trajetória, uma edição, um marco de temporada).
2. **Enquadramento na Arquitetura Narrativa** de quatro atos definida na Fase 4 (revelação → prova social → convite → memória).
3. **Escolha do(s) território(s) criativo(s)** aplicável(is) a cada ato.
4. **Produção conforme a Direção Criativa** (Capítulo 8).
5. **Validação pelos critérios de qualidade e diferenciação** (Capítulos 5 e 6).
6. **Veiculação conforme o papel de cada canal** já definido no Sistema de Comunicação (Projeto 01).
7. **Retroalimentação do Sistema de Memória** — toda campanha, ao final, deve gerar algum registro (nome, história, dado) que passa a fazer parte do arquivo permanente, fechando o ciclo.

---

## 10. SISTEMA DE GRANDES IDEIAS — O QUE DURA ANOS

Uma ideia tem potencial de durar décadas quando passa nos seguintes testes:

- **Teste do silêncio:** a ideia ainda comunica algo relevante se removido todo texto e toda trilha sonora — depende de imagem e situação, não de explicação.
- **Teste de propriedade:** nenhum concorrente direto (CrossFit, HYROX, Spartan, Ironman) poderia reivindicar essa ideia com credibilidade igual.
- **Teste de tradução:** a ideia funciona em qualquer formato (foto, vídeo curto, vídeo longo, texto) sem depender de um único meio.
- **Teste de raiz:** a ideia se conecta literalmente aos dois verbos centrais da marca — sustentar e guardar — não apenas ao tom geral de "esporte" ou "superação" genérica.

Ideias que passam nos quatro testes tornam-se candidatas a **territórios permanentes** (Capítulo 3); ideias que passam em apenas um ou dois testes são tratadas como conteúdo pontual, não como plataforma de longo prazo.

---

## 11. MATRIZ DE FORMATOS

- **Vídeos curtos:** função de descoberta — primeira interrupção de atenção, território "O Peso do Tempo" ou "Nome Próprio".
- **Vídeos longos:** função de aprofundamento dramático — território "Respiração Contida".
- **Documentários:** função de legado e prova social ampliada — território "Arquivo Vivo" e "Bastidor Técnico" combinados.
- **Entrevistas:** função de humanização e bastidor técnico — território "Bastidor Técnico" e "Nome Próprio".
- **Fotografia:** função de registro permanente e retrato — insumo direto do Sistema de Memória.
- **Artigos:** função educativa e de relacionamento com imprensa — território "Bastidor Técnico".
- **Apresentações institucionais:** função comercial e de patrocínio — apoio direto ao Capítulo 13 do Sistema de Comunicação.
- **Eventos presenciais:** função de prova definitiva — onde todos os territórios criativos se manifestam simultaneamente, ao vivo.

---

## 12. SISTEMA DE INOVAÇÃO CRIATIVA

Inovar sem perder identidade exige que qualquer novo formato, tecnologia (realidade aumentada, inteligência artificial generativa, novos formatos de mídia social) ou linguagem visual passe pelo mesmo funil de validação de qualquer outra peça — Capítulos 5 e 6 — antes de ser adotado como prática recorrente.

**O que pode evoluir livremente:** ferramentas de produção, formatos de distribuição, tecnologia de captação.
**O que nunca pode ser alterado por inovação tecnológica:** a presença de nomes reais, a rejeição de encenação artificial, e os territórios criativos centrais definidos no Capítulo 3 — nenhuma tecnologia nova justifica abrir mão desses elementos.

Toda proposta de inovação criativa relevante passa pela mesma Governança de Marca (Fases 5 e 6) responsável por proteger a Constituição do projeto, evitando que entusiasmo tecnológico pontual comprometa consistência de longo prazo.

---

## 13. CHECKLIST CRIATIVO — ANTES DE INICIAR PRODUÇÃO

1. Esta ideia nasceu de uma pessoa, nome ou momento real?
2. É possível identificar claramente qual território criativo (Capítulo 3) está sendo usado?
3. A ideia passou pela matriz de qualidade (Capítulo 5) com nota mínima em todos os critérios?
4. A ideia passou pelo teste de diferenciação (Capítulo 6) — não seria confundida com concorrentes?
5. O tom está alinhado ao Sistema de Comunicação (Projeto 01)?
6. Existe um plano claro de como esta peça retroalimenta o Sistema de Memória?
7. Foi testado se a ideia ainda funciona removendo texto e trilha sonora (teste do silêncio, Capítulo 10)?

Nenhuma produção começa formalmente sem resposta afirmativa a todas as perguntas.

---

## 14. AUDITORIA FINAL — CONSELHO DE SETE ESPECIALISTAS

**Diretor Criativo Executivo:** "O sistema evita a armadilha mais comum de manuais de marca — regras estéticas vagas demais para orientar decisão real. O framework de geração de ideias (Capítulo 4) é aplicável no dia a dia, não apenas em teoria."

**Diretor de Arte:** "A ausência deliberada de identidade visual (paleta, tipografia) nesta fase está correta, mas cria um risco temporário: sem esses elementos, diferentes produtores podem interpretar 'contenção visual' de formas distintas até que a identidade visual formal seja definida. Recomendo que isso seja tratado como prioridade imediata na próxima fase de execução."

**Redator:** "O vocabulário e o tom já vêm bem amarrados ao Projeto 01, o que evita duplicidade de regras. Gostaria de ver, futuramente, exemplos reais de texto aplicados a cada território criativo — isso ainda está em nível conceitual."

**Fotógrafo:** "Os princípios de fotografia (Capítulo 8) são coerentes com a filosofia de autenticidade, mas immediate risco prático: 'luz natural sempre que possível' pode ser operacionalmente difícil em ambientes de competição fechados. Recomendo uma nota de exceção controlada para esses casos, sem abrir mão do princípio de proximidade real."

**Diretor de Cinema:** "O território 'Respiração Contida' e a estrutura de 'plano contínuo' (Capítulo 7) são, na minha experiência, os elementos com maior potencial de viralização orgânica de qualidade — recomendo que sejam tratados como prioridade de investimento de produção assim que o orçamento permitir (conforme os cenários já definidos na Fase 6)."

**Especialista em Branding:** "O teste de propriedade e o teste do silêncio (Capítulo 10) são ferramentas raras e valiosas — a maioria dos sistemas criativos não oferece critério objetivo para saber se uma ideia realmente pertence à marca ou é apenas boa em abstrato. Isso protege contra ideias 'bonitas, mas genéricas'."

**Atleta:** "Como alguém que seria fotografado e filmado por este sistema, aprecio a ênfase em autenticidade e recusa de encenação — já vivi experiências em outros eventos onde me pediram para 'atuar' emoção que não senti naquele momento. Espero que isso realmente se sustente na prática, principalmente sob pressão de prazo de produção."

**Consolidação das críticas:** nenhuma crítica contradiz a estrutura do sistema — todas apontam necessidades de complementação em fases futuras de execução, incorporadas como pendências formais: **(1)** definição de identidade visual (paleta, tipografia) como prioridade imediata da próxima fase, para eliminar ambiguidade de interpretação entre produtores; **(2)** nota de exceção controlada para fotografia em ambientes fechados, preservando o princípio de proximidade real; **(3)** priorização orçamentária do território "Respiração Contida" em formato de vídeo assim que os cenários financeiros da Fase 6 permitirem; **(4)** desenvolvimento futuro de exemplos aplicados de texto por território criativo, como extensão prática deste manual.

---

*Fim do Projeto 02 — Sistema Criativo. Documento oficial, fundamentado nas Fases 1 a 6 e no Projeto 01, servindo como Manual Criativo permanente do Campeonato Brasileiro de Kettlebell Sport.*
