# FASE 3 — PLATAFORMA DE MARCA
### Campeonato Brasileiro de Kettlebell Sport
### Documento oficial de identidade permanente

*Fundamentado sobre a Constituição do projeto: Fase 1 (Inteligência Estratégica) e Fase 2 (Identidade Estratégica — "O Duelo Testemunhado"). Nenhuma decisão estratégica anterior é reaberta aqui. Este documento constrói a plataforma de marca a partir do DNA já definido: coragem individual, testemunho coletivo, força como controle (não caos), pertencimento em camadas, memória como ativo permanente.*

---

## 1. ESSÊNCIA DA MARCA

**"A força que se sustenta é a força que se lembra."**

Essência de marca não é slogan — é o núcleo do qual tudo o resto (visão, voz, símbolos, experiência) precisa poder ser deduzido sem contradição. Esta frase carrega dois verbos que resumem toda a Fase 2: **sustentar** (a natureza real da prova — controle prolongado sob carga, o oposto do impulso explosivo de um único levantamento) e **lembrar** (a promessa central do "Duelo Testemunhado" — nenhum esforço sustentado desaparece sem registro, porque há sempre alguém, e uma comunidade, testemunhando).

**Por que nasce diretamente das Fases 1 e 2:** a Fase 1 identificou que nenhum concorrente do benchmark comunica bem retenção pós-evento ou memória de longo prazo do atleta — um vácuo competitivo real. A Fase 2 definiu que o núcleo emocional vencedor era o drama do "duelo silencioso", sustentado por uma camada estrutural de comunidade/casa. A essência condensa os dois: o verbo "sustentar" é o gesto físico e psicológico da prova; o verbo "lembrar" é o mecanismo estrutural que transforma esse gesto em pertencimento duradouro.

**Por que é superior às alternativas descartadas:** uma essência baseada em "superação" (linguagem de Spartan/CrossFit) ou em "acessibilidade para todos" (linguagem de HYROX) reproduziria territórios já ocupados, exatamente o erro que a Fase 2 identificou e evitou. Uma essência baseada apenas em "comunidade" (Alternativa 4 isolada) prometeria pertencimento sem dar à marca nenhum gancho emocional imediato para quem ainda não conhece o esporte — reproduzindo o ponto cego que o debate da Fase 2 expôs. "A força que se sustenta é a força que se lembra" resolve os dois problemas na mesma frase: é ao mesmo tempo descrição fiel do esporte (força sustentada, não explosiva) e promessa estrutural da marca (nada que é sustentado aqui é esquecido).

---

## 2. PROPÓSITO

*Por quê o Campeonato Brasileiro de Kettlebell Sport precisa existir?*

**Por quê 1:** Para dar um palco a atletas de kettlebell sport no Brasil.

**Por quê 2 — por que eles precisam de um palco?**
Porque maestria sem testemunha desaparece. A excelência técnica que este esporte exige — décimos de controle, respiração, ritmo sustentado por minutos contínuos — é, hoje, praticamente invisível fora de um círculo muito pequeno. Sem um palco permanente, não existe onde essa maestria seja vista, reconhecida e guardada.

**Por quê 3 — por que isso importa especificamente para este tipo de esforço?**
Porque, ao contrário de um recorde de levantamento único (visível, fotografável, instantâneo) ou de uma prova de resistência com linha de chegada clara (visível pela distância percorrida), o esforço do kettlebell sport é *silencioso e contínuo* — a coisa mais impressionante que acontece numa série de dez minutos é justamente o que **não** acontece: o atleta não larga o peso, não perde o ritmo, não quebra. Esse tipo de conquista, por natureza, exige alguém que a enquadre e a nomeie — sozinha, ela passa despercebida.

**Por quê 4 — por que uma sociedade precisaria enquadrar e nomear esse tipo específico de esforço?**
Porque o Brasil, como a maioria das culturas de fitness contemporâneas, celebra publicamente apenas dois tipos de dedicação: a vitória espetacular (o recorde, o gol, a virada) e o sofrimento extremo (a prova brutal, o "no pain no gain"). Existe uma virtude intermediária — a competência sustentada, silenciosa, disciplinada — que raramente ganha palco público, embora seja exatamente a virtude que sustenta a maior parte da vida real: carreiras, famílias, rotinas de treino ao longo de anos, trabalho bem-feito sem aplausos diários.

**Por quê 5 — causa fundamental:**
O Campeonato Brasileiro de Kettlebell Sport existe para que essa virtude específica — coragem controlada, sustentada, sem espetáculo — deixe de ser invisível. Ele existe não apenas para promover competições, mas para construir, ano após ano, o único lugar no Brasil onde esse tipo de esforço é visto, nomeado e lembrado por quem entende exatamente o que ele custou.

---

## 3. VISÃO

**5 anos — Existência reconhecida.**
O Kettlebell Sport deixa de ser uma categoria invisível para o público geral de fitness e passa a existir como opção reconhecível — do jeito que "fazer um HYROX" já é uma frase que faz sentido para milhões de brasileiros hoje. O campeonato se torna o destino natural de qualquer atleta de força que descobre a modalidade, com um sistema de reconhecimento nominal e um ritual anual já reconhecíveis pela comunidade.

**10 anos — Referência cultural de "força controlada".**
O campeonato se consolida como a referência nacional de um território próprio: não é "mais um esporte de força" nem "mais uma corrida com obstáculos" — é o lugar onde controle, disciplina e sustentação prolongada são celebrados como valor competitivo distinto. Patrocinadores de performance e bem-estar já associam a marca a esse território específico. Existe um arquivo público e crescente da trajetória de cada atleta que já competiu.

**20 anos — Patrimônio simbólico nacional, referência mundial.**
O modelo construído pelo campeonato brasileiro — drama testemunhado, comunidade em camadas, memória como ativo formal — é estudado e citado por federações de kettlebell sport em outros países como referência de construção de marca esportiva de nicho. Múltiplas gerações de atletas, técnicos e boxes se enxergam representadas em um patrimônio histórico contínuo. O campeonato se torna sinônimo cultural do próprio esporte no Brasil.

**Como essa marca pretende transformar o Kettlebell Sport brasileiro:** não pela via do volume (tentando parecer maior do que é), mas pela via da profundidade — criando o único registro formal e emocional de memória que a modalidade tem no país, e usando esse registro como o ativo mais valioso e mais difícil de copiar do projeto.

---

## 4. MISSÃO

**Dar palco, nome e memória permanente à força que se sustenta — construindo, ano após ano, o patrimônio simbólico do Kettlebell Sport brasileiro.**

Esta é a missão permanente da organização: ela não muda com o crescimento do campeonato, não muda com patrocínio, não muda com formato de prova. Toda edição, toda decisão operacional e toda parceria devem, no mínimo, cumprir uma destas três funções — dar palco, dar nome, ou construir memória. Se uma iniciativa não cumpre nenhuma das três, ela não pertence à missão da organização, mesmo que pareça boa ideia isoladamente.

---

## 5. VALORES

### 1. Controle acima do caos
**Significado:** a marca valoriza domínio, respiração e ritmo mais do que intensidade descontrolada ou espetáculo de sofrimento.
**Aplicação prática:** comunicação evita linguagem de "destruição" ou "sofrimento extremo"; cerimônias e rituais têm cadência deliberada, não frenética.
**Exemplos:** um vídeo de bastidores mostra a respiração controlada de um atleta antes da série, não apenas o momento de esgotamento.
**Comportamentos incompatíveis:** promover conteúdo que glorifica lesão, colapso físico ou "quebrar o corpo" como prova de valor.

### 2. Coragem visível
**Significado:** todo esforço sustentado merece ser visto e reconhecido — a coragem não deve competir por atenção, ela deve receber atenção deliberadamente.
**Aplicação prática:** todo atleta competidor, independente do nível, tem seu nome chamado publicamente durante a prova.
**Exemplos:** transmissões e materiais dão tempo de tela a atletas de categorias intermediárias, não só ao pódio.
**Comportamentos incompatíveis:** tratar atletas fora do top 3 como irrelevantes na comunicação.

### 3. Memória como responsabilidade
**Significado:** a organização se compromete a registrar formalmente a trajetória de cada atleta que compete, ano após ano.
**Aplicação prática:** manutenção de um arquivo histórico público (nomes, resultados, evolução) acessível e atualizado.
**Exemplos:** um atleta que compete pela quinta vez tem acesso ao próprio histórico documentado pela organização.
**Comportamentos incompatíveis:** apagar ou negligenciar resultados de edições anteriores; tratar dados históricos como descartáveis.

### 4. Pertencimento genuíno
**Significado:** comunidade não é tática de marketing — é estrutura real de reconhecimento entre atleta, técnico, box e cidade.
**Aplicação prática:** rituais e reconhecimentos são organizados em camadas (individual, técnico, box, cidade), não apenas em massa.
**Exemplos:** menção pública ao box de origem do atleta durante a apresentação da prova.
**Comportamentos incompatíveis:** tratar comunidade como "engajamento" de rede social sem contrapartida real de reconhecimento.

### 5. Excelência técnica acessível
**Significado:** o prestígio da técnica não deve ser usado para intimidar ou excluir quem está começando.
**Aplicação prática:** todo conteúdo técnico avançado é acompanhado de uma versão traduzida para iniciantes.
**Exemplos:** explicação de critérios de julgamento em linguagem simples, sem depender só do jargão federativo.
**Comportamentos incompatíveis:** comunicação que pressupõe conhecimento prévio das regras como pré-requisito para se importar com o esporte.

### 6. Consistência ano após ano
**Significado:** os rituais e promessas da marca não mudam a cada edição por conveniência ou tendência.
**Aplicação prática:** elementos simbólicos centrais (chamada de nomes, arquivo histórico, cerimônia de reconhecimento) são fixos e protegidos de alterações cosméticas.
**Exemplos:** o mesmo ritual de abertura se repete, reconhecível, edição após edição.
**Comportamentos incompatíveis:** alterar elementos rituais centrais apenas para "parecer mais moderno" sem justificativa estratégica.

### 7. Honestidade competitiva
**Significado:** a organização nunca comunica escassez, urgência ou exclusividade que não sejam reais.
**Aplicação prática:** qualquer mecanismo de "vagas limitadas" só é usado quando há demanda genuína comprovável.
**Exemplos:** comunicação transparente sobre critérios de qualificação, julgamento e elegibilidade.
**Comportamentos incompatíveis:** simular fila, contagem regressiva ou urgência artificial para gerar conversão.

---

## 6. CRENÇAS FUNDAMENTAIS

- **Sobre esporte:** acreditamos que esporte é a forma mais honesta de mostrar quem alguém é sob pressão — sem edição, sem discurso, só o corpo e a decisão de continuar.
- **Sobre competição:** acreditamos que competir não é vencer o outro, é revelar, publicamente, do que você é capaz quando ninguém mais pode fazer por você.
- **Sobre coragem:** acreditamos que a coragem mais rara não é a que grita — é a que se mantém, minuto após minuto, sem precisar provar nada além de continuar.
- **Sobre disciplina:** acreditamos que disciplina é a forma mais silenciosa e mais subestimada de ambição.
- **Sobre comunidade:** acreditamos que nenhuma conquista individual é completa sem alguém que saiba o que ela custou.
- **Sobre excelência:** acreditamos que excelência técnica não deveria ser sinônimo de exclusão — o padrão mais alto e a porta mais aberta podem coexistir.
- **Sobre evolução:** acreditamos que progresso importa mais que perfeição — e que cada edição registrada é prova de um caminho, não um veredito final.
- **Sobre liderança:** acreditamos que liderar, neste esporte, é dar o exemplo de controle antes de exigir desempenho.
- **Sobre reconhecimento:** acreditamos que todo atleta que termina o que começou merece ter seu nome dito em voz alta, não apenas seu resultado registrado em uma planilha.
- **Sobre legado:** acreditamos que legado não se declara — se constrói, atleta por atleta, edição por edição, nome por nome.

---

## 7. PERSONALIDADE

Se o Campeonato Brasileiro de Kettlebell Sport fosse uma pessoa, seria alguém **de meia-idade, presença firme, fala pausada e olhos atentos** — o tipo de pessoa que impõe respeito não por volume, mas por precisão. Já viveu o suficiente para não precisar provar nada por impulso, mas ainda compete, ainda se importa, ainda está no jogo.

**Como falaria:** frases curtas, diretas, sem excesso de adjetivos. Nunca grita para ser ouvida — fala baixo o suficiente para que as pessoas se aproximem para escutar.

**Como se vestiria:** sem logotipos gritantes, sem excesso visual. Roupas funcionais, de qualidade perceptível, com um detalhe simbólico discreto (nunca ostensivo) que só quem entende reconhece.

**Como tomaria decisões:** devagar, com critério, priorizando consistência de longo prazo sobre ganho rápido de visibilidade. Prefere dizer não a uma oportunidade vistosa que contradiga seus valores do que dizer sim por conveniência.

**Como trataria os atletas:** pelo nome. Sempre pelo nome. Lembraria de conquistas passadas antes de perguntar sobre a atual. Trataria o atleta de última colocação com o mesmo respeito que o campeão, porque ambos sustentaram até o fim.

**Como reagiria em crises:** sem pânico e sem silêncio. Reconheceria o problema publicamente, de forma direta, sem espetáculo defensivo — e agiria com a mesma disciplina que exige dos atletas: controle, não caos.

---

## 8. ARQUÉTIPOS

**Principal — O Herói (reformulado como coragem silenciosa, não conquista bombástica)**
Escolhido porque o núcleo emocional definido na Fase 2 é, precisamente, a jornada de enfrentar o próprio limite e não recuar — a estrutura clássica do arquétipo do Herói. A diferença deliberada em relação ao uso mais comum desse arquétipo (Nike, Spartan) é que aqui o heroísmo não é espetacular — é contido, quase invisível até ser testemunhado.

**Secundário — O Sábio**
Escolhido porque representa a camada de controle, técnica e domínio que diferencia a marca do caos comunicado por concorrentes diretos. O Sábio explica, entende, domina — reforça a legitimidade técnica sem tornar a marca fria.

**Complementar — O Cuidador (com traços de Todo-Mundo/Everyman)**
Escolhido para carregar a camada estrutural de comunidade e pertencimento definida na Fase 2 como vantagem competitiva central. O Cuidador garante que ninguém seja esquecido; o traço de Todo-Mundo garante acessibilidade e evita que a marca soe hierárquica ou fechada.

**Arquétipos descartados e por quê:**
- **Fora-da-Lei/Rebelde** — combina bem com "desafiar convenções", mas contradiz diretamente o valor de "controle acima do caos"; território já ocupado por Spartan.
- **Mago** — traria um tom místico/transformador que soaria artificial dado o compromisso da marca com honestidade competitiva e ausência de exagero.
- **Governante** — reforçaria prestígio e hierarquia, mas entraria em conflito direto com o valor de "excelência técnica acessível", criando risco de elitismo.
- **Bobo da Corte** — incompatível com a personalidade séria e pausada definida no Capítulo 7.

**Riscos da combinação escolhida:** Herói + Sábio + Cuidador é uma combinação exigente de sustentar simultaneamente — risco real de a comunicação pender demais para um dos três (viradas eventuais para "só drama" ou "só técnica" ou "só comunidade") e perder o equilíbrio. **Benefícios:** juntos, cobrem exatamente as três camadas definidas na Fase 2 (núcleo emocional, tom/registro, estrutura de retenção) sem sobreposição — nenhum dos três faz o trabalho do outro.

---

## 9. BIG IDEA

**"O que você sustenta, a gente guarda."**

Esta não é uma frase de campanha — é o princípio organizador de todas as decisões futuras da marca, com a mesma função que "Just Do It" tem para a Nike ou "Belong Anywhere" tem para o Airbnb.

A força da ideia está na ambiguidade deliberada de dois verbos:

- **Sustentar** — o gesto físico literal do esporte (segurar o peso, manter o ritmo, não largar) e, ao mesmo tempo, o gesto psicológico de manter-se firme sob qualquer tipo de pressão, dentro ou fora da competição.
- **Guardar** — o compromisso estrutural da organização: guardar o nome, o resultado, a trajetória, a memória. Guardar também no sentido de proteger — cuidar de quem está competindo, não apenas espectar.

**Como influencia décadas de decisões futuras:**

- **Identidade visual:** qualquer elemento gráfico que remeta a "segurar", "sustentar" ou "registrar" é território natural da marca; elementos que remetem a explosão, impacto único ou velocidade não são.
- **Produtos e experiências:** qualquer novo produto (App, arquivo histórico, sistema de ranking, item físico de reconhecimento) deve responder à pergunta: isso ajuda a "guardar" algo que o atleta "sustentou"?
- **Patrocínio:** parceiros são chamados, na comunicação institucional, de "guardiões" do campeonato — não apenas financiadores.
- **Decisões de crise:** qualquer resposta institucional deve demonstrar que a marca "segura" o problema com controle, e "guarda" (documenta, aprende, não esconde) o que aconteceu.
- **Expansão internacional futura:** a mesma ideia se traduz sem perda de sentido em qualquer idioma — "o que você sustenta, a gente guarda" não depende de trocadilho local para funcionar.

---

## 10. PROMESSA DA MARCA

- **Para atletas:** "Seu nome não desaparece depois da prova. Nós registramos, lembramos e contamos sua trajetória, ano após ano."
- **Para treinadores:** "Seu trabalho técnico é reconhecido publicamente, não apenas mencionado como rodapé do resultado do atleta."
- **Para boxes:** "Vocês são vitrine, não concorrência. Seus atletas carregam o nome do seu box com orgulho dentro da nossa comunicação oficial."
- **Para patrocinadores:** "Associação a um território emocional único, defensável e crescente — não a mais um evento de nicho genérico."
- **Para a comunidade:** "Histórias reais, contadas com o mesmo respeito e controle que pedimos aos atletas dentro da arena."
- **Para espectadores:** "Você vai entender o drama, mesmo sem entender todas as regras — porque o que está em jogo é humano antes de ser técnico."

**Como garantir que a promessa seja cumprida:** cada promessa exige um mecanismo estrutural correspondente, não apenas boa intenção discursiva — arquivo histórico público e mantido (para atletas), crédito nominal formal a técnicos em toda comunicação oficial (para treinadores), presença visível de boxes em todo material de resultado (para boxes), relatórios e métricas de território/engajamento entregues a parceiros (para patrocinadores), curadoria editorial que prioriza histórias reais sobre conteúdo promocional (para comunidade), e roteiro de transmissão que sempre contextualiza o que está em jogo emocionalmente antes do tecnicamente (para espectadores). Promessa sem mecanismo é apenas discurso — este documento trata isso como falha de sistema, não de boa vontade.

---

## 11. BRAND STORY

*(Narrativa atemporal — não é história factual da organização, é o significado da marca contado como mito.)*

Há um momento, em toda prova de kettlebell sport, em que o peso deixa de ser peso e vira tempo. O atleta já não está levantando um objeto — está segurando um relógio que não para, minuto após minuto, enquanto o corpo pede para largar e a mente decide que ainda não é hora.

Ninguém aplaude no meio disso. Não há explosão, não há linha de chegada visível, não há um adversário para vencer com um golpe só. Existe apenas a decisão, repetida centenas de vezes por minuto, de continuar.

É fácil não ver isso. É fácil olhar para um esforço silencioso e achar que nada está acontecendo. Mas há sempre alguém que sabe olhar — um técnico que reconhece o instante exato em que a respiração muda, um companheiro de box que sabe o que aquele atleta treinou para chegar ali, uma comunidade inteira que aprendeu a prestar atenção justamente onde o espetáculo não existe.

É para isso que este campeonato existe. Não para inventar drama onde não há — para dar testemunha a um drama que sempre existiu, mas que raramente teve palco. Cada nome chamado, cada resultado guardado, cada história contada de novo no ano seguinte é uma forma de dizer: o que você sustentou não passou despercebido. Nós vimos. Nós guardamos.

É por isso que ninguém aqui compete sozinho — mesmo quando, no meio da série, parece que está.

---

## 12. BRAND MANIFESTO

Existe um tipo de força que não faz barulho.

Não é a força do golpe único, nem a da vitória instantânea. É a força de quem continua — quando o corpo já pediu para parar há um minuto, quando ninguém mais está prestando atenção, quando a única testemunha possível seria o próprio silêncio.

Nós acreditamos que esse tipo de força merece um lugar. Não um lugar de espetáculo, nem de sofrimento decorativo — um lugar de reconhecimento real, onde cada pessoa que sustentou até o fim tenha seu nome dito em voz alta, sua trajetória registrada, sua história contada de novo, ano após ano.

Não pedimos que você grite. Pedimos que você segure — e prometemos que, enquanto você segura, alguém está prestando atenção.

Não somos o esporte do impacto. Somos o esporte do controle. Não somos o esporte da multidão anônima. Somos o esporte em que se sabe o nome de quem compete, o box de onde veio, a trajetória que percorreu para chegar até aqui.

Cada edição é uma página. Cada atleta é um nome que fica. E o que você sustenta, nós guardamos — não porque é bonito dizer isso, mas porque é o único jeito de garantir que esse tipo de coragem silenciosa nunca mais precise acontecer sem testemunha.

---

## 13. VOZ DA MARCA

**Personalidade da voz:** madura, contida, precisa — nunca eufórica, nunca apologética.
**Tom:** sóbrio e orgulhoso, sem arrogância; caloroso, sem ser informal em excesso.
**Estilo:** frases curtas e concretas; evita adjetivos em excesso; prefere verbos de ação controlada a superlativos.
**Ritmo:** pausado e deliberado — a pontuação reflete respiração controlada, não pressa. Evita excesso de exclamações e caixa alta.
**Vocabulário:** concreto, sensorial, ligado ao corpo e ao tempo (segurar, sustentar, respirar, continuar), nunca abstrato-vazio.

**Palavras recomendadas:** sustentar, testemunha, nome, memória, controle, domínio, presença, trajetória, prova, continuar, guardar, reconhecer.

**Palavras a evitar:** insano, brutal, destruir, guerra, "beast mode", "no pain no gain", "sem limites" (clichê genérico de fitness sem lastro na identidade real da marca).

**Palavras proibidas:** qualquer linguagem que glorifique lesão, colapso físico ou automutilação como prova de valor; qualquer comparação depreciativa a outros esportes ou federações; apropriação descontextualizada da herança russa do kettlebell sem cuidado histórico e respeito cultural.

---

## 14. TERRITÓRIOS DA MARCA

**Sobre o que a marca tem legitimidade para falar:**
Força controlada e técnica; disciplina e consistência; superação silenciosa e sustentada; comunidade e pertencimento esportivo; memória e trajetória do atleta; desenvolvimento técnico do esporte no Brasil; bastidores e cultura de treino; reconhecimento de treinadores, boxes e comunidades locais.

**Sobre o que a marca nunca deve falar:**
Política partidária; comparações depreciativas com outras modalidades esportivas; promessas de emagrecimento rápido ou linguagem de transformação estética comparativa (contradiz o valor de "excelência técnica acessível" e desvia do território de "força/controle" para o território, já ocupado por outros, de estética corporal); discurso que romantiza lesão ou sofrimento físico extremo como prova de comprometimento; qualquer conteúdo que trate atletas como número ou estatística sem nome.

---

## 15. PILARES DE COMUNICAÇÃO

1. **Nome e Memória** — toda comunicação, sempre que possível, nomeia pessoas reais, não apenas resultados. Função estratégica: sustentar a promessa central da marca (memória) em todo ponto de contato.
2. **Controle sobre Caos** — o registro visual e verbal da marca sempre privilegia composição, respiração e ritmo sobre intensidade caótica. Função estratégica: proteger a diferenciação de tom frente a concorrentes de linguagem mais explosiva.
3. **Prova Real** — nenhuma comunicação usa urgência ou escassez que não seja genuína. Função estratégica: proteger a credibilidade de longo prazo, evitando o erro mais citado no benchmark da Fase 1.
4. **Comunidade em Camadas** — comunicação reconhece, sempre que possível, atleta, técnico, box e cidade — não apenas o indivíduo isolado. Função estratégica: sustentar a vantagem estrutural de intimidade identificada como diferencial competitivo central.
5. **Trajetória Contínua** — comunicação trata o campeonato como parte de uma temporada/jornada contínua, nunca como evento isolado. Função estratégica: criar o "calendário afetivo" identificado como oportunidade na Fase 1.
6. **Acesso com Prestígio** — comunicação demonstra alto padrão técnico sem intimidar iniciantes. Função estratégica: ampliar mercado endereçável sem abrir mão de diferenciação técnica.
7. **Bastidor Técnico Traduzido** — conteúdo educativo constante, sempre traduzindo tecnicidade em linguagem acessível. Função estratégica: resolver a lacuna de "existência categórica" identificada na Fase 2 — ensinar o público a entender e desejar o esporte.

---

## 16. EXPERIÊNCIA DA MARCA

**Antes:** o atleta e o público devem sentir expectativa contida — não hype explosivo, mas antecipação real, como quem sabe que algo importante está se aproximando e já está se preparando mentalmente para isso.

**Durante:** devem sentir tensão presente e testemunhada — a sensação de estar vendo algo genuíno acontecer, sem artificialismo, com atenção total dada a cada nome chamado.

**Depois (dias):** devem sentir reconhecimento concreto — a certeza de que o que fizeram foi visto, registrado e vai ser lembrado, não apenas arquivado silenciosamente.

**Meses depois:** devem sentir pertencimento contínuo — presença ativa em uma comunidade e em uma trajetória que continua entre uma edição e outra, não silêncio total até o próximo evento.

**Anos depois:** devem sentir que fazem parte de uma história maior — que seu nome, seus resultados e sua trajetória continuam acessíveis, contados, parte de um patrimônio que cresce, e que voltar não é reiniciar do zero, é continuar uma história já registrada.

---

## 17. SISTEMA SIMBÓLICO

- **Chamada do Nome** — ritual fixo em que cada atleta tem seu nome, cidade e box anunciados individualmente antes de iniciar sua série, sempre no mesmo formato, reconhecível edição após edição.
- **Livro de Nomes** — arquivo físico e digital permanente com o nome de todo atleta que já competiu, exposto fisicamente no local da prova e disponível publicamente online.
- **Peso Testemunha** — um kettlebell simbólico específico (não usado na competição), presente em todas as edições, que carrega gravações ou marcas relacionadas à história do campeonato — objeto físico de continuidade.
- **Última Respiração** — momento ritual de silêncio total imediatamente antes do início de cada série, para que o esforço sustentado seja percebido desde o primeiro segundo.
- **Cerimônia de Reconhecimento** — momento, ao final de cada edição, em que não apenas o pódio, mas atletas de diferentes categorias e histórias são chamados publicamente por nome.
- **Marca de Retorno** — reconhecimento visual (pin, patch ou elemento equivalente) para atletas que competem em múltiplas edições, tornando visível a continuidade da trajetória.
- **Momento do Box** — instante da cerimônia dedicado a reconhecer publicamente boxes e técnicos, não apenas atletas individuais.

Todos os elementos deste sistema simbólico são desenhados para reforçar, de forma concreta e repetível, a promessa central da marca — nada que é sustentado aqui desaparece sem ser visto e guardado.

---

## 18. PRINCÍPIOS DE DECISÃO

Filtro estratégico para qualquer decisão futura da organização — se uma decisão falha em qualquer um destes princípios, ela deve ser reconsiderada, independentemente de quão vantajosa pareça em outros aspectos:

1. Isso aumenta o controle da marca, ou aumenta o caos?
2. Isso guarda e registra algo, ou apaga e descarta?
3. Isso chama alguém pelo nome, ou trata alguém como número?
4. A escassez ou urgência envolvida aqui é real, ou é encenada?
5. Isso é possível de sustentar de forma consistente por 20 anos, ou é uma tendência passageira?
6. Isso fortalece camadas reais de pertencimento (atleta, técnico, box, cidade), ou apenas engajamento superficial?
7. Um iniciante entenderia e se sentiria bem-vindo, ou só um especialista entenderia?
8. Isso é fiel à personalidade definida (contida, precisa, madura), ou está imitando o tom de outro concorrente?
9. Essa decisão poderia ser copiada facilmente por qualquer outro evento, ou depende de algo genuinamente nosso (memória acumulada, comunidade real)?
10. Se essa decisão desse errado publicamente, a resposta seria compatível com nossos valores (controle, honestidade, transparência)?

---

## 19. TESTE DE CONSISTÊNCIA (AUDITORIA CRÍTICA)

**Inconsistências identificadas:**
- O valor "consistência ano após ano" pode entrar em tensão com a necessidade natural de melhoria operacional — é preciso deixar claro, em documentos futuros, que consistência se aplica a *elementos simbólicos centrais*, não a toda decisão operacional (logística, formato de transmissão, parcerias podem e devem evoluir).
- A promessa "seu nome não desaparece" exige infraestrutura real (arquivo histórico funcional, atualizado e acessível) que ainda não existe operacionalmente — a plataforma de marca está, neste momento, à frente da capacidade de execução. Isso não invalida a promessa, mas exige que a Fase 4 (execução) trate a construção desse arquivo como prioridade estrutural, não incidental.

**Clichês evitados, mas com risco residual:** frases como "coragem silenciosa" e "força que se sustenta" correm risco de soar poéticas demais se repetidas sem lastro concreto (rituais, arquivo, chamada de nomes). A plataforma mitiga isso ao amarrar cada conceito abstrato a um mecanismo físico e replicável (Capítulos 17 e 10) — mas a vigilância contra abstração vazia deve ser constante nas próximas fases.

**Promessas difíceis de cumprir:** a promessa a patrocinadores ("associação a um território emocional único e defensável") depende inteiramente da execução consistente de todos os outros capítulos — é uma promessa condicionada, não independente. Deve ser comunicada a patrocinadores com transparência sobre o estágio de maturidade do projeto.

**Elementos facilmente copiáveis:** o "Livro de Nomes" e a "Chamada do Nome" são ideias replicáveis por qualquer concorrente que decida copiá-las. O que não é copiável é o histórico acumulado ao longo dos anos — por isso, quanto antes esses rituais começarem a ser praticados de forma consistente, maior a vantagem competitiva construída (vantagem de tempo, não de ideia).

**Fragilidades:** a plataforma depende de execução emocionalmente sofisticada (tom contido, sem euforia) em um mercado de fitness que historicamente recompensa comunicação de alta intensidade — existe risco real de a execução futura (Fase 4 em diante) ceder à tentação de imitar o tom mais espalhafatoso de concorrentes por pressão de curto prazo. Este documento deve ser usado ativamente como filtro contra essa tentação.

**Melhorias incorporadas a partir desta auditoria:** os princípios de decisão do Capítulo 18 já incorporam perguntas diretas contra as fragilidades identificadas aqui (pergunta 5 protege contra modismo; pergunta 9 protege contra cópia fácil; pergunta 8 protege contra desvio de tom).

---

## 20. LEGADO

*Texto imaginado em 2050.*

Quando se pergunta hoje, em qualquer competição de kettlebell sport no mundo, por que este esporte finalmente conquistou um lugar cultural que antes não tinha, a resposta invariavelmente aponta para o mesmo lugar: o modelo brasileiro.

Não foi o maior orçamento. Não foi o maior número de inscritos no primeiro ano. Foi uma decisão simples, tomada ainda nos primeiros anos do campeonato, de tratar cada atleta como alguém que merecia ser chamado pelo nome — e de nunca abrir mão disso, edição após edição, mesmo quando crescer mais rápido teria sido mais fácil se abrisse mão dessa promessa.

O "Livro de Nomes", que começou como uma lista simples afixada ao lado da arena, tornou-se, décadas depois, o arquivo mais completo e mais citado da história do kettlebell sport mundial — não porque alguém planejou que se tornaria um monumento, mas porque, ano após ano, ninguém foi esquecido.

O que este campeonato provou, e que hoje é ensinado em outras federações como estudo de caso, é que um esporte de nicho não precisa competir em volume para se tornar permanente. Precisa apenas garantir, com disciplina absoluta, que tudo o que for sustentado por um atleta seja, de fato, guardado por quem estava assistindo.

Foi assim que a força silenciosa, que antes desaparecia sem testemunha, se tornou — em 2050 — uma das histórias mais respeitadas do esporte mundial.

---

## REVISÃO FINAL — CONSELHO INDEPENDENTE DE CINCO ESPECIALISTAS

**Especialista em Branding:** "A plataforma tem coerência interna rara — cada capítulo deriva logicamente do anterior, e a Big Idea consegue unificar tom, símbolo e promessa numa única frase. O risco que vejo é de excesso de sofisticação verbal: em execução real, times de marketing menos experientes podem diluir a sutileza do tom 'contido' e cair em clichê genérico de superação. Recomendo que a Fase 4 inclua um guia prático de aplicação da voz, com exemplos de 'certo' e 'errado' lado a lado."

**Especialista em Marketing Esportivo:** "Minha preocupação é de aquisição, não de retenção — essa plataforma é excelente para reter quem já está dentro, mas ainda depende de execução criativa forte (Fase 4/5) para resolver o problema de 'existência categórica' identificado na Fase 2. A plataforma, por si só, não traz ninguém novo para dentro — ela só garante que, quando alguém entrar, a experiência seja consistente e memorável. Isso é adequado para esta fase, mas não deve ser confundido com solução de aquisição."

**Psicólogo do Consumidor:** "O uso de nome próprio como mecanismo central de reconhecimento é psicologicamente muito bem fundamentado — reconhecimento nominal é um dos gatilhos mais fortes de vínculo emocional e retenção comportamental que existem, mais forte inclusive do que recompensa material. Um ponto de atenção: a promessa de 'nunca ser esquecido' cria uma expectativa alta que precisa ser sustentada tecnicamente (arquivo funcional, atualizado, de fácil acesso) — se a infraestrutura falhar mesmo uma vez, o dano à confiança será desproporcionalmente grande, justamente por ser uma promessa tão pessoal."

**Patrocinador (perspectiva de investimento):** "Como investidor, vejo uma marca com identidade defensável e difícil de confundir com concorrentes — isso reduz risco de diluição de imagem para minha marca. Minha ressalva é prática: preciso de métricas claras de alcance e conversão de território (não apenas de emoção) antes de comprometer investimento relevante. Recomendo que a próxima fase inclua indicadores objetivos de sucesso vinculados a cada pilar de comunicação, para que eu possa medir retorno, não apenas acreditar na narrativa."

**Atleta de Alto Rendimento:** "Do ponto de vista de quem compete, a promessa de ser chamado pelo nome e ter minha trajetória registrada é genuinamente diferente de qualquer coisa que já vivi em outras competições — a maioria dos eventos trata a gente como número de peito, não como história. Meu único receio é que, se o campeonato crescer rápido, essa atenção individual fique impossível de sustentar operacionalmente. Peço que isso seja levado a sério na fase de execução — a promessa é boa demais para ser quebrada por falta de planejamento logístico."

**Consolidação das críticas:** nenhuma crítica exige revisão do DNA ou da plataforma em si — todas apontam, de forma convergente, para o mesmo ponto de atenção: a plataforma é conceitualmente sólida, mas sua força depende inteiramente da qualidade de execução nas próximas fases (guia prático de voz, mecanismo de aquisição, infraestrutura de arquivo, métricas objetivas de território, planejamento logístico de escala). Este documento permanece como a versão definitiva da Plataforma de Marca; os pontos levantados pelo conselho ficam registrados como requisitos obrigatórios de atenção para a Fase 4.

---

*Fim da Plataforma de Marca — Fase 3. Documento oficial, fundamentado nas Fases 1 e 2, para orientar todas as decisões futuras de comunicação, identidade visual, campanhas, patrocínio, eventos, experiências, produtos e relacionamento do Campeonato Brasileiro de Kettlebell Sport.*
