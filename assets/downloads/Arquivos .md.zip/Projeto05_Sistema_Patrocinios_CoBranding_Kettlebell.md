# PROJETO 05 — SISTEMA DE PATROCÍNIOS E CO-BRANDING
### Campeonato Brasileiro de Kettlebell Sport
### Constituição Permanente do Ecossistema Comercial

*Fases 1-6 e Projetos 01-04 são Constituição definitiva e têm prioridade absoluta sobre qualquer regra aqui contida. Este documento não cria propostas comerciais — cria as regras permanentes que protegem simultaneamente marca, patrocinador, atleta, público e sustentabilidade financeira do campeonato.*

---

## FILOSOFIA GERAL

O patrocinador não compra espaço. Compra participação em uma instituição — na linguagem já estabelecida pela Big Idea da Fase 3 ("o que você sustenta, a gente guarda"), o patrocinador é chamado, institucionalmente, de **guardião**: alguém que ajuda a sustentar a estrutura que guarda a memória do esporte. A marca do campeonato nunca é vendida — é compartilhada sob regras claras, mensuráveis e protegidas por veto formal.

---

## 1. FILOSOFIA DO PATROCÍNIO

**Por que existe patrocinador:** para viabilizar financeiramente o cumprimento da missão definida na Fase 3 (dar palco, nome e memória à força que se sustenta) em escala sustentável, sem depender exclusivamente de inscrição de atletas.

**Papel institucional:** o patrocinador é parte do Sistema de Patrocinadores definido na Fase 5 — um dos sistemas permanentes do ecossistema, não um apêndice comercial.

**O que significa apoiar o campeonato:** significa associar-se publicamente aos valores da Fase 3 (controle, honestidade competitiva, memória, pertencimento) — a associação é sempre bilateral: o patrocinador empresta recursos e credibilidade comercial; o campeonato empresta território emocional único e comunidade genuína.

**Como o patrocinador fortalece a missão:** cada real investido deve, direta ou indiretamente, fortalecer um dos seis pilares definidos na filosofia geral (autenticidade, memória, permanência, reconhecimento, confiança, legitimidade) — nunca apenas exposição de logotipo desconectada desses pilares.

---

## 2. ARQUITETURA COMERCIAL — SISTEMA DE NÍVEIS

| Nível | Função | Proximidade à marca |
|---|---|---|
| **Naming Rights (estrutural, não do nome do campeonato)** | Nomeação de elementos físicos específicos (ex: arena, palco) — nunca do nome institucional do campeonato. | Alta, mas estritamente limitada (ver Capítulo 9). |
| **Patrocinador Master** | Maior nível de investimento e maior nível de exposição permitida. | Alta — espaço proporcionalmente maior em todos os pontos de contato do Capítulo 5. |
| **Patrocinador Ouro** | Segundo nível, com exclusividade de categoria disponível. | Média-alta. |
| **Patrocinador Prata** | Terceiro nível, sem exclusividade automática de categoria. | Média. |
| **Patrocinador Bronze** | Nível de entrada comercial. | Baixa-média. |
| **Parceiros** | Instituições que contribuem com recursos não financeiros (estrutura, conhecimento técnico, validação institucional). | Variável, definida por acordo específico. |
| **Apoiadores** | Contribuição pontual ou regional (ex: eventos paralelos da Fase 5). | Baixa, localizada. |
| **Fornecedores Oficiais** | Provedores de produtos/serviços utilizados operacionalmente (equipamento, tecnologia). | Funcional, não emocional — reconhecimento técnico, não território de marca. |
| **Instituições (públicas/educacionais)** | Parcerias de legitimidade e infraestrutura. | Institucional, tratada pelo Sistema de Parceiros da Fase 5, não pelo comercial. |
| **Parceiros Técnicos** | Organizações ligadas a arbitragem, certificação, educação (Fase 5). | Técnica, não comercial. |
| **Comunidades (boxes)** | Presença territorial e de pertencimento (Fase 5), não patrocínio comercial. | Estrutural, fora da lógica de cotas financeiras. |

---

## 3. DIREITOS DE MARCA

**Quem pode usar:** exclusivamente patrocinadores, parceiros e fornecedores com contrato formal vigente, dentro do nível contratado.

**Como usar:** estritamente conforme as regras de co-branding do Brand Book (Projeto 04, Capítulo 6) — nenhuma adaptação, recorte ou modificação dos elementos da marca é permitida.

**Onde usar:** apenas nos pontos de contato explicitamente listados na matriz de exposição do Capítulo 5, conforme o nível contratado.

**Quando usar:** exclusivamente durante o período de vigência contratual, com uma janela de transição de desuso definida em contrato (nunca uso indefinido pós-contrato).

**O que nunca pode fazer:** sublicenciar a terceiros sem aprovação; sugerir endosso pessoal de um atleta a um produto sem acordo individual separado com esse atleta; alterar qualquer elemento visual da marca; reivindicar exclusividade não formalmente concedida; usar qualquer elemento simbólico protegido (Capítulo 5) sob nenhuma circunstância.

**Tempo de uso e restrições:** definidos contrato a contrato, nunca superiores ao período de vigência mais a janela de transição.

**Revogação:** qualquer violação identificada aciona o processo formal descrito no Capítulo 10 (Sistema Jurídico), com possibilidade de suspensão imediata de uso em casos de dano reputacional grave, mediante decisão da Governança de Marca.

---

## 4. SISTEMA DE CO-BRANDING

**Distâncias e espaçamento:** mínimo de 2U (Projeto 04, Capítulo 3) de separação entre o lockup do campeonato e qualquer logotipo de patrocinador, independentemente do nível.

**Hierarquia:** em qualquer aplicação própria do campeonato, o logotipo da marca é sempre dominante; patrocinadores nunca dividem posição de igual destaque, mesmo no nível Master.

**Escalas por nível (proporção relativa ao símbolo do campeonato):** Master até 1x a largura do símbolo · Ouro até 0.75x · Prata até 0.5x · Bronze até 0.35x · demais níveis conforme acordo específico, sempre abaixo de Bronze em proeminência visual.

**Alinhamento:** logotipos de patrocinador sempre alinhados a uma zona secundária fixa (rodapé, lateral, área designada), nunca centralizados ou competindo pela mesma centralidade da marca principal.

**Proteção visual:** aplicação de patrocinador exige campo neutro (Osso ou Ferro sólido, Projeto 04, Capítulo 6) — nunca sobreposição direta a fotografia de atleta ou a elementos rituais simbólicos.

**Proteção institucional:** nenhum logotipo de patrocinador pode, em qualquer circunstância, entrar na área de proteção do símbolo do campeonato (Projeto 03/04).

**Casos permitidos:** menção "apresentado por" em materiais institucionais e de abertura de transmissão; presença em backdrop conforme espaçamento definido (Projeto 04, Capítulo 12); presença em materiais de patrocínio específicos.

**Casos proibidos:** fusão de logotipos em um único símbolo; presença de patrocinador em qualquer elemento do Sistema Simbólico protegido (Capítulo 5); alteração de cor do logotipo do campeonato para "combinar" com a identidade visual de um patrocinador.

---

## 5. SISTEMA DE EXPOSIÇÃO

**Princípio constitucional inegociável:** os elementos rituais definidos na Fase 3 (Capítulo 17) — Chamada do Nome, Livro de Nomes, Última Respiração, Cerimônia de Reconhecimento — são **permanentemente protegidos de qualquer aplicação comercial**, em qualquer nível de patrocínio, sem exceção. Nenhum valor de contrato altera essa regra.

| Ponto de contato | Master | Ouro | Prata | Bronze | Fornecedores |
|---|---|---|---|---|---|
| Arena (espaço geral, fora dos rituais protegidos) | Sim | Sim | Sim | Sim | Não |
| Backdrop de entrevistas | Sim | Sim | Sim | Não | Não |
| Site (área institucional) | Sim | Sim | Sim | Sim | Menção técnica |
| Lives/streaming (abertura/intervalos) | Sim | Sim | Não | Não | Não |
| Redes sociais (conteúdo institucional) | Sim | Sim | Sim | Não | Não |
| Credenciais | Sim | Sim | Não | Não | Não |
| Camisas/uniformes (aplicação discreta, Projeto 04 Cap.14) | Sim | Sim | Não | Não | Não |
| Banners/painéis | Sim | Sim | Sim | Sim | Não |
| Pódio | Sim | Não | Não | Não | Não |
| Medalhas/certificados | **Nunca** (elemento simbólico protegido) | — | — | — | — |
| Área VIP | Sim | Sim | Não | Não | Não |
| Materiais impressos institucionais | Sim | Sim | Sim | Sim | Menção técnica |
| Brindes/merchandising oficial | Sim | Sim | Sim | Não | Não |
| Publicidade paga externa (co-branded) | Sim | Sim | Não | Não | Não |

---

## 6. SISTEMA DE EXCLUSIVIDADE

**Categorias exclusivas:** disponíveis apenas para os níveis Master e Ouro, mediante contrato específico e por categoria de produto/serviço claramente definida (ex: "bebida esportiva oficial").

**Conflitos e concorrentes:** dois patrocinadores da mesma categoria não coexistem simultaneamente em nenhum nível, mesmo que um deles não tenha exclusividade contratada — a Governança Comercial (Capítulo 19) resolve prioridade por ordem de contrato vigente.

**Coexistência:** patrocinadores de categorias distintas coexistem livremente em todos os níveis, respeitando apenas as regras de espaçamento e hierarquia do Capítulo 4.

**Limites da exclusividade:** a exclusividade de categoria nunca se estende a impedir patrocínios pessoais dos próprios atletas (direito individual do atleta, protegido separadamente), nem a controlar conteúdo editorial da marca.

**Exceções:** avaliadas exclusivamente pela Governança de Marca, nunca pelo núcleo comercial isoladamente.

---

## 7. SISTEMA DE CONTRAPARTIDAS

- **Exposição:** conforme matriz do Capítulo 5.
- **Conteúdo:** produção de conteúdo institucional (Sistema de Comunicação, Projeto 01) mencionando o patrocinador, sempre revisado pelo checklist de comunicação antes de publicação.
- **Ativações:** conforme regras do Capítulo 8.
- **Experiências e hospitalidade:** acesso a área VIP (níveis Master/Ouro), convites para presença institucional no evento.
- **Networking:** encontros institucionais organizados entre patrocinadores e liderança do campeonato.
- **Direitos digitais:** acesso a banco de mídia oficial (Capítulo 16), com direitos de uso definidos contratualmente, nunca perpétuos ou irrestritos.
- **Uso de imagem:** nunca inclui uso da imagem de atletas específicos sem acordo individual separado entre patrocinador e atleta — a marca não comercializa a imagem de terceiros em nome próprio.
- **Convites e área técnica:** acesso limitado e sempre subordinado à integridade da competição, nunca interferindo na operação técnica ou na experiência do atleta durante a prova.

---

## 8. SISTEMA DE ATIVAÇÕES

**Como uma ativação deve funcionar:** deve reforçar a experiência do público e da comunidade, nunca competir por atenção com os momentos rituais protegidos (Capítulo 5).

**O que fortalece a experiência:** ativações experienciais e educativas (ex: apresentação de tecnologia relevante ao esporte) têm prioridade sobre distribuição passiva de brindes genéricos.

**O que prejudica:** qualquer ativação que interrompa, sonora ou visualmente, o momento de competição; qualquer ativação que force interação de atleta com marca sem consentimento prévio individual.

**Limites:** nenhuma ativação comercial ocorre durante a Chamada do Nome, a Última Respiração ou a Cerimônia de Reconhecimento — janelas de silêncio comercial absoluto.

**Boas práticas:** ativações que gerem valor real para o espectador (conteúdo, experiência, utilidade) são priorizadas sobre ativações puramente promocionais.

**Interação com atletas e público:** sempre opcional para o atleta, nunca imposta por contrato de patrocínio; interação com público deve ser genuína e não invasiva do espaço de torcida e reconhecimento.

---

## 9. SISTEMA DE NAMING RIGHTS

**Quando permitir:** exclusivamente para elementos físicos e estruturais específicos (ex: "Arena [Patrocinador]", "Palco Técnico [Patrocinador]") — nunca para o nome institucional do campeonato, que é elemento constitucional protegido desde a Fase 3 e não está disponível para naming rights sob nenhuma circunstância ou valor de contrato.

**Quando negar:** qualquer proposta que substitua, incorpore ou modifique "Campeonato Brasileiro de Kettlebell Sport" no nome oficial do evento ou de qualquer elemento do Sistema Simbólico protegido (Capítulo 5).

**Limites e modelo máximo permitido:** a forma mais próxima de naming rights disponível é a fórmula "apresentado por", associada ao nível Master, aplicada apenas em contextos institucionais definidos (abertura de transmissão, materiais de imprensa) — nunca substituindo o nome em uso corrente pela comunidade.

**Proteção da identidade:** qualquer proposta de naming rights, mesmo estrutural, exige aprovação explícita da Governança de Marca antes de qualquer negociação comercial avançar.

**Hierarquia:** naming rights estrutural nunca supera, em destaque visual, o nome e o símbolo do campeonato em nenhuma aplicação.

---

## 10. SISTEMA JURÍDICO

**Proteção de marca:** registro formal de marca (já previsto na Governança Visual, Projeto 03/04) é pré-requisito para qualquer negociação comercial relevante.

**Licenciamento:** todo uso da marca por patrocinador é regido por contrato formal de licenciamento de uso, com escopo, prazo e território de aplicação explicitamente definidos.

**Uso indevido:** identificado o uso fora do contratado, o processo formal é: notificação escrita → prazo de correção → suspensão temporária de uso → rescisão contratual em caso de reincidência ou gravidade.

**Cancelamento:** pode ocorrer por iniciativa de qualquer das partes, conforme cláusulas contratuais, ou por decisão da Governança de Marca em caso de dano reputacional (Capítulo 17).

**Sanções:** proporcionais à gravidade da violação, desde advertência formal até rescisão com possível ação de reparação, conforme legislação aplicável.

**Direitos e obrigações:** formalizados em contrato individual, sempre subordinados às regras permanentes deste documento — nenhum contrato pode conceder direito superior ao que este sistema permite.

---

## 11. SISTEMA FINANCEIRO

*(Consistente com a Fase 6, este sistema não fixa valores absolutos sem estudo financeiro específico de mercado — define estrutura e critérios, não cifras.)*

**Estrutura de cotas:** proporcional entre níveis (referência relativa: Bronze = 1x · Prata ≈ 2-3x · Ouro ≈ 5-8x · Master ≈ 12-20x, a calibrar com o estudo financeiro previsto na Fase 6, Capítulo 8).

**Critérios de precificação:** exposição contratada (Capítulo 5), exclusividade de categoria (Capítulo 6), duração do contrato, e nível de acesso a ativações (Capítulo 8).

**Duração:** contrato mínimo sugerido de um ciclo de edição completo, com incentivo explícito a contratos multianuais — coerente com o valor de "trajetória contínua" (Fase 3) também aplicado à relação comercial.

**Renovação:** patrocinadores com histórico de avaliação positiva (Capítulo 13) têm prioridade formal de renovação antes de qualquer nova negociação com terceiros na mesma categoria.

**Escalonamento:** valor de cota pode crescer ano a ano proporcionalmente ao crescimento de indicadores do campeonato (Fase 6, Capítulo 10), nunca de forma arbitrária.

**Prioridade a patrocinadores fundadores:** os primeiros patrocinadores do campeonato recebem reconhecimento formal de "guardiões fundadores", incluindo registro no Sistema de Memória (Fase 5) como parte da história institucional — aplicação literal da Big Idea também à relação comercial.

**Reajustes:** anuais, indexados a critério formalizado em contrato (nunca renegociação unilateral fora do ciclo contratual).

**Benefícios por nível:** conforme matriz do Capítulo 5 e contrapartidas do Capítulo 7.

---

## 12. SISTEMA DE APROVAÇÃO

**Fluxo completo:**
1. Triagem inicial pelo núcleo comercial contra o checklist de alinhamento de marca (já previsto na Fase 6, Projeto P10).
2. Revisão jurídica do contrato proposto (Capítulo 10).
3. Aprovação da Governança de Marca, com poder de veto sobre qualquer associação incompatível com a Constituição do projeto.
4. Assinatura formal pelo Diretor Executivo (Fase 6), com validação expressa da Governança de Marca obrigatória para os níveis Master, Ouro e Naming Rights.

**Quem pode negociar:** exclusivamente o núcleo comercial formalmente designado (Diretor Comercial, Fase 6).
**Quem revisa:** jurídico responsável e Diretor de Marca.
**Quem aprova:** Governança de Marca (poder de veto) e Diretor Executivo (aprovação final).
**Quem assina:** Diretor Executivo, com contra-assinatura da Governança de Marca em contratos de alto nível.

---

## 13. SISTEMA DE AVALIAÇÃO

- **ROI institucional:** variação em menções espontâneas de imprensa/redes que associam corretamente o patrocinador ao território de marca (linguagem oficial, Projeto 01, Capítulo 6).
- **ROI financeiro:** retorno percebido pelo patrocinador conforme métricas comerciais tradicionais, traduzidas a partir dos indicadores de profundidade (já formalizado como pendência de anexo comercial nas Fases 4 e 6).
- **Impacto na marca:** auditoria de consistência de aplicação do patrocinador conforme checklist do Capítulo 18.
- **Impacto na comunidade:** pesquisa qualitativa periódica sobre percepção da comunidade em relação à presença do patrocinador — rejeição da comunidade é sinal de alerta formal, mesmo com contrato em dia.
- **Retenção:** taxa de renovação de contrato, já indicador oficial desde a Fase 6.
- **Satisfação:** pesquisa formal com o patrocinador ao final de cada ciclo contratual, usada como insumo direto para a decisão de renovação.

---

## 14. SISTEMA DE RECUSA

**Empresas que nunca poderão patrocinar, independente de valor oferecido:**
- Empresas de tabaco e de substâncias/métodos proibidos por entidades antidoping reconhecidas.
- Empresas de apostas não regulamentadas pela legislação brasileira vigente.
- Empresas com histórico comprovado e não remediado de violação trabalhista ou ambiental grave.
- Marcas cujo posicionamento público contradiz frontalmente os valores da Fase 3 (ex: discurso de ódio, discriminação, ou comunicação fundamentalmente incompatível com o valor de "controle acima do caos").

**Critérios éticos gerais:** qualquer empresa avaliada passa pelo checklist de alinhamento (Capítulo 18) antes de qualquer negociação avançar — a recusa por critério ético é decisão da Governança de Marca, não apenas do núcleo comercial.

**Conflitos:** categoria já ocupada por patrocinador com exclusividade vigente (Capítulo 6).

**Casos especiais:** zonas cinzentas (empresas sem histórico claro de violação, mas com reputação controversa) são sempre avaliadas caso a caso pela Governança de Marca, nunca aprovadas automaticamente pelo núcleo comercial.

---

## 15. SISTEMA INTERNACIONAL

**Patrocínio estrangeiro:** permitido, sujeito às mesmas regras deste documento, sem exceção por porte ou nacionalidade da empresa.

**Empresas multinacionais:** avaliadas pelos mesmos critérios de qualquer patrocinador nacional — porte não concede tratamento preferencial automático fora da estrutura de níveis já definida (Capítulo 2).

**Parceiros internacionais (federações estrangeiras):** regidos pelo Sistema de Parceiros institucionais da Fase 5, não pelo Sistema Comercial — parceria técnica é tratada separadamente de patrocínio financeiro.

**Coexistência entre países:** relevante apenas no cenário de expansão internacional previsto na Fase 5 (Capítulo 9) — nesse caso, a futura "constituição simbólica" de expansão internacional também regerá naming rights e patrocínio local, mantendo os mesmos princípios aqui definidos como base inegociável.

---

## 16. SISTEMA DIGITAL

**Redes sociais:** presença de patrocinador limitada aos espaços institucionais definidos no Capítulo 5, nunca em conteúdo do território "Duelo Testemunhado" ou de descoberta pura (Projeto 02), que devem permanecer livres de qualquer associação comercial direta para preservar autenticidade.

**Lives/streaming:** menção/tela de abertura e intervalos técnicos, nunca sobreposição visual durante o momento real de competição.

**Podcast/aplicativo/website:** aplicação restrita a áreas institucionais claramente delimitadas (nunca na página do Livro de Nomes, elemento protegido).

**Banco de mídia:** patrocinadores de níveis Master/Ouro recebem acesso a banco de imagens e vídeos oficiais, com direitos de uso definidos contratualmente (prazo, finalidade, território) — nunca direitos irrestritos ou perpétuos.

**Downloads:** materiais institucionais oficiais disponibilizados apenas na versão e nível de acesso previstos em contrato.

---

## 17. SISTEMA DE CRISES

**Cancelamento de patrocínio:** processo formal e comunicado com transparência, seguindo os princípios de gestão de crise já definidos no Projeto 01, Capítulo 12 (controle, não caos).

**Mudança de patrocinador:** transição planejada para minimizar impacto na identidade e na experiência da comunidade, nunca abrupta sem comunicação prévia.

**Escândalos envolvendo patrocinador:** aciona imediatamente o processo de revogação do Capítulo 3/10; a dissociação pública é rápida, clara e alinhada ao valor de controle — sem espetáculo defensivo, sem silêncio prolongado.

**Falência ou inadimplência de patrocinador:** o sistema é desenhado, desde a Fase 5 (Capítulo 8), para nunca depender de um único patrocinador — mitigação estrutural preexistente reaplicada aqui.

**Troca de naming rights:** processo formal, comunicado com antecedência, nunca uma mudança repentina e não explicada de nome de elemento estrutural.

**Reposicionamento:** qualquer mudança de tom ou categoria de patrocínio segue o mesmo funil de aprovação do Capítulo 12, sem atalhos por urgência comercial.

---

## 18. CHECKLIST COMERCIAL

**Critérios obrigatórios (eliminatórios se ausentes):**
1. A empresa não está na lista de recusa do Capítulo 14. [crítico]
2. Não há conflito de categoria com patrocinador de exclusividade vigente. [crítico]
3. O contrato respeita a matriz de exposição do Capítulo 5, sem incluir elementos rituais protegidos. [crítico]
4. O contrato foi revisado juridicamente (Capítulo 10). [crítico]
5. A aplicação visual proposta respeita o Sistema de Co-branding (Capítulo 4). [crítico]
6. A Governança de Marca aprovou formalmente (Capítulo 12). [crítico]

**Checklist jurídico:** escopo, prazo, território e direitos de imagem claramente definidos em contrato.
**Checklist visual:** conforme Projeto 04, Capítulo 18, aplicado especificamente às peças de co-branding.
**Checklist institucional:** compatibilidade com valores da Fase 3 confirmada.
**Checklist financeiro:** cota compatível com a estrutura do Capítulo 11, sem desconto informal fora de processo formal de negociação.

---

## 19. GOVERNANÇA COMERCIAL

**Quem administra:** núcleo comercial, liderado pelo Diretor Comercial (Fase 6), responsável pela operação do dia a dia dentro das regras deste documento.
**Quem altera este documento:** exclusivamente a Governança de Marca, com o Diretor de Marca como responsável técnico principal — nenhuma alteração de regra comercial permanente é feita unilateralmente pelo núcleo comercial.
**Como registrar mudanças:** changelog formal, versionado, seguindo a mesma lógica de nomenclatura de arquivos definida no Projeto 04, Capítulo 17.
**Versionamento:** este documento nunca é sobrescrito — toda revisão gera nova versão numerada, preservando histórico completo.
**Proteção institucional:** nenhum acordo comercial entra em vigor sem ter passado pelo fluxo completo do Capítulo 12 — não existe exceção por urgência financeira, conforme já reforçado como princípio desde o Master Plan (Fase 6).

---

## AUDITORIA ESTRATÉGICA — CONSELHO DE ONZE ESPECIALISTAS (CICLO ITERATIVO)

### Rodada 1 — críticas técnicas

**Branding:** "A proteção absoluta dos elementos rituais (Capítulo 5) contra qualquer aplicação comercial, sem exceção de valor, é a decisão mais importante deste documento — é isso que impede que pressão financeira futura corroa lentamente a identidade construída desde a Fase 3."

**Marketing Esportivo:** "A estrutura de níveis (Capítulo 2) é clara e comercialmente competitiva. Ponto de atenção: não há menção a um nível de patrocínio específico para public relations/mídia (ex: 'emissora oficial' ou 'parceiro de transmissão'), que costuma ter dinâmica diferente de patrocínio financeiro tradicional."

**Direito Empresarial:** "O sistema jurídico (Capítulo 10) está bem estruturado, mas falta menção a cláusula de força maior e a jurisdição/foro aplicável em caso de disputa — elementos padrão de qualquer contrato comercial de porte, ausentes aqui."

**Licenciamento:** "Os direitos de marca (Capítulo 3) e o banco de mídia (Capítulo 16) estão bem amarrados. Recomendo apenas que fique explícito se o direito de uso do banco de mídia sobrevive ao fim do contrato para peças já publicadas antes do encerramento (uso retroativo) ou se cessa integralmente."

**Eventos:** "O Sistema de Ativações (Capítulo 8) protege bem a experiência do público, mas não define um processo prático de aprovação prévia de cada ativação específica antes do dia do evento — hoje o documento define princípios, mas não o fluxo de aprovação pontual."

**Patrocínio:** "A escala proporcional de cotas (Capítulo 11) é uma solução honesta para a ausência de dados de mercado, consistente com a Fase 6. Recomendo apenas registrar, aqui também, que o estudo financeiro específico (já pendência da Fase 6) deve calibrar esses multiplicadores antes da primeira negociação real."

**Experiência de Marca:** "O silêncio comercial absoluto durante os momentos rituais (Capítulo 8) é um diferencial competitivo real — poucos eventos esportivos protegem isso formalmente. Nenhuma crítica estrutural."

**Finanças:** "Concordo com o ponto de Patrocínio. Adicionalmente, o sistema de reajuste (Capítulo 11) menciona indexação 'a critério formalizado em contrato', mas não sugere um índice de referência padrão (ex: inflação oficial) — isso deveria ao menos ser citado como prática recomendada padrão."

**Gestão Comercial:** "O fluxo de aprovação (Capítulo 12) está correto e protege contra decisão unilateral. Recomendo apenas SLA (prazo máximo) para cada etapa do fluxo, para que o processo de proteção não se torne, na prática, lento demais para negociações comerciais reais."

**Comunicação Institucional:** "A forma como o sistema integra com o Projeto 01 (Capítulo 13, tradução de indicadores) está coerente. Nenhuma inconsistência nova identificada."

**Atletas:** "Fico tranquilo ao ver, de forma explícita, que nenhuma ativação pode forçar minha interação com um patrocinador sem meu consentimento, e que meu direito de imagem pessoal é tratado separadamente do patrocínio institucional. Isso protege atletas de uma prática comum e problemática em outros eventos."

### Ajustes incorporados após a Rodada 1

- **Capítulo 2** passa a incluir um nível adicional: **Parceiro de Transmissão/Mídia**, com regras próprias de exposição (a serem detalhadas em contrato específico, dado seu formato diferente de patrocínio financeiro tradicional).
- **Capítulo 10** passa a registrar como padrão contratual obrigatório a inclusão de cláusula de força maior e definição de foro/jurisdição em todo contrato de patrocínio.
- **Capítulo 16** passa a especificar que o direito de uso do banco de mídia para peças já publicadas antes do fim do contrato é preservado (uso retroativo), mas a produção de novo conteúdo com a marca cessa integralmente ao final da vigência.
- **Capítulo 8** passa a prever um processo formal de aprovação prévia de cada ativação específica, com prazo mínimo de antecedência antes do evento, a ser detalhado operacionalmente na fase de execução.
- **Capítulo 11** passa a registrar explicitamente que os multiplicadores de cota apresentados são provisórios até a calibração pelo estudo financeiro específico já pendente desde a Fase 6, e passa a recomendar um índice oficial de inflação como referência padrão de reajuste, salvo acordo contratual diferente.
- **Capítulo 12** passa a prever prazo máximo (SLA) para cada etapa do fluxo de aprovação, a ser formalizado operacionalmente, evitando que o processo de proteção se torne inviável comercialmente por lentidão.

### Rodada 2 — segunda leitura crítica após ajustes

**Marketing Esportivo:** "A inclusão do nível de Parceiro de Transmissão resolve a lacuna que apontei — meu ponto está integralmente endereçado."

**Direito Empresarial:** "Cláusula de força maior e foro/jurisdição agora estão formalmente previstos como padrão contratual. Nenhuma nova inconsistência jurídica estrutural identificada."

**Gestão Comercial e Finanças (avaliação conjunta):** "O SLA de aprovação e a recomendação de índice de reajuste padrão resolvem nossas objeções práticas. O sistema está pronto para orientar negociações reais, com as pendências corretamente registradas para calibração futura (estudo financeiro, detalhamento operacional de SLA)."

**Consolidação final:** a segunda rodada não identificou nenhuma inconsistência estrutural relevante remanescente. As pendências restantes (calibração financeira exata, detalhamento operacional de SLA e de fluxo de aprovação de ativações pontuais) são, corretamente, questões de especificação futura de execução, não de decisão constitucional em aberto — e estão formalmente registradas neste documento como tal. O ciclo iterativo é encerrado nesta rodada.

---

*Fim do Projeto 05 — Sistema de Patrocínios e Co-branding. Documento oficial, fundamentado nas Fases 1-6 e nos Projetos 01-04, servindo como Constituição Permanente do Ecossistema Comercial do Campeonato Brasileiro de Kettlebell Sport.*
