# MANUAL DO FORMULÁRIO DE MANIFESTAÇÃO DE INTERESSE
### Campeonato Brasileiro de Kettlebell Sport
### Manual Operacional Permanente

*Opera dentro dos princípios do Projeto 10 (Lançamento e Mobilização) e do Projeto 11 (Inteligência Pré-Inscrição), e de toda a Constituição anterior — sem autoridade para alterar nenhum princípio já estabelecido. Este manual não define plataforma, layout ou pergunta final — define o sistema que qualquer formulário futuro, em qualquer tecnologia, deve seguir.*

---

## 1. FILOSOFIA DO FORMULÁRIO

**Objetivo:** o formulário não existe para coletar dados — existe para dar início a um relacionamento. O primeiro contato formal entre uma pessoa interessada e o campeonato deve parecer o começo de algo, não o preenchimento de um cadastro.

**Papel institucional:** é o ponto de entrada oficial da Jornada do Interessado já definida no Projeto 11 (Capítulo 3) — a primeira aplicação prática e tangível da promessa "você sustenta, nós guardamos" (Fase 3), porque é aqui que um nome passa a existir formalmente no sistema.

**Como fortalece a comunidade:** cada resposta é tratada como uma pequena contribuição à construção coletiva do campeonato, nunca como extração unilateral de dado para benefício exclusivo da organização.

**Como protege a marca:** mantendo, mesmo em um formulário técnico, o mesmo tom contido e humano definido no Sistema de Comunicação (Projeto 01) — um formulário frio ou burocrático quebra a promessa de marca tão certeiramente quanto qualquer peça de comunicação malfeita.

**O que nunca pode acontecer:** o interessado sentir que está preenchendo um cadastro genérico; qualquer pergunta sem propósito declarado (mesmo princípio do Projeto 11, Capítulo 1); qualquer atleta já conhecido pelo Sistema de Memória ser tratado como estranho.

---

## 2. ARQUITETURA GERAL

**Estrutura:** o formulário é dividido em micro-etapas curtas, nunca uma página longa e única — aplicação direta do princípio de coleta progressiva já definido no Projeto 11, Capítulo 4.

**Fluxo:** cada etapa corresponde a um momento da Jornada do Usuário (Capítulo 3), nunca uma simples sequência arbitrária de campos.

**Progressão:** indicador de progresso visível, mas discreto — nunca usado como mecanismo de pressão ou gamificação artificial (o que contradiria os princípios éticos do Projeto 10, Capítulo 16).

**Princípio geral:** uma decisão por tela sempre que possível — reduzindo carga cognitiva e permitindo que o interessado avance em seu próprio ritmo, inclusive em múltiplas sessões.

---

## 3. JORNADA DO USUÁRIO

1. **Primeiro contato:** pedido mínimo — nome e uma forma de contato, nada além disso (Projeto 11, Capítulo 4).
2. **Preenchimento:** continuação progressiva, podendo ocorrer em múltiplas sessões, sem perda de progresso já realizado.
3. **Confirmação:** mensagem simples e pessoal (Capítulo 7), nunca uma tela genérica de "formulário enviado com sucesso".
4. **Acompanhamento:** contato leve e espaçado, nunca invasivo, mantendo a pessoa informada sem pressão.
5. **Atualização:** possibilidade permanente de revisar e completar informações, disponível a qualquer momento (mesmo princípio de autoatualização do Projeto 11, Capítulo 5).
6. **Conversão em inscrição:** os dados já coletados alimentam diretamente o processo de inscrição — nunca exigindo que a pessoa informe novamente o que já foi dito.

---

## 4. ARQUITETURA DAS PERGUNTAS

**Obrigatórias:** nome e um meio de contato — o mínimo absoluto para que o relacionamento comece a existir.

**Opcionais:** todos os demais campos definidos na tabela do Projeto 11, Capítulo 4 — sempre comunicados como opcionais, nunca disfarçados de obrigatórios.

**Condicionais:** perguntas que só aparecem conforme respostas anteriores (ex: "box" só é perguntado se a pessoa já indicar que treina atualmente; "hospedagem" só é perguntado quando a decisão de participar já está mais madura).

**Perguntas futuras:** campos reservados para necessidades ainda não ativas (ex: interesse em edições internacionais), documentados aqui como possibilidade, mas não implementados até que exista propósito real e aprovado.

**Perguntas que nunca devem existir:** qualquer campo sem função clara em algum sistema constitucional já existente (Projeto 11, Capítulo 1); qualquer dado sensível sem finalidade explícita; qualquer pergunta redundante a quem já está no Sistema de Memória.

---

## 5. ORDEM DA COLETA

**Primeiro:** nome, contato, estado e cidade — maior valor preditivo com menor fricção (Projeto 11, Capítulo 4).

**Depois:** categoria pretendida, modalidade, experiência prévia (primeira participação ou recorrente) — perguntado apenas quando a pessoa já tem essa decisão em formação.

**Perto da abertura das inscrições:** provas pretendidas, dias de permanência, necessidade de hospedagem e transporte, quantidade de acompanhantes — dados que exigem decisão mais madura e por isso são coletados mais tarde no relacionamento.

**Quando interromper a coleta:** ao primeiro sinal de hesitação ou abandono — o formulário nunca força conclusão, sempre salva o progresso parcial automaticamente.

**Quando retomar:** por meio de um único lembrete gentil, nunca uma sequência insistente de contatos — coerente com os limites éticos já definidos no Projeto 10, Capítulo 16.

---

## 6. PRINCÍPIOS DE UX

**Tempo máximo desejável:** a primeira etapa (Capítulo 5) deve ser completável em menos de um minuto — qualquer etapa além disso é redesenhada.

**Quantidade de perguntas por etapa:** entre duas e quatro, nunca mais — evitando sobrecarga cognitiva.

**Agrupamento:** perguntas de mesmo tema aparecem juntas, nunca misturadas com temas não relacionados.

**Progressão:** visível, mas nunca opressiva ou usada como gatilho de urgência.

**Feedback:** confirmação imediata de que cada resposta foi recebida corretamente.

**Redução de atrito:** preenchimento automático sempre que tecnicamente possível, nenhum campo obrigatório além do estritamente necessário (Capítulo 4).

**Acessibilidade:** conforme os padrões já definidos no Brand Book (Projeto 04, Capítulo 16) — contraste, tamanho de fonte, navegação por teclado.

**Versão mobile:** desenhado mobile-first, já que a maior parte do público chega por redes sociais em dispositivo móvel (coerente com o Sistema de Redes Sociais, Projeto 04, Capítulo 11).

---

## 7. UX WRITING

**Princípios da escrita:** direta, humana, nunca burocrática — mesmo tom contido e preciso do Sistema de Comunicação (Projeto 01, Capítulo 5), aplicado até ao texto mais funcional de um campo de formulário.

**Tom de voz:** idêntico ao definido constitucionalmente — nenhuma "voz de formulário" genérica e separada da voz da marca.

**Microcopy:** curto e claro, sempre explicando o motivo de uma pergunta quando não for óbvio (reforça transparência, Projeto 11, Capítulo 13).

**Mensagens de ajuda:** explicam o propósito da pergunta em uma frase simples — nunca jargão técnico desnecessário.

**Mensagens de erro:** nunca culpabilizam a pessoa ("você errou") — sempre orientam a correção de forma neutra e gentil.

**Mensagens de confirmação:** reconhecem a pessoa pelo nome imediatamente — aplicação literal do valor "nome importa" já no primeiro contato formal com a marca.

**Mensagens de agradecimento:** calorosas, mas contidas — nunca eufóricas ou exageradas, coerente com a personalidade da marca (Fase 3, Capítulo 7).

**Vocabulário:** segue integralmente as palavras recomendadas, neutras e proibidas já definidas no Projeto 01, Capítulo 6.

---

## 8. QUALIDADE DOS DADOS

**Como reduzir erros:** validação em tempo real (formato de e-mail, telefone), não apenas no envio final.

**Como reduzir abandono:** etapas curtas (Capítulo 6) e salvamento automático de progresso.

**Como reduzir respostas inconsistentes:** exemplos claros em campos que possam gerar ambiguidade.

**Como validar:** confirmação simples do meio de contato informado.

**Como atualizar:** link permanente de autoatualização disponível a qualquer momento (Capítulo 3).

**Como lidar com duplicidade:** cruzamento automático com registros existentes e com o Sistema de Memória, seguindo exatamente o protocolo já definido no Projeto 11, Capítulo 5 — inclusive o tratamento de casos inconclusivos (nunca presumir identidade sem confiança suficiente).

---

## 9. LGPD

**Consentimento:** granular e específico por finalidade — nunca um único checkbox genérico de "aceito os termos". Cada finalidade distinta de uso de dado (previsão operacional, comunicação, eventual compartilhamento com parceiro) tem consentimento próprio e separado.

**Finalidade:** explicada em linguagem simples no momento da pergunta, não apenas relegada a uma política de privacidade separada e pouco lida.

**Privacidade desde a concepção:** campos sensíveis (ex: idade, sexo) sempre acompanhados de explicação inline do motivo da coleta.

**Direitos do usuário:** acesso, correção, portabilidade e exclusão completa disponíveis diretamente a partir do próprio formulário ou de link associado a ele — nunca escondidos em processo burocrático separado.

**Retenção e anonimização:** conforme já definido no Projeto 11, Capítulo 13.

**Transparência:** a pessoa pode, a qualquer momento, entender exatamente quais dados forneceu e para qual finalidade.

---

## 10. INTEGRAÇÃO

- **Projeto 10 (Lançamento):** o formulário é o instrumento primário da macrofase de Escuta.
- **Projeto 11 (Inteligência Pré-Inscrição):** este manual operacionaliza diretamente os princípios técnicos ali definidos.
- **CRM:** toda resposta alimenta o CRM já previsto no Sistema Comercial (Projeto 06), sem duplicação de cadastro.
- **Sistema de Memória:** consultado automaticamente para reconhecer atletas recorrentes e evitar perguntas redundantes.
- **Sistema de Inscrições:** os dados fluem diretamente para o processo de inscrição, sem exigir reentrada.
- **Dashboard e Analytics:** cada etapa do formulário gera evento rastreável, alimentando os indicadores do Capítulo 11.

---

## 11. INDICADORES

- **Taxa de conclusão:** por etapa, não apenas do formulário como um todo — permite identificar exatamente onde a fricção ocorre.
- **Tempo médio:** por etapa e total.
- **Abandono:** identificado por etapa específica, informando prioridade de redesenho.
- **Conversão:** granularidade fina dentro do funil geral já definido no Projeto 11.
- **Campos ignorados:** campos opcionais raramente preenchidos são sinal de pergunta mal formulada, mal posicionada, ou de propósito pouco claro para quem responde.
- **Qualidade da base:** proporção de respostas válidas e completas.
- **Atualização:** frequência de uso do recurso de autoatualização (Capítulo 3).
- **Precisão:** os dados coletados aqui retroalimentam diretamente o indicador central de precisão de previsão já definido no Projeto 11, Capítulo 9.

---

## 12. GOVERNANÇA

**Quem cria:** equipe técnica sob responsabilidade do Diretor de Comunicação e do Diretor Comercial (Fase 6), conforme a natureza do dado envolvido.

**Quem revisa:** revisão de UX e revisão de marca (checklist do Projeto 01, Capítulo 15, e do Brand Book, Projeto 04, Capítulo 18) antes de qualquer publicação.

**Quem aprova:** mudanças estruturais relevantes exigem aprovação da Governança de Marca; ajustes menores de microcopy ou usabilidade seguem o fluxo de aprovação ágil já formalizado no Projeto 01.

**Quem publica:** apenas responsáveis formalmente autorizados, dentro da estrutura já definida desde a Fase 6.

**Quem altera:** princípios permanentes deste manual só são alterados pela Governança de Marca; ajustes técnicos e de plataforma são de responsabilidade da equipe técnica designada.

**Versionamento e auditorias:** mesma lógica formal já padronizada desde o Projeto 04.

---

## 13. ROADMAP DE EVOLUÇÃO

**Como melhorar ao longo dos anos:** por meio de testes de usabilidade (nunca testes manipulativos de conversão a qualquer custo), sempre orientados por clareza e redução de fricção genuína, nunca por pressão psicológica.

**Como validar hipóteses:** por meio de pesquisa real de usuário, conforme já recomendado no Projeto 11, Capítulo 3/4 — a ordem de coleta apresentada neste manual é uma hipótese de boa-fé, sujeita a validação e ajuste.

**Como incorporar aprendizados:** qualquer alteração relevante segue o mesmo Sistema de Aprendizado já definido no Projeto 11, Capítulo 14.

**Como comparar versões:** versionamento formal (Capítulo 12), permitindo comparação de desempenho entre diferentes iterações do formulário ao longo dos anos.

---

## 14. ROADMAP DE IMPLEMENTAÇÃO

**Etapas para transformar este manual em formulário real:**
1. Escolha de plataforma tecnológica compatível com os princípios de integração (Capítulo 10) — nenhuma plataforma específica é exigida por este manual, desde que suporte lógica condicional, salvamento de progresso e integração via API.
2. Prototipagem do fluxo conforme a Arquitetura Geral e a Ordem da Coleta (Capítulos 2 e 5).
3. Redação de microcopy conforme o Capítulo 7.
4. Teste de acessibilidade e experiência mobile (Capítulo 6).
5. Validação jurídica de conformidade com LGPD (Capítulo 9).
6. Teste com grupo reduzido de usuários reais antes de publicação ampla.
7. Publicação formal, seguindo a Governança (Capítulo 12).

**Dependências:** implementação real depende do CRM (Projeto 11, Capítulo 18) estar minimamente operacional para integração de dados.

**Ferramentas compatíveis:** qualquer plataforma (Google Forms, Typeform, Tally, HubSpot, sistema próprio) que cumpra os requisitos técnicos do Capítulo 10 — o sistema nunca depende de fornecedor único, mesmo princípio de continuidade já estabelecido nos Projetos 08 e 09.

---

## 15. CASOS ESPECIAIS

- **Atletas estrangeiros:** campos adaptados de país e documento, com comunicação de apoio em idioma adicional quando relevante (Projeto 05, Capítulo 15).
- **Menores de idade:** consentimento parental explícito e coleta mínima reforçada, seguindo rigorosamente os princípios já estabelecidos no Projeto 08, Capítulo 16, e no Projeto 10, Capítulo 16.
- **Grupos (mesmo box/cidade):** o formulário permite manifestação vinculada a um grupo, sem nunca perder o registro nominal individual de cada pessoa — "nome importa" mesmo dentro de uma manifestação coletiva.
- **Boxes:** manifestação institucional distinta da manifestação individual de atleta, alimentando o Sistema de Boxes (Fase 5) separadamente.
- **Federações, autoridades e convidados institucionais:** fluxo simplificado e direto, fora do funil comercial padrão, tratado pelo Sistema de Parceiros (Fase 5).
- **Voluntários e árbitros:** formulário derivado deste mesmo sistema, mas com campos específicos vinculados ao Sistema de Voluntariado e ao Sistema de Árbitros já constitucionais (Projeto 07/09).
- **Imprensa:** segue fluxo de credenciamento próprio, já definido na Jornada da Imprensa (Projeto 07, Capítulo 6), não este formulário de interesse geral.
- **Patrocinadores:** nunca utilizam este formulário — seguem exclusivamente o funil comercial dedicado do Projeto 06, evitando confusão entre relacionamento comercial e manifestação de interesse esportivo.

---

## AUDITORIA TÉCNICA — CONSELHO DE ONZE ESPECIALISTAS (CICLO ITERATIVO)

### Rodada 1 — críticas técnicas

**UX:** "A lógica de uma decisão por tela e o princípio de salvar progresso automaticamente (Capítulos 2 e 5) são práticas corretas e bem fundamentadas. Nenhuma inconsistência estrutural."

**UX Research:** "A recomendação, herdada do Projeto 11, de validar a ordem de coleta com pesquisa real (Capítulo 13) está corretamente mantida aqui. Sugiro reforçar que os primeiros ciclos do formulário devem ser tratados explicitamente como período de aprendizado, com expectativa de ajuste, não como versão definitiva desde o primeiro uso."

**UX Writing:** "O Capítulo 7 está bem alinhado ao Projeto 01. Ponto de atenção: falta orientação sobre como lidar com mensagens em caso de erro técnico do sistema (não erro do usuário) — cenário comum e não coberto aqui."

**CRM:** "A integração com Sistema de Memória e tratamento de duplicidade (Capítulo 8) reaproveita corretamente o protocolo já definido no Projeto 11. Nenhuma inconsistência nova."

**LGPD:** "O consentimento granular por finalidade (Capítulo 9) é tecnicamente correto e vai além da prática comum de mercado (que costuma usar checkbox único). Recomendo apenas que fique explícito como o consentimento é revisitado quando uma nova finalidade de uso do dado surge no futuro (ex: uma nova parceria comercial que queira usar dado já coletado) — hoje o documento cobre a coleta inicial, mas não o cenário de nova finalidade posterior."

**Ciência de Dados:** "Os indicadores granulares por etapa (Capítulo 11) são valiosos para diagnóstico real de fricção. Nenhuma inconsistência."

**Growth Marketing:** "A proibição explícita de testes manipulativos de conversão (Capítulo 13) mantém a coerência ética de toda a Constituição. Recomendo apenas que o roadmap de evolução defina brevemente o que conta como teste 'de clareza' aceitável versus teste manipulativo não aceitável, para orientar decisões futuras de equipe técnica sem ambiguidade."

**Marketing Esportivo:** "O tratamento diferenciado de casos especiais (Capítulo 15), especialmente a separação clara entre patrocinadores e o formulário de interesse geral, evita um erro comum de funis mal desenhados. Nenhuma inconsistência."

**Conversão:** "A granularidade de indicadores por etapa (Capítulo 11) é exatamente o que permite otimização real sem recorrer a gatilhos artificiais — o documento oferece um caminho legítimo de melhoria de conversão. Nenhuma inconsistência."

**Pesquisa de Mercado:** "A forma como este manual se conecta ao Sistema de Inteligência de Mercado mais amplo (via Projeto 11) está coerente. Nenhuma observação adicional."

**Arquitetura da Informação:** "A Arquitetura das Perguntas (Capítulo 4), com categorias claras de obrigatórias, opcionais, condicionais e proibidas, é uma estrutura sólida e replicável por qualquer equipe técnica futura. Nenhuma inconsistência estrutural."

### Ajustes incorporados após a Rodada 1

- **Capítulo 13** passa a determinar explicitamente que os primeiros ciclos de uso real do formulário são tratados como período formal de aprendizado, com expectativa declarada de ajuste, nunca apresentados como versão definitiva e imutável desde o primeiro lançamento.
- **Capítulo 7** passa a incluir princípio para mensagens de erro técnico do sistema (distintas de erro de preenchimento do usuário): sempre honestas sobre o que aconteceu, nunca atribuindo o problema à pessoa, com orientação clara de próximo passo (ex: tentar novamente, contato alternativo).
- **Capítulo 9** passa a prever que qualquer nova finalidade de uso de um dado já coletado exige novo consentimento específico, obtido ativamente junto ao titular antes do uso — nunca reaproveitando consentimento antigo para finalidade não prevista originalmente.
- **Capítulo 13** passa a distinguir explicitamente teste aceitável (voltado à clareza, usabilidade e redução de fricção real) de teste inaceitável (qualquer teste desenhado para aumentar conversão através de pressão psicológica, ambiguidade proposital ou ocultamento de informação) — os dois nunca são a mesma coisa, mesmo quando ambos são tecnicamente chamados de "teste A/B".

### Rodada 2 — segunda leitura crítica após ajustes

**UX Research:** "O tratamento explícito dos primeiros ciclos como período de aprendizado resolve minha observação — evita que a equipe trate a primeira versão como fracasso caso precise de ajuste."

**UX Writing:** "O princípio para erro técnico do sistema resolve a lacuna que apontei. Nenhuma nova inconsistência."

**LGPD:** "A exigência de novo consentimento específico para nova finalidade resolve exatamente o cenário que eu havia levantado. Tecnicamente sólido."

**Growth Marketing:** "A distinção clara entre teste de clareza e teste manipulativo remove a ambiguidade que eu havia sinalizado — agora há um critério objetivo para a equipe técnica decidir no dia a dia."

**Consolidação final:** a segunda rodada não identificou nenhuma inconsistência estrutural relevante remanescente. Todos os ajustes da primeira rodada foram incorporados como princípios formais, sem comprometer a validade deste manual. O ciclo iterativo é encerrado nesta rodada.

---

*Fim do Manual do Formulário de Manifestação de Interesse. Documento oficial, fundamentado em toda a Constituição do projeto (Fases 1-6, Projetos 01-11), servindo como padrão permanente para qualquer implementação futura deste formulário.*
