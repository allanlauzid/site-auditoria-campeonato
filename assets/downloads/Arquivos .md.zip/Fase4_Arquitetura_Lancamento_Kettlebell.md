# FASE 4 — ARQUITETURA ESTRATÉGICA DE LANÇAMENTO
### Campeonato Brasileiro de Kettlebell Sport

*Constituição do projeto (Fases 1, 2 e 3) tratada como definitiva e não revisitada. Este documento constrói a arquitetura de lançamento — não a execução, não o calendário, não as peças. A execução será desenvolvida na próxima fase.*

---

## COMO A PLATAFORMA DE MARCA INFLUENCIA O LANÇAMENTO

A Fase 3 deixou um recado direto para esta fase: a marca promete controle, não caos; memória, não espetáculo vazio; nome próprio, não massa anônima. Isso significa que o lançamento não pode seguir o manual padrão de "gerar hype rápido com urgência artificial" — isso violaria diretamente o valor de honestidade competitiva e a personalidade contida definida no Capítulo 7 da Fase 3. Também significa que o problema real que este lançamento precisa resolver não é conversão — é **existência categórica**, exatamente como identificado na Fase 2: a maior parte do público endereçável simplesmente não sabe que esta categoria existe. Por isso, a arquitetura de lançamento aqui construída trata **notoriedade genuína e infraestrutura de memória** como prioridade fundacional, e trata inscrições como consequência tardia, não como métrica de largada.

---

## 1. PRINCÍPIOS DO LANÇAMENTO

- **Nunca simular escassez ou urgência.** Se não houver demanda real que justifique "vagas limitadas", isso não será comunicado — princípio direto do Capítulo 5 da Fase 3.
- **Nunca lançar com aparato de mídia maior do que a capacidade real de sustentar.** Um "live announcement" estilo CrossFit sem audiência compatível soaria artificial e quebraria a personalidade contida da marca — risco já identificado na Fase 1.
- **Todo ativo de lançamento deve cumprir função dupla:** gerar curiosidade e, ao mesmo tempo, semear a infraestrutura de memória (arquivo de nomes) que a Fase 3 identificou como promessa central ainda não construída operacionalmente.
- **Nomear pessoas desde o primeiro dia.** Nenhuma comunicação de lançamento trata o público-alvo como massa — mesmo antes da primeira edição, os primeiros atletas, técnicos e boxes envolvidos devem ser nomeados publicamente.
- **Profundidade antes de velocidade.** Preferir crescer mais devagar com comunidade real a crescer rápido com engajamento superficial — aplicação direta do Capítulo 18 (Princípios de Decisão) da Fase 3.

**O que nunca poderá ser feito:**
Comparações depreciativas com outras modalidades; linguagem de sofrimento extremo ou glorificação de lesão; promessas de acesso "para todo mundo" sem entrega real de reconhecimento individual; contagens regressivas ou senso de urgência fabricado; tom espalhafatoso ou eufórico incompatível com a personalidade definida na Fase 3.

**Erros que destruiriam o posicionamento construído:**
1. Lançar como "mais um evento de nicho fitness" genérico, sem comunicar o território emocional único definido na Fase 2.
2. Prometer pertencimento e comunidade e, na prática, tratar os primeiros inscritos como números — quebraria a promessa central da marca já na largada.
3. Terceirizar a comunicação para um tom de agência genérica de fitness, perdendo a voz contida e precisa definida no Capítulo 13 da Fase 3.
4. Crescer rápido demais, rápido demais cedo, sem conseguir sustentar a promessa de reconhecimento individual em escala — risco citado pelo próprio atleta de elite na auditoria da Fase 3.

---

## 2. OBJETIVOS ESTRATÉGICOS

**Curto prazo (0–12 meses)**
- *Notoriedade:* fazer a categoria "Kettlebell Sport" e o nome do campeonato existirem, pela primeira vez, na cabeça de um público de fitness mais amplo do que o círculo já convertido.
- *Consideração:* fazer com que quem já pratica força/fitness veja o campeonato como uma opção legítima e desejável, não apenas curiosa.
- *Comunidade:* formar um núcleo fundador pequeno, mas genuinamente engajado — os primeiros nomes do "Livro de Nomes".
- *Inscrições:* garantir uma primeira edição bem documentada, mesmo que numericamente modesta — qualidade de registro acima de volume.

**Médio prazo (1–3 anos)**
- *Notoriedade:* consolidar reconhecimento do campeonato como principal referência nacional da modalidade.
- *Consideração:* associação espontânea entre "força controlada" e a marca do campeonato em conversas do universo fitness.
- *Comunidade:* camadas de pertencimento (atleta, técnico, box, cidade) funcionando de forma visível e consistente.
- *Inscrições:* crescimento sustentável, mas nunca priorizado acima da qualidade da experiência prometida.
- *Fidelização:* taxa mensurável de atletas retornando em edições subsequentes.

**Longo prazo (3–10 anos)**
- *Comunidade e Legado:* arquivo histórico robusto e citado como referência; múltiplas gerações de atletas, técnicos e boxes representados; a marca torna-se sinônimo cultural da própria modalidade no Brasil, cumprindo a visão de 10-20 anos definida na Fase 3.

---

## 3. PÚBLICOS

**Pessoas que nunca ouviram falar do esporte**
Pensam hoje: kettlebell é, no máximo, um acessório de treino funcional, não um esporte competitivo com federação e campeonato próprio.
Precisam passar a pensar: existe um esporte de verdade, com prestígio técnico e drama competitivo real, que elas nunca tiveram a chance de conhecer.
Objeções: "isso não é um esporte de verdade"; "isso é coisa de nicho pequeno demais para eu me importar".
Emoções a despertar: curiosidade genuína, admiração diante de algo inesperadamente impressionante.
Ação esperada: assistir a um conteúdo, comentar, compartilhar — nenhuma ação de conversão neste estágio.

**Praticantes iniciantes**
Pensam hoje: talvez pratiquem kettlebell em treino funcional, mas não se veem como "atletas competidores".
Precisam passar a pensar: competir é acessível e desejável mesmo sem ser um atleta de elite.
Objeções: "não sou bom o suficiente"; "não entendo as regras de competição".
Emoções a despertar: sensação de convite genuíno, não de exame de admissão.
Ação esperada: buscar informação sobre como começar a competir, seguir a comunidade.

**Atletas experientes**
Pensam hoje: talvez já disputem eventos internacionais ou vejam pouco prestígio nacional para investir energia competitiva no Brasil.
Precisam passar a pensar: o campeonato nacional é o palco mais prestigioso e mais bem documentado que eles terão no país.
Objeções: "o cenário nacional não tem nível/visibilidade suficiente".
Emoções a despertar: orgulho, senso de prestígio técnico reconhecido.
Ação esperada: competir, engajar publicamente, tornar-se referência/voz pública da comunidade.

**Treinadores**
Pensam hoje: seu trabalho técnico raramente é reconhecido publicamente além do círculo do próprio box.
Precisam passar a pensar: o campeonato é uma vitrine legítima do seu trabalho técnico, não apenas dos atletas.
Objeções: "vou passar batido, só o atleta é lembrado".
Emoções a despertar: reconhecimento profissional, orgulho de formar atletas.
Ação esperada: incentivar alunos a competir, engajar-se como voz técnica da comunidade.

**Boxes**
Pensam hoje: eventos de outras modalidades tratam boxes como concorrência ou como irrelevantes.
Precisam passar a pensar: o campeonato é parceiro, e o box ganha visibilidade legítima ao participar.
Objeções: "isso é concorrência com meu próprio negócio/comunidade local".
Emoções a despertar: senso de parceria e vitrine, não ameaça.
Ação esperada: apoiar e divulgar entre seus alunos, ceder espaço/estrutura quando pertinente.

**Árbitros**
Pensam hoje: função técnica importante, mas normalmente invisível na comunicação de eventos esportivos.
Precisam passar a pensar: são guardiões da honestidade competitiva, valor central da marca — função reconhecida publicamente, não anônima.
Objeções: "meu papel nunca é valorizado, só cobrado".
Emoções a despertar: senso de responsabilidade reconhecida.
Ação esperada: engajamento ativo e orgulho declarado da função.

**Patrocinadores**
Pensam hoje: fitness de nicho tem risco de baixo retorno e associação a evento pequeno/pouco profissional.
Precisam passar a pensar: esta é uma marca com território emocional único, defensável e crescente — associação estratégica, não aposta genérica.
Objeções: "não tenho métricas suficientes para justificar investimento".
Emoções a despertar: confiança na solidez estratégica e na diferenciação da marca.
Ação esperada: investimento inicial testável, com abertura a relacionamento de longo prazo.

**Imprensa**
Pensam hoje: kettlebell sport não é pauta relevante ou compreensível para grande público.
Precisam passar a pensar: existe ali uma história humana genuinamente interessante, além do jargão técnico.
Objeções: "não tenho ângulo humano fácil de contar, é técnico demais".
Emoções a despertar: interesse editorial genuíno, não apenas obrigação de cobertura de nicho.
Ação esperada: cobertura editorial espontânea, não apenas pautada por assessoria.

**Criadores de conteúdo**
Pensam hoje: kettlebell sport tem pouco material visual/dramático conhecido para se apropriarem em seus formatos.
Precisam passar a pensar: existe ali material narrativo raro (tensão, drama contido, autenticidade) que se diferencia do conteúdo saturado de outros nichos fitness.
Objeções: "não sei explicar as regras para minha audiência".
Emoções a despertar: entusiasmo por descobrir um território de conteúdo ainda inexplorado.
Ação esperada: produção espontânea de conteúdo, colaboração editorial.

**Familiares**
Pensam hoje: pouca ou nenhuma compreensão do que o parente pratica ou do nível de exigência envolvido.
Precisam passar a pensar: é um esforço sério, admirável, que merece ser testemunhado presencialmente.
Objeções: "não entendo o suficiente para me importar ou comparecer".
Emoções a despertar: orgulho e vontade de testemunhar presencialmente.
Ação esperada: comparecer, apoiar, compartilhar a conquista do familiar.

**Espectadores**
Pensam hoje: provavelmente nunca assistiram a uma prova e não têm motivo aparente para começar.
Precisam passar a pensar: dá para se emocionar com essa disputa mesmo sem entender todas as regras técnicas — o drama humano é acessível.
Objeções: "não vou entender nada do que está acontecendo".
Emoções a despertar: tensão genuína, torcida espontânea.
Ação esperada: assistir, comentar, voltar a assistir na próxima edição.

---

## 4. JORNADA DO PÚBLICO

1. **Nunca ouvi falar** — objetivo: nenhum, ainda fora do radar. Ponto de contato: nenhum ativo direcionado.
2. **Primeiro contato / curiosidade** — objetivo psicológico: interromper o padrão de conteúdo de fitness já conhecido com algo visualmente e emocionalmente diferente. Emoção: surpresa, curiosidade. Pontos de contato: vídeo curto de descoberta (redes sociais), imprensa, indicação de terceiros.
3. **Compreensão / interesse** — objetivo: traduzir tecnicidade em desejo, sem intimidar. Emoção: fascínio, admiração. Pontos de contato: conteúdo educativo, bastidores técnicos, YouTube.
4. **Consideração** — objetivo: fazer a pessoa se imaginar dentro daquele mundo, como praticante, espectador ou apoiador. Emoção: identificação, pertencimento antecipado. Pontos de contato: histórias reais de atletas, comunidade local, site/arquivo.
5. **Primeira experiência** — objetivo: entregar, na prática, a promessa de reconhecimento e controle prometida pela marca. Emoção: acolhimento, orgulho inicial. Pontos de contato: inscrição, evento presencial, primeira menção nominal.
6. **Pertencimento** — objetivo: transformar participação isolada em identidade contínua. Emoção: pertencimento genuíno, continuidade. Pontos de contato: comunidade entre edições, reconhecimento contínuo (WhatsApp, e-mail, redes).
7. **Retorno** — objetivo: reforçar que a trajetória é acumulativa, não recomeça a cada edição. Emoção: orgulho de continuidade, senso de história pessoal crescendo. Pontos de contato: arquivo histórico, reconhecimento de retorno.
8. **Defesa da marca (advocacy)** — objetivo: transformar quem vive a experiência em voz ativa que traz outras pessoas. Emoção: orgulho de pertencer a algo que vale a pena divulgar. Pontos de contato: indicação espontânea, criação de conteúdo próprio, testemunho público.

---

## 5. NARRATIVA DO LANÇAMENTO

A história não começa pedindo nada ao público — começa mostrando algo que ele nunca viu, exatamente como a Brand Story da Fase 3 estabelece: um esforço sustentado, silencioso, que passa despercebido até alguém saber onde olhar.

**Ato 1 — Revelação do invisível.** A narrativa se abre mostrando o próprio fenômeno do "duelo testemunhado" — a tensão real de uma série contínua, sem pedir inscrição, sem falar do campeonato ainda. O objetivo é puramente perceptivo: fazer o público notar algo que sempre existiu, mas nunca tinha sido enquadrado dessa forma.

**Ato 2 — Existem nomes por trás disso.** A narrativa evolui para apresentar pessoas reais — os primeiros atletas, técnicos, boxes — não como protagonistas de campanha, mas como prova de que esse mundo já existe e já tem história, mesmo que pequena. Este é o momento em que o "Livro de Nomes" começa a ser semeado publicamente, mesmo antes da primeira edição estar formalmente aberta.

**Ato 3 — Convite ao pertencimento.** Só depois de estabelecida a curiosidade (Ato 1) e a prova social genuína (Ato 2), a narrativa apresenta o convite — inscrição, participação, presença. O convite é comunicado como entrada em algo que já está vivo, não como fundação de algo do zero, mesmo em uma primeira edição — o senso de comunidade já criado nos dois atos anteriores sustenta essa percepção.

**Ato 4 — O ciclo de memória.** Após a primeira edição, a narrativa se fecha (temporariamente) mostrando o resultado do compromisso de memória — nomes documentados, histórias recontadas — criando a ponte natural para a próxima edição, sustentando o "calendário afetivo" identificado como oportunidade na Fase 1.

Essa arquitetura evolui ao longo do tempo de forma cíclica, não linear: cada nova edição reabre o Ato 1 para novos públicos, enquanto aprofunda os Atos 2, 3 e 4 para quem já está dentro — o lançamento nunca "termina", ele se repete em camadas crescentes de profundidade.

---

## 6. FASES DO LANÇAMENTO

1. **Descoberta** — objetivo psicológico: interromper o piloto automático do público, gerando reconhecimento de que algo novo e genuinamente interessante existe.
2. **Educação** — objetivo psicológico: reduzir a barreira de intimidação técnica, substituindo confusão por fascínio compreensível.
3. **Aproximação** — objetivo psicológico: reduzir distância emocional entre marca e público, através de histórias reais e nomes reais, não de instituição abstrata.
4. **Pertencimento** — objetivo psicológico: fazer o público sentir que já poderia fazer parte, antes mesmo de se inscrever.
5. **Abertura das inscrições** — objetivo psicológico: transformar desejo já construído em ação concreta, com transparência total sobre o processo (nunca escassez artificial).
6. **Preparação** — objetivo psicológico: sustentar antecipação genuína, com marcos reais de progresso (rumo à experiência, não apenas contagem regressiva vazia).
7. **Campeonato** — objetivo psicológico: entregar, sem exceção, a promessa central da marca — controle, testemunho, reconhecimento nominal.
8. **Legado** — objetivo psicológico: transformar a experiência vivida em memória permanente e ponte emocional para o retorno na edição seguinte.

---

## 7. MECÂNICAS DE COMUNIDADE

- **Nomes fundadores:** os primeiros atletas, técnicos e boxes envolvidos no lançamento são explicitamente reconhecidos como parte da fundação do "Livro de Nomes" — não apenas participantes, mas coautores da história em construção.
- **Reconhecimento de retorno:** mecanismo simples e consistente de sinalizar publicamente quando um atleta está competindo pela segunda, terceira, quinta vez — tornando visível a continuidade da trajetória.
- **Indicação por pertencimento, não por incentivo comercial:** convites para novos participantes são estruturados como "traga alguém do seu box/comunidade", reforçando a camada estrutural de pertencimento em vez de mecanismos de desconto por indicação.
- **Contato entre edições:** presença ativa e não transacional em canais de proximidade (comunidade fechada, grupo direto) para manter viva a sensação de "calendário afetivo" fora da janela de competição.
- **Memória compartilhada:** rituais de revisitação (relembrar histórias e nomes de edições anteriores) usados deliberadamente como conteúdo recorrente, não apenas como arquivo passivo.

*(Mecanismos aqui descritos permanecem em nível de arquitetura — a forma operacional de cada um será definida na próxima fase.)*

---

## 8. EXPERIÊNCIA DO ATLETA

**Primeiro contato:** curiosidade respeitosa — a marca não pressiona, apresenta-se com credibilidade e controle.
**Decisão de se inscrever:** confiança — o processo é transparente, sem urgência artificial, e a pessoa sente que está entrando por escolha genuína, não por pressão.
**Preparação:** acompanhamento e reconhecimento crescente — mesmo antes de competir, o atleta já é nomeado e incluído em comunicação real.
**Dia da competição:** presença total — o atleta sente que, no momento do seu esforço, existe testemunha genuína (Chamada do Nome, Última Respiração) e não apenas cronômetro.
**Imediatamente depois:** reconhecimento concreto — independentemente do resultado, há reconhecimento público e pessoal do esforço sustentado.
**Meses depois:** continuidade — contato ativo da comunidade, sem que o atleta precise buscar por conta própria.
**Anos depois:** identidade — o atleta se vê como parte de uma história documentada e crescente, com orgulho de trajetória acumulada, não apenas de resultados isolados.

---

## 9. PAPEL DE CADA CANAL

- **Instagram:** porta de descoberta e narrativa visual — carrega principalmente os Atos 1 e 2 da narrativa (revelação e prova social), função de curiosidade e reconhecimento inicial.
- **YouTube:** aprofundamento e drama documental — o único canal capaz de sustentar a tensão contida do "duelo testemunhado" em formato longo, com fidelidade ao tom da marca.
- **WhatsApp:** camada de proximidade e pertencimento real — função de intimidade e continuidade entre edições, coerente com a promessa de comunidade genuína (não engajamento de massa).
- **Email:** função de memória formal — comunicação estruturada, arquivo pessoal do atleta, ponto de contato mais adequado para reforçar a promessa de "nada se perde".
- **Site institucional:** casa permanente do Livro de Nomes e do arquivo histórico — função estrutural, não apenas promocional.
- **Landing pages:** função de conversão pontual e transparente — usadas apenas nos momentos de decisão concreta (inscrição), nunca como substituto de construção de desejo.
- **Assessoria de imprensa:** função de legitimidade externa — validação de terceiros que ajuda a resolver diretamente o problema de "existência categórica" identificado na Fase 2.
- **Eventos presenciais:** função de prova definitiva — é onde toda promessa da marca (controle, testemunho, reconhecimento nominal) é finalmente entregue de forma inegável.

---

## 10. INDICADORES

**Fortalecimento de marca:** lembrança espontânea da marca em pesquisas informais com público de fitness; associação correta entre a marca e o território "força controlada" (não confundida com CrossFit/HYROX genérico).
**Comunidade:** número de atletas, técnicos e boxes ativamente engajados fora da janela de competição; frequência de interação espontânea nos canais de proximidade.
**Retenção:** percentual de atletas que retornam em edições subsequentes; percentual de boxes que retornam a indicar novos atletas.
**Crescimento:** taxa de crescimento de inscrições ano a ano — sempre lida em conjunto com os indicadores de retenção, nunca isoladamente.
**Lembrança/reputação:** menções espontâneas na imprensa e por criadores de conteúdo sem ação direta de assessoria; qualidade e tom das menções (se usam a linguagem e o território da marca, ou se tratam o evento genericamente).
**Legado:** completude e atualização do arquivo histórico (Livro de Nomes); percentual de atletas com trajetória documentada ao longo de múltiplas edições.
**Patrocínio:** taxa de renovação de patrocinadores ano a ano — indicador mais confiável de valor percebido de longo prazo do que o valor do primeiro contrato isolado.

---

## 11. RISCOS

1. **Pressão por hype de curto prazo** — equipes de execução podem ser tentadas a adotar linguagem de urgência ou intensidade genérica para acelerar resultados. *Mitigação:* usar os Princípios de Decisão da Fase 3 como filtro obrigatório em toda peça antes da publicação.
2. **Infraestrutura de memória não pronta a tempo** — o arquivo histórico (Livro de Nomes) é uma promessa central, mas exige construção técnica real. *Mitigação:* tratar a infraestrutura de arquivo como prioridade de execução desde o primeiro dia, não como entregável secundário.
3. **Crescimento rápido demais, cedo demais** — se a base de participantes crescer antes da capacidade de sustentar reconhecimento individual, a promessa central quebra. *Mitigação:* controlar deliberadamente o ritmo de crescimento nas primeiras edições, priorizando qualidade de execução sobre volume.
4. **Insularidade da comunidade** — risco já identificado no debate da Fase 2: uma comunidade muito fechada pode afastar novos públicos. *Mitigação:* garantir que os Atos 1 e 2 da narrativa (descoberta e prova social) continuem ativos permanentemente, não apenas na fase inicial de lançamento.
5. **Cobertura de imprensa que trata o esporte de forma genérica** ("mais um CrossFit"), diluindo a diferenciação construída na Fase 2. *Mitigação:* preparar material de apoio à imprensa que comunique explicitamente o território emocional único da marca.
6. **Expectativa de patrocinadores por métricas tradicionais de volume**, incompatíveis com a lógica de profundidade da marca. *Mitigação:* educar patrocinadores desde o primeiro contato sobre os indicadores de valor real da marca (retenção, território, reputação), não apenas alcance bruto.

---

## 12. AUDITORIA FINAL — CONSELHO DE SEIS ESPECIALISTAS

**Diretor Global de Branding:** "A arquitetura é coerente com a plataforma de marca e evita a armadilha mais comum de lançamentos de nicho — imitar o aparato dos grandes players. Meu único alerta é sobre consistência de execução: a narrativa em quatro atos exige disciplina editorial rigorosa para não colapsar em conteúdo genérico de fitness na pressão do dia a dia."

**Diretor de Marketing Esportivo:** "Gosto da priorização de profundidade sobre volume, mas insisto no ponto que já levantei na Fase 3: sem um mecanismo de aquisição robusto (Atos 1 e 2 sempre ativos, não apenas na fase de lançamento), o campeonato corre risco real de virar comunidade fechada e nunca resolver o problema de existência categórica em escala relevante."

**Especialista em Economia Comportamental:** "O uso de reconhecimento nominal como mecanismo central de engajamento é psicologicamente bem fundamentado — reforço social e identidade pessoal são motivadores mais duráveis do que urgência ou desconto. O risco behaviorale que vejo é a ausência de qualquer gatilho de ação imediata nos primeiros estágios da jornada — pode ser necessário, na fase de execução, criar microcompromissos genuínos (não escassez falsa) para não perder momentum de conversão."

**Jornalista Esportivo:** "O ângulo humano do 'duelo testemunhado' é genuinamente noticiável — chamativo o suficiente para justificar pauta espontânea, algo raro em esportes de nicho. Recomendo que o material de apoio à imprensa citado no plano de mitigação de riscos inclua sempre uma história real, não apenas dados técnicos do esporte."

**Patrocinador:** "A lógica de indicadores de profundidade (retenção, território, reputação) é mais sofisticada do que a maioria dos relatórios de patrocínio esportivo que recebo — mas, na prática, ainda vou precisar de números de alcance bruto nos primeiros ciclos para justificar orçamento internamente. Recomendo que a próxima fase inclua uma tradução desses indicadores de profundidade em linguagem que comitês de patrocínio tradicionais também reconheçam."

**Atleta de Elite:** "A experiência descrita no Capítulo 8 é exatamente o que sinto falta em outros eventos que já disputei. Meu ponto de atenção é prático: se o crescimento não for realmente controlado como o documento promete, a primeira quebra de promessa (não ser reconhecido, não ser lembrado) vai doer mais aqui do que doeria em qualquer evento genérico — porque a expectativa criada é mais alta."

**Consolidação das críticas:** nenhuma crítica contradiz a arquitetura construída — todas convergem, mais uma vez, para o mesmo ponto estrutural já sinalizado na Fase 3: a estratégia é conceitualmente sólida, mas seu sucesso depende de disciplina de execução (editorial, técnica e de ritmo de crescimento) e de traduzir os indicadores de profundidade em linguagem que também sirva a interlocutores mais tradicionais, como comitês de patrocínio. Este documento permanece como a versão definitiva da Arquitetura Estratégica de Lançamento; os pontos levantados ficam registrados como requisitos obrigatórios de atenção para a fase de execução.

---

*Fim da Fase 4 — Arquitetura Estratégica de Lançamento. Documento oficial, fundamentado nas Fases 1, 2 e 3, para orientar a construção da execução na próxima fase do projeto.*
