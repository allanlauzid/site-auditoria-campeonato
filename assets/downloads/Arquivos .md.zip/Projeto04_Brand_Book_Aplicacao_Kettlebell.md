# PROJETO 04 — SISTEMA DE APLICAÇÃO DA IDENTIDADE VISUAL
### Campeonato Brasileiro de Kettlebell Sport
### Brand Book — Manual Operacional Oficial

*Fases 1-6 e Projetos 01-03 são Constituição definitiva e têm prioridade absoluta sobre qualquer regra aqui contida. Este documento não cria identidade nova — operacionaliza o que já foi decidido em regras reproduzíveis, sem depender de interpretação subjetiva de quem aplica.*

---

## 1. INTRODUÇÃO

**Objetivo do Brand Book:** ser o documento de referência técnica que qualquer designer, agência, gráfica, videomaker, desenvolvedor, patrocinador ou fornecedor consulta antes de produzir qualquer material — eliminando a necessidade de interpretação pessoal sobre "o que a marca permitiria".

**Como utilizar:** este documento não substitui o Projeto 03 (Constituição Visual) — ele o operacionaliza. Sempre que houver dúvida sobre *por que* uma regra existe, a resposta está no Projeto 03; sempre que houver dúvida sobre *como* aplicá-la tecnicamente, a resposta está aqui.

**Hierarquia documental:** Fases 1-6 (estratégia e DNA) → Projetos 01-03 (comunicação, criação, identidade visual conceitual) → este Brand Book (aplicação operacional) → Anexos Técnicos Obrigatórios (Capítulo 20, ainda a serem desenvolvidos). Em qualquer conflito, o documento hierarquicamente superior prevalece sempre.

**O que pode ser alterado:** valores técnicos de especificação (tamanhos exatos de exportação, codecs, nomenclatura de arquivo) podem evoluir com a tecnologia disponível, desde que a função que cumprem permaneça a mesma.

**O que nunca pode ser alterado por este documento:** paleta cromática central, tipografia central, estrutura do logotipo, presença obrigatória de identificação nominal, e qualquer princípio do Projeto 03 — este Brand Book não tem autoridade para revisar decisões constitucionais, apenas para especificá-las tecnicamente.

---

## 2. ARQUITETURA DO SISTEMA VISUAL — HIERARQUIA ENTRE CAMADAS

| Ordem | Camada | Natureza |
|---|---|---|
| 1 | **Logotipo** | Mais protegida — nunca se adapta às demais camadas. |
| 2 | **Identificação nominal** | Transversal e obrigatória — atravessa todas as demais camadas sempre que uma pessoa está representada. |
| 3 | **Sistema cromático** | Estrutural — define o campo onde todo o resto acontece. |
| 4 | **Sistema tipográfico** | Estrutural — carrega hierarquia de informação. |
| 5 | **Grid e espaçamento** | Organizador — disciplina onde cada elemento pode existir. |
| 6 | **Fotografia** | Conteúdo principal — carrega a promessa de autenticidade. |
| 7 | **Ícones e motion** | Apoio funcional — nunca competem com fotografia ou tipografia. |
| 8 | **Texturas** | Camada mais flexível — pode variar por aplicação, desde que dentro dos limites do Projeto 03. |

Regra geral de conflito entre camadas: a camada de ordem mais alta nunca cede espaço, contraste ou proteção visual para acomodar uma camada de ordem mais baixa. Por exemplo: textura nunca reduz o contraste de tipografia; ícone nunca invade a área de proteção do logotipo.

---

## 3. SISTEMA MODULAR OFICIAL

**Unidade U:** `1U = 8px` em ambiente digital e `1U = 4mm` em ambiente impresso — a mesma lógica proporcional definida conceitualmente no Projeto 03, agora com valor técnico fixo.

**Escala modular:** 0.5U (4px) · 1U (8px) · 2U (16px) · 3U (24px) · 4U (32px) · 6U (48px) · 8U (64px) · 12U (96px) · 16U (128px).

**Grid matemático — digital:** 12 colunas (desktop, >1024px) · 8 colunas (tablet, 600–1024px) · 4 colunas (mobile, <600px). Gutter fixo de 2U em todas as resoluções.

**Margens:** mobile = 4U · tablet = 6U · desktop = 8U. Margens nunca são reduzidas para "caber mais conteúdo" — se o conteúdo não cabe, ele é reorganizado, nunca a margem comprimida.

**Respiros (whitespace):** mínimo de 1U entre elementos relacionados; mínimo de 2U entre blocos de conteúdo não relacionados.

**Alinhamentos:** alinhamento à esquerda como padrão (reflete objetividade e ausência de decoração); centralização é reservada exclusivamente a contextos cerimoniais (certificados, placas de honraria, telas de reconhecimento nominal).

**Sistema de proporções:** área de proteção do logotipo (Projeto 03, Capítulo 5) = 1U em qualquer escala de aplicação, calculada proporcionalmente à altura do símbolo.

**Sistema de módulos:** todo componente de interface (botão, card, campo de formulário) é dimensionado em múltiplos inteiros de U — nunca em valores arbitrários fora da escala.

**Sistema de espaçamentos e padding:** padding interno padrão de componentes = 2U vertical / 3U horizontal.

**Sistema de gutters:** 2U fixo em grids digitais; 1U em grids editoriais impressos de coluna estreita.

**Sistema de baseline:** grade vertical de texto alinhada a incrementos de 0.5U (4px), garantindo ritmo vertical consistente entre blocos de texto de tamanhos diferentes.

**Sistema responsivo:** breakpoints em 600px (mobile→tablet) e 1024px (tablet→desktop); a passagem entre grids nunca altera a proporção do logotipo ou a hierarquia tipográfica, apenas o número de colunas disponíveis.

---

## 4. SISTEMA CROMÁTICO OPERACIONAL

**Escala tonal — Ferro** (base `#2B2E30`): 50 `#F2F3F3` · 100 `#D9DBDC` · 200 `#B3B7B9` · 300 `#8C9296` · 400 `#666D72` · 500 `#454A4D` · 600 `#2B2E30` (base) · 700 `#212325` · 800 `#17181A` · 900 `#0D0E0F`.

**Escala tonal — Terracota** (base `#B5502C`): 50 `#FBEEE8` · 100 `#F3D2C2` · 200 `#E5A57F` · 300 `#D37B4F` · 400 `#C46339` · 500 `#B5502C` (base) · 600 `#8F3F23` · 700 `#6B2F1A` · 800 `#471F11` · 900 `#241009`.

**Escala tonal — Osso** (base `#EDE7DD`): 50 `#FFFFFC` · 100 `#F9F6F0` · 200 `#EDE7DD` (base) · 300 `#DCD3C2` · 400 `#C4B7A0` · 500 `#A99879`.

**Escala tonal — Carvão** (base `#141414`): usada primariamente em 900/800; variações mais claras remetem à escala Ferro acima.

**Estados de interface:**
- **Hover:** escurecer a cor base em um passo da escala tonal (ex: Terracota 500 → 600).
- **Pressed:** escurecer em dois passos (ex: Terracota 500 → 700).
- **Disabled:** cor base a 40% de opacidade sobre o fundo, sempre em Ferro 300/400 independente da cor original do componente.
- **Focus:** contorno de 2px em Terracota 500, nunca preenchimento — o foco é indicado por borda, não por mudança de área.

**Cores de sistema (uso funcional restrito, fora da paleta emocional central):**
- **Sucesso:** `#6E7A5E` (verde-oliva acinzentado, derivado da paleta secundária do Projeto 03).
- **Erro:** `#8C3A2E` (vermelho-terroso escuro, deliberadamente distinto de Terracota para não ser confundido com a cor de identidade da marca).
- **Aviso:** `#A9863C` (ocre acinzentado).
- **Informação:** `#4A5A63` (azul-acinzentado neutro, uso exclusivamente digital/funcional, nunca em comunicação de marca).

**Conversões de formato:**
- **HEX/RGB:** valores de referência primária, conforme listado acima.
- **CMYK (aproximação para impressão offset):** Ferro `C:65 M:55 Y:50 K:45` · Terracota `C:15 M:70 Y:85 K:10` · Osso `C:5 M:5 Y:12 K:0` · Carvão `C:0 M:0 Y:0 K:95`.
- **Pantone e LAB:** não fixados neste documento — a correspondência exata de Pantone físico deve ser validada por prova de cor profissional junto ao fornecedor gráfico contra os valores CMYK/HEX de referência aqui definidos, e então documentada como anexo técnico (Capítulo 20) assim que a primeira produção impressa oficial ocorrer.

**Quando usar cada cor:** conforme já definido no Projeto 03, Capítulo 3 — este capítulo apenas adiciona a granularidade tonal necessária para uso funcional em interfaces e produção gráfica, sem alterar as regras de uso emocional já estabelecidas.

---

## 5. SISTEMA TIPOGRÁFICO OPERACIONAL

**Escala tipográfica (razão modular 1.25):**
Caption 12px · Small 14px · Body 16px (base) · H4 20px · H3 25px · H2 31px · H1 39px · Display 49px.
*Nome de atleta/identificação:* nunca abaixo de 18px em qualquer contexto — regra fixa que sobrepõe a escala padrão, em conformidade com o valor "nome importa" (Projeto 03).

**Peso:** Regular (corpo de texto) · Medium (subtítulos, legendas de nome) · Semibold (títulos, nomes em destaque). Ultra-bold e Ultra-thin permanecem fora do sistema, conforme já definido no Projeto 03.

**Leading (entrelinha):** 1.5x para corpo de texto · 1.2x para títulos e headlines · 1.3x para legendas de identificação nominal.

**Tracking:** -1% em headlines grandes (Display, H1) · 0% (neutro) em corpo de texto · +3% em textos totalmente em caixa alta (labels, categorias).

**Kerning:** kerning nativo da fonte ativado por padrão; ajuste manual apenas em aplicações de grande escala (backdrop, sinalização de arena) onde pares de caracteres específicos exigem correção visual.

**Tamanhos mínimos e máximos por meio:**
- Digital: mínimo 14px (corpo), sem máximo fixo além do Display.
- Impresso: mínimo 8pt para texto legal/regulamentar, mínimo 10pt para corpo geral.
- Sinalização física: tamanho mínimo calculado pela fórmula de distância de leitura (altura da letra em mm ≈ distância de leitura em metros ÷ 3), aplicada caso a caso pela equipe de sinalização de evento.
- Vídeo: legendas nunca abaixo de 32px em referência a entrega Full HD (1920×1080).

**Usos específicos:** digital (sans-serif dominante, serifada reservada a headlines editoriais) · impresso (ambas as famílias conforme hierarquia do Projeto 03) · palco/telão (apenas Display e H1, nunca corpo de texto pequeno) · vídeo (lower thirds em Medium/Semibold, nunca Regular, para legibilidade sobre imagem em movimento) · redes sociais (Semibold para nome/identificação obrigatório em qualquer legenda sobreposta) · institucional/documentos (serifada dominante) · sinalização (sans-serif exclusiva, pela exigência de legibilidade a distância).

---

## 6. SISTEMA DO LOGOTIPO — OPERACIONALIZAÇÃO

**Construção matemática:** o símbolo é construído sobre grade de 1U; a distância entre símbolo e wordmark no lockup completo é fixada em 1U; a altura do wordmark corresponde a 0.6x a altura do símbolo.

**Área de proteção:** 1U livre em todas as direções, medido a partir da borda externa do elemento mais extremo do lockup (símbolo ou texto, o que for maior).

**Reduções mínimas:** lockup completo — 120px de largura (digital) / 30mm (impresso); símbolo isolado — 24px de altura (digital) / 8mm (impresso). Abaixo desses valores, nenhuma aplicação é permitida — recomenda-se remoção completa da marca antes de reduzir além do mínimo.

**Versões:** cor cheia · monocromática positiva (Carvão sobre Osso) · monocromática negativa (Osso sobre Carvero/Ferro) · versão gravada/cunhada de traço único, sem preenchimento, para uso em metal e madeira (Capítulo 13).

**Fundos permitidos:** cor sólida da paleta institucional (Osso, Ferro, Carvão) ou fotografia com camada de proteção (scrim) que garanta contraste mínimo de 4.5:1 entre logotipo e fundo — nunca aplicado diretamente sobre fotografia de alto contraste ou textura complexa sem essa camada.

**Co-branding e patrocínio:** separação mínima de 2U entre o lockup do campeonato e qualquer logotipo de terceiro; linha divisória neutra opcional de 0.5U de espessura em Ferro 300.

**Assinaturas institucionais:** a assinatura oficial (logotipo + linha de contexto, ex: "Campeonato Brasileiro de Kettlebell Sport — [ano/edição]") segue o mesmo sistema de proteção do lockup completo.

**Aplicações incorretas (lista de verificação rápida):** distorcer proporção · rotacionar · aplicar gradiente, sombra ou brilho não previstos · recolorir fora da paleta · reduzir abaixo do mínimo · posicionar sem respeitar área de proteção · fundir com logotipo de patrocinador em um único símbolo.

**Checklist de aplicação do logotipo:** ver Capítulo 18 (Sistema de QA), critério "Logotipo".

---

## 7. SISTEMA FOTOGRÁFICO OPERACIONAL

| Contexto | Lentes | ISO/Exposição | Observações |
|---|---|---|---|
| Retratos | ~85mm equivalente, abertura ampla (f/1.8–2.8) | ISO nativo, baixo | Altura dos olhos, foco no olhar. |
| Competição | ~35–50mm | ISO até 3200 aceitável | Prioriza captura do instante real sobre exposição perfeita; grão é aceitável. |
| Bastidores | ~24–35mm | ISO alto aceitável | Luz disponível, sem flash direto. |
| Premiação | ~50–85mm | ISO nativo | Enquadramento sóbrio, sem distorção grande-angular. |
| Público | ~50–135mm | Conforme luz disponível | Captura de reação real, não posada. |
| Patrocinadores/Institucional | ~50mm | ISO nativo | Iluminação uniforme, fundo neutro da paleta institucional. |
| Drone | Grande-angular padrão do equipamento | — | Uso limitado a planos de estabelecimento; nunca recurso narrativo principal. |

**Temperatura de cor:** referência de 5200–5600K (luz-dia balanceada) como padrão; desvios são aplicados apenas intencionalmente na etapa de tratamento, nunca por erro de captura não corrigido.

**Contraste e profundidade:** conforme Projeto 03, Capítulo 7 — este capítulo apenas fixa os parâmetros técnicos de captura que viabilizam esse resultado na pós-produção.

---

## 8. SISTEMA DE VÍDEO — ESPECIFICAÇÃO TÉCNICA

- **Frame rate:** 25fps como padrão de entrega (compatibilidade com broadcast nacional); 50fps disponível exclusivamente para captura de câmera lenta controlada em momentos-chave de esforço (não como recurso constante).
- **Resolução:** captura mínima em 4K sempre que o equipamento permitir; entrega padrão em Full HD (1920×1080) para digital, 4K reservado a arquivo master e eventuais usos institucionais de alta exibição.
- **Codecs:** captura em formato de alta qualidade (ProRes ou equivalente); entrega digital em H.264/H.265 (MP4); arquivo master preservado em ProRes ou codec sem perdas equivalente.
- **Aspect ratios:** 16:9 (padrão principal, YouTube/site) · 9:16 (Stories/Reels/Shorts) · 1:1 (uso limitado, feed estático).
- **Grão:** textura sutil de grão adicionada em pós-produção quando a captura digital resultar "limpa" demais, para preservar a sensação documental definida no Projeto 03.
- **Color grading:** LUT de referência derivado da paleta oficial (tons neutros-quentes, baixa saturação) — nunca o grading "teal-and-orange" padrão publicitário.
- **Motion, lower third e legendas:** conforme Projeto 03, Capítulo 8, com lower third em tipografia Semibold/Medium (Capítulo 5 deste documento) e legendas embutidas obrigatórias em todo conteúdo social, além de arquivo de legenda separado (.srt) entregue junto ao master para acessibilidade e arquivo.
- **Vinhetas:** duração máxima de 3 segundos, conduzidas por som real.
- **Áudio:** prioridade sempre ao áudio ambiente real (respiração, som de competição); captação com lapela ou boom para entrevistas, microfone ambiente dedicado para som de arena.
- **Entrega:** nomenclatura e organização de arquivo conforme Capítulo 17.

---

## 9. SISTEMA EDITORIAL

- **Livros/publicações de legado:** seguem grid editorial (Capítulo 3), tipografia serifada dominante, papel/textura visual equivalente a Osso.
- **PDF institucional:** capa com lockup, título, edição/data; corpo em grid de coluna única ou dupla; rodapé com referência de arquivo (número de versão, data).
- **Apresentações:** template fixo de capa, divisores de seção e encerramento, seguindo paleta institucional.
- **Ofícios e relatórios:** papel timbrado com lockup reduzido no cabeçalho, tipografia serifada, sem elementos promocionais.
- **Certificados:** nome do participante no tamanho tipográfico máximo da peça (Display, Capítulo 5), acima até do próprio nome do campeonato em hierarquia visual.
- **Credenciais:** grid compacto, tipografia tabular para números/códigos, nome sempre em destaque equivalente ou superior à função.
- **Propostas comerciais:** seguem o Sistema Editorial institucional, com anexo de indicadores conforme já referenciado no Projeto 01, Capítulo 13.
- **Papelaria e assinaturas de e-mail:** lockup reduzido, tipografia sans-serif, paleta institucional restrita (sem Terracota em áreas extensas).

---

## 10. SISTEMA DIGITAL

- **Estrutura geral do site:** organizada sobre o grid de 12 colunas (Capítulo 3), com o Livro de Nomes como seção estruturalmente permanente, não apenas mais um item de menu.
- **Botões:** dimensionados em múltiplos de U (mínimo 4U de altura para toque confortável), estados conforme Capítulo 4 (hover/pressed/disabled/focus).
- **Cards:** padding interno de 3U, cantos com raio pequeno (2–4px) — nunca cantos totalmente quadrados (frios demais) nem excessivamente arredondados (lúdicos demais).
- **Inputs de formulário:** altura mínima 4U, borda em Ferro 300, estado de foco conforme Capítulo 4.
- **Menus:** hierarquia clara, nunca mais de dois níveis de profundidade sem necessidade absoluta.
- **Ícones:** conforme Projeto 03, Capítulo 9, aplicados em tamanho fixo de 3U ou 4U conforme contexto.
- **Tabelas (ranking):** nome do atleta na primeira coluna, sempre em peso tipográfico igual ou superior ao dado numérico.
- **Responsividade:** conforme breakpoints do Capítulo 3.
- **Dark mode:** fundo dominante em Ferro 700/800, texto em Osso 100, Terracota preservada como acento (testada para manter contraste mínimo). **Light mode:** fundo dominante em Osso 100/200, texto em Carvão 900, Terracota preservada como acento.
- **Feedback visual:** cores de sistema do Capítulo 4 (sucesso/erro/aviso/informação), nunca a paleta emocional central da marca para esses estados funcionais.

---

## 11. SISTEMA PARA REDES SOCIAIS — ESPECIFICAÇÕES

| Formato | Dimensão de referência | Zona de segurança |
|---|---|---|
| Instagram feed | 1080×1350px | Legenda de nome sempre no terço inferior, nunca sobre rosto. |
| Instagram Stories/Reels | 1080×1920px | Zona de segurança inferior de 250px para elementos de interface da plataforma. |
| YouTube thumbnail | 1280×720px | Rosto real + nome em tipografia Semibold, sem elementos de clickbait. |
| Facebook | 1200×630px (link) | Mesma lógica de proteção de nome do Instagram feed. |
| LinkedIn | 1200×627px | Paleta institucional dominante. |
| TikTok | 1080×1920px | Mesma zona de segurança do Instagram Stories. |

Carrosséis seguem o grid editorial (Capítulo 3) aplicado a múltiplos quadros sequenciais, mantendo tipografia e paleta idênticas entre todos os quadros de uma mesma peça.

---

## 12. SISTEMA PARA EVENTOS

- **Backdrop:** repetição do símbolo (nunca do lockup completo) espaçada em intervalos mínimos de 3x a largura do próprio símbolo — nunca em padrão denso tipo "step and repeat" publicitário.
- **Pódio:** paleta institucional, iluminação natural ou branca neutra, sem efeitos coloridos artificiais.
- **Painéis e banners:** hierarquia tipográfica igual à sinalização (Capítulo 5), grid consistente com o sistema editorial.
- **Credenciamento:** template fixo com campos (nome, função, nível de acesso), tipografia tabular para códigos.
- **Uniformes:** aplicação do símbolo isolado em escala pequena (peito, nunca costas em grande formato), paleta Ferro/Osso dominante.
- **Sinalização de arena/palco/área técnica/imprensa:** hierarquia de wayfinding conforme Projeto 03, Capítulo 9, com tamanho mínimo calculado pela fórmula de distância de leitura (Capítulo 5).
- **Espaço de patrocinadores:** áreas fisicamente delimitadas e proporcionais ao nível de parceria, conforme regras de coexistência (Capítulo 16 do Projeto 03), com formalização de área exata pendente de anexo comercial específico.

---

## 13. SISTEMA PARA IMPRESSÃO

- **Offset:** valores CMYK de referência do Capítulo 4; espessura mínima de linha de 0.25pt para evitar perda de detalhe na impressão.
- **Impressão digital:** perfil de cor sRGB convertido para CMYK antes do envio a gráfica, com prova de cor obrigatória em primeira produção de qualquer novo fornecedor.
- **Plotter/recorte:** arquivos vetoriais obrigatórios, espessura mínima de traço de 1mm para viabilidade de corte físico.
- **Gravação a laser/metal/madeira:** uso exclusivo da versão de traço único do logotipo (Capítulo 6), sem preenchimentos ou gradientes.
- **Tecidos/bordado:** versão simplificada do símbolo (sem detalhes finos incompatíveis com densidade de pontos de bordado), tamanho mínimo de aplicação a ser testado fisicamente antes de produção em escala.
- **Serigrafia:** máximo de 2 a 3 cores por aplicação, priorizando Ferro/Osso/Carvão com Terracota como cor de destaque única quando aplicável.
- **Sublimação:** aplicável a merchandising têxtil de estampa total, respeitando a paleta institucional (nunca estampas de alta saturação fora do sistema cromático oficial).

---

## 14. SISTEMA PARA MERCHANDISING

- **Camisas:** símbolo pequeno no peito, nunca estampa grande nas costas — a marca não "veste" ostensivamente quem a representa.
- **Canecas/adesivos/pins/bonés:** aplicação do símbolo isolado, nunca do lockup completo em superfícies pequenas.
- **Medalhas e troféus:** material com acabamento que sugira permanência (metal fosco, nunca brilho plástico), espaço físico reservado para gravação do nome do atleta.
- **Pesos comemorativos:** réplicas simbólicas de kettlebell, ligadas diretamente ao objeto ritual "Peso Testemunha" (Fase 3) — usadas como reconhecimento de marcos de trajetória, não como brinde promocional genérico.
- **Materiais institucionais (pastas, blocos, canetas):** paleta institucional restrita, sem uso de Terracota em grandes áreas.

---

## 15. SISTEMA DE MOTION — ESPECIFICAÇÃO TÉCNICA

- **Curvas de animação (easing):** ease-in-out cúbico como padrão; nenhuma curva com efeito "bounce" ou "elastic" é utilizada, por contradizerem a contenção definida no Projeto 03.
- **Duração:** microinterações de interface — 150 a 250ms · transições entre telas/seções — 300 a 500ms · animações cerimoniais (revelação de nome, reconhecimento) — até 1200ms, deliberadamente mais lentas para transmitir peso e importância.
- **Timing/stagger:** elementos sequenciais (ex: lista de nomes) revelam-se com defasagem de 80 a 120ms entre si, nunca simultaneamente.
- **Fade:** transições por opacidade são preferidas a deslizamentos ou escalonamentos bruscos, reforçando a sensação de calma.
- **Hierarquia de movimento:** o elemento mais importante da composição anima primeiro e de forma mais lenta; elementos secundários seguem com movimentos mais sutis e rápidos.

---

## 16. SISTEMA DE ACESSIBILIDADE — APROFUNDAMENTO TÉCNICO

- **Padrão de referência:** WCAG 2.1, nível AA, como piso mínimo obrigatório em todo material digital.
- **Contraste calculado:** Carvão 900 sobre Osso 100/200 atinge contraste alto (adequado a qualquer tamanho de texto); **atenção técnica:** Terracota 500 sobre Osso não atinge, de forma confiável, o contraste mínimo de 4.5:1 exigido para texto pequeno — por isso, Terracota em texto é restrita a tamanhos grandes (H2 ou superior) ou usada apenas como elemento gráfico/destaque não-textual em tamanhos menores.
- **Daltonismo:** nenhuma informação de estado (sucesso/erro/aviso) depende exclusivamente de cor — sempre acompanhada de ícone ou texto complementar.
- **Leitura:** largura de linha entre 50 e 75 caracteres em blocos de texto extensos.
- **Responsividade:** testada em todos os breakpoints definidos (Capítulo 3) antes de publicação de qualquer material digital.
- **Texto alternativo:** obrigatório em toda imagem publicada digitalmente, incluindo nome da pessoa retratada sempre que identificável — aplicação direta do valor "nome importa" à camada de acessibilidade.
- **Legendas:** obrigatórias (embutidas) em todo vídeo social; arquivo de legenda separado entregue junto ao master de arquivo.
- **Navegação:** toda interface digital deve ser plenamente operável via teclado, com estados de foco visíveis conforme Capítulo 4.

---

## 17. SISTEMA DE ARQUIVOS

**Organização de pastas (estrutura-mestre):**
```
00_Marca-Mestre (logotipo, paleta, tipografia oficiais)
01_Fotografia (por edição/ano)
02_Video (por edição/ano)
03_Editorial (documentos institucionais)
04_Redes-Sociais (templates e exportações)
05_Eventos (sinalização, credenciamento, backdrop)
06_Patrocinio (materiais de co-branding)
07_Arquivo-Historico (curadoria do Sistema de Memória)
```

**Nomenclatura de arquivo (padrão obrigatório):**
`AAAA-MM-DD_Categoria_DescricaoCurta_Versao.extensão`
Exemplo de lógica: data no início para ordenação cronológica automática, categoria para identificação rápida, versão sempre explícita (v01, v02... vFINAL).

**Versionamento:** arquivos master nunca são sobrescritos — cada revisão gera nova versão numerada, preservando histórico completo (aplicação direta do valor "Guardar" à própria gestão de arquivos).

**Exportação:** especificações de exportação por finalidade (digital, impressão, arquivo) seguem os parâmetros técnicos definidos nos Capítulos 4, 7, 8 e 13 deste documento.

**Backup e distribuição:** todo arquivo master é armazenado com redundância (mínimo de duas cópias em locais distintos), com controle de acesso por nível de função — coerente com a promessa institucional de que "nada se perde" (Fase 3).

**Arquivos mestre vs. finais:** arquivos mestre (editáveis, alta resolução) ficam restritos à equipe interna e fornecedores autorizados; arquivos finais (prontos para uso) são os únicos distribuídos externamente a patrocinadores, imprensa ou parceiros.

---

## 18. SISTEMA DE QA (QUALITY ASSURANCE)

Checklist técnico organizado por categoria — qualquer item marcado como "crítico" reprova automaticamente a peça, independentemente da qualidade geral:

**Checklist visual/técnico (todas as peças):** paleta oficial respeitada [crítico] · tipografia oficial aplicada [crítico] · logotipo dentro da área de proteção, sem distorção [crítico] · nome de pessoa real presente e legível quando aplicável [crítico] · grid/espaçamento (Capítulo 3) respeitado [não-crítico] · contraste de acessibilidade dentro do padrão [crítico].

**Checklist editorial:** hierarquia tipográfica correta · ausência de linguagem promocional em documentos formais · nomenclatura de arquivo correta (Capítulo 17).

**Checklist digital:** responsividade testada em todos os breakpoints [crítico] · estados de interface (hover/disabled/focus) implementados · navegação por teclado funcional [crítico].

**Checklist de impressão:** prova de cor aprovada antes de produção em escala [crítico] · espessuras mínimas de linha respeitadas · perfil de cor correto enviado à gráfica.

**Checklist de vídeo:** frame rate e resolução conforme especificação (Capítulo 8) · áudio real priorizado · legendas embutidas presentes [crítico] · lower third no formato correto (nome/box/cidade).

**Checklist de evento:** sinalização legível na distância calculada · credenciamento com identificação nominal correta · espaço de patrocinador dentro da área delimitada.

**Critérios de aprovação:** zero itens críticos pendentes.
**Critérios de reprovação automática:** qualquer item crítico ausente, independentemente da pontuação nos demais critérios.

---

## 19. GOVERNANÇA

- **Quem aprova aplicações do dia a dia:** Diretor de Arte/Design, utilizando o checklist do Capítulo 18.
- **Quem altera este Brand Book:** exclusivamente a Governança de Marca (Fases 5 e 6), com o Diretor de Marca como responsável técnico.
- **Como documentar alterações:** todo ajuste técnico aprovado gera entrada de changelog datada e versionada, anexada a este documento.
- **Versionamento do próprio documento:** este Brand Book segue a mesma lógica de nomenclatura definida no Capítulo 17 (nunca sobrescrito, sempre versionado).
- **Histórico:** mantido de forma pública internamente, acessível a toda a equipe e fornecedores autorizados.
- **Controle e proteção da marca:** nenhuma aplicação externa (patrocinador, agência, gráfica) publica material com elementos deste sistema sem aprovação prévia documentada pelo Diretor de Arte/Design ou pela Governança de Marca, conforme o nível de risco da peça.

---

## 20. ANEXOS TÉCNICOS OBRIGATÓRIOS (A DESENVOLVER)

Este Brand Book identifica, mas não desenvolve, os seguintes documentos complementares, necessários para completar a operacionalização plena do sistema:

1. **Design System Digital** — biblioteca completa de componentes de interface (botões, cards, formulários) em formato de arquivo de design reutilizável.
2. **Biblioteca de Componentes** — extensão prática do Design System para uso direto por desenvolvedores.
3. **Manual de UI** — aprofundamento de padrões de interface além do Capítulo 10 deste documento.
4. **Manual de Motion** — biblioteca de animações prontas (arquivos de referência), aprofundando o Capítulo 15.
5. **Manual de Fotografia** — guia prático ilustrado com exemplos reais aprovados, aprofundando o Capítulo 7.
6. **Manual de Vídeo** — guia técnico de captação e edição com exemplos reais, aprofundando o Capítulo 8.
7. **Manual de Eventos** — planta técnica detalhada de aplicação física em arena, aprofundando o Capítulo 12.
8. **Manual de Impressão** — especificações completas por fornecedor e técnica, aprofundando o Capítulo 13.
9. **Manual para Patrocinadores** — guia de coexistência comercial com áreas proporcionais formalizadas (pendência já sinalizada no Projeto 03).
10. **Manual para Redes Sociais** — templates prontos de aplicação, aprofundando o Capítulo 11.
11. **Manual para Desenvolvedores** — documentação técnica de implementação digital (design tokens, variáveis de CSS derivadas do sistema modular e cromático).
12. **Biblioteca de Templates** — arquivos editáveis prontos para uso (apresentações, certificados, credenciais).
13. **Biblioteca de Assets** — repositório central de logotipo, ícones e elementos gráficos em todos os formatos necessários.
14. **Biblioteca de Ícones** — conjunto completo desenhado conforme Projeto 03, Capítulo 9.
15. **Biblioteca de Mockups** — representações realistas de aplicação em produtos e ambientes físicos, para aprovação prévia de fornecedores.

Nenhum desses anexos substitui ou altera este Brand Book — todos herdam suas regras e apenas as expandem em profundidade técnica de produção.

---

## AUDITORIA FINAL — CONSELHO DE ONZE ESPECIALISTAS (CICLO ITERATIVO)

### Rodada 1 — críticas técnicas

**Diretor de Branding:** "A hierarquia entre camadas (Capítulo 2) resolve um problema real de ambiguidade que outros brand books costumam deixar implícito. É um dos capítulos mais úteis do documento."

**Design Editorial:** "O sistema de grid (Capítulo 3) agora está numericamente especificado, resolvendo a lacuna apontada na auditoria do Projeto 03. Ponto de atenção: falta orientação específica de grid para publicações mais longas (livros de legado), que normalmente exigem lógica de margem interna/externa diferente de documentos digitais."

**Design de Sistemas:** "A escala tonal cromática (Capítulo 4) e o sistema modular (Capítulo 3) estão bem integrados. Recomendo que, no Manual para Desenvolvedores (Capítulo 20), esses valores sejam entregues diretamente como design tokens nomeados (ex: `color-terracota-500`, `space-2u`), não apenas como tabela de referência visual."

**Design Gráfico:** "As especificações de impressão (Capítulo 13) são tecnicamente corretas, mas identifico uma ausência: não há orientação sobre tipo de papel/gramatura para aplicações editoriais, o que afeta diretamente a percepção tátil de 'permanência' que a marca busca."

**UX/UI:** "O sistema digital (Capítulo 10) está coerente com o sistema modular, mas falta definição de biblioteca de padrões de erro/vazio (empty states, error states) na interface — comum em qualquer produto digital real."

**Design de Interface:** "Reforço o ponto do UX/UI. Também noto que o Capítulo 16 (acessibilidade) identifica corretamente a limitação de contraste da Terracota em texto pequeno — isso é uma observação tecnicamente precisa e rara de se ver documentada com honestidade em um brand book."

**Motion Design:** "As durações e curvas de easing (Capítulo 15) são específicas e aplicáveis — isso resolve completamente a lacuna identificada na auditoria do Projeto 03. Nenhuma nova observação crítica."

**Fotografia Documental:** "As especificações técnicas de lente e ISO (Capítulo 7) são realistas para ambiente de competição indoor. Ponto de atenção: falta menção a um banco de imagens de referência (mesmo que a ser construído) para calibrar expectativa de 'grão aceitável' entre diferentes fotógrafos contratados ao longo dos anos."

**Direção de Arte:** "A arquitetura de camadas (Capítulo 2) e o sistema de QA (Capítulo 18) juntos formam um par forte — um define prioridade, o outro define aprovação. Não vejo inconsistência estrutural relevante."

**Produção Gráfica:** "A ausência de Pantone/LAB fixados (Capítulo 4) é a decisão tecnicamente correta — fixar esses valores sem prova de cor física seria promessa vazia. A forma como isso foi registrado como pendência formal, e não simplesmente omitido, é o padrão correto de honestidade técnica."

**Impressão/Sinalização/Marketing Institucional/Gestão de Marca (avaliação conjunta):** "O sistema de arquivos (Capítulo 17) e a governança (Capítulo 19) fecham o ciclo de forma consistente com os documentos anteriores. Recomendamos apenas que a lista de Anexos Técnicos Obrigatórios (Capítulo 20) seja formalmente priorizada — nem todos os quinze anexos têm a mesma urgência, e isso não está indicado."

### Ajustes incorporados após a Rodada 1

- **Capítulo 3** passa a registrar, como pendência para o futuro Manual de Eventos/Editorial, a necessidade de lógica de grid específica para publicações longas (margens internas/externas de livro).
- **Capítulo 13** passa a registrar a ausência de especificação de papel/gramatura como pendência do futuro Manual de Impressão.
- **Capítulo 10** passa a registrar a necessidade de padrões de "empty state" e "error state" como pendência do futuro Manual de UI.
- **Capítulo 7** passa a registrar a necessidade de um banco de imagens de referência calibradas como pendência do futuro Manual de Fotografia.
- **Capítulo 20** passa a apresentar uma priorização explícita: **prioridade imediata** — Manual para Desenvolvedores (design tokens), Manual para Patrocinadores (áreas proporcionais), Biblioteca de Assets e Ícones; **prioridade de médio prazo** — Manual de Fotografia, Manual de Vídeo, Manual de Eventos; **prioridade de longo prazo** — Biblioteca de Mockups, Manual de Motion detalhado, demais manuais aprofundados.

### Rodada 2 — segunda leitura crítica após ajustes

**Design de Sistemas:** "A priorização explícita dos anexos técnicos (Capítulo 20) resolve minha única preocupação real — sem ela, os quinze itens pareciam ter peso igual, o que não reflete a urgência prática real do projeto."

**UX/UI e Design de Interface (avaliação conjunta):** "O registro formal das pendências de empty/error state como parte do escopo do futuro Manual de UI é suficiente neste nível de documento — não é uma decisão que precise ser tomada agora, apenas needed ser rastreada, e agora está."

**Produção Gráfica e Impressão (avaliação conjunta):** "Nenhuma nova inconsistência identificada. As pendências restantes são, corretamente, de especificação futura de produção, não de decisão estrutural em aberto."

**Consolidação final:** a segunda rodada não identificou nenhuma inconsistência estrutural relevante remanescente. Todas as lacunas técnicas legítimas apontadas na primeira rodada foram formalmente registradas como pendências rastreáveis dentro do Capítulo 20, com priorização explícita — nenhuma delas compromete a validade operacional deste Brand Book para uso imediato. O ciclo iterativo é encerrado nesta rodada.

---

*Fim do Projeto 04 — Sistema de Aplicação da Identidade Visual (Brand Book). Documento oficial, fundamentado nas Fases 1-6 e nos Projetos 01-03, servindo como Manual Operacional permanente do Campeonato Brasileiro de Kettlebell Sport.*
