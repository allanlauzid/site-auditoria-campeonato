# FASE 2 — IDENTIDADE ESTRATÉGICA
### Campeonato Brasileiro de Kettlebell Sport
### Pergunta central: Qual deve ser a identidade estratégica do campeonato?

*Documento-base: Fase 1 (Inteligência Estratégica) é referência permanente. Nada aqui é campanha, slogan, cronograma ou conteúdo — é definição de DNA.*

---

## ANTES DE COMEÇAR: QUESTIONANDO A FASE 1

A Fase 1 concluiu, por inferência, que a vantagem do campeonato está em "profundidade de pertencimento" e sugeriu a metáfora do evento como "casa". Essa conclusão não será tratada como verdade adquirida. Ela é **uma hipótese entre várias**, e será testada, atacada e comparada com alternativas neste documento — inclusive com o risco real de não sobreviver ao debate. Comunidade é uma tese forte, mas tese forte não é a mesma coisa que tese vencedora. Um conselho de especialistas que já chegasse à mesma conclusão da fase anterior sem contestá-la não estaria fazendo estratégia — estaria confirmando um viés.

---

## ETAPA 1 — QUAL É O VERDADEIRO PROBLEMA?

**Camada 1 — o problema aparente**
O Campeonato Brasileiro de Kettlebell Sport precisa crescer: mais inscritos, mais visibilidade, mais reconhecimento.

*Por quê isso ainda não acontece?*
Porque poucas pessoas fora do círculo já convertido conhecem o esporte ou o veem como uma opção real de treino/competição.

**Camada 2**
*Por que poucas pessoas conhecem o esporte?*
Porque o kettlebell sport, no Brasil, é comunicado quase exclusivamente para dentro — regras, categorias, critérios de pontuação, calendário federativo — uma linguagem que faz sentido para quem já pratica, mas que não dá a um estranho nenhum motivo emocional para se interessar.

**Camada 3**
*Por que a comunicação ficou presa nesse registro técnico?*
Porque, historicamente, quem construiu o esporte no Brasil (técnicos, atletas fundadores, federações) precisou primeiro conquistar **legitimidade esportiva** — provar que aquilo é um esporte de verdade, com regras, arbitragem e reconhecimento oficial. Esse trabalho é interno e regulatório por natureza. Ninguém, nesse processo, assumiu o papel de traduzir a excelência técnica em **desejo cultural** — que é um trabalho diferente, de fora para dentro.

**Camada 4**
*Por que legitimidade esportiva não gerou desejo cultural automaticamente?*
Porque são duas moedas diferentes. Legitimidade responde à pergunta "isso é sério?". Desejo cultural responde à pergunta "isso é para mim, e o que isso faz de mim?". Um esporte pode ser plenamente legítimo (regras, arbitragem, federação, ranking internacional) e, ainda assim, ser invisível na cabeça do público geral — porque nunca respondeu à segunda pergunta.

**Camada 5 — a causa fundamental**
*Por que isso importa tanto agora?*
Porque o problema real não é "conversão" (fazer quem já conhece se inscrever). É **existência categórica**: para a grande maioria dos brasileiros fisicamente ativos, "Kettlebell Sport" simplesmente não está no mapa mental de coisas que uma pessoa pode "ser" ou "se tornar" — do jeito que "eu quero fazer uma maratona", "quero fazer um CrossFit", "quero fazer um HYROX" já são frases que existem na cabeça de milhões de brasileiros mesmo antes de eles pesquisarem qualquer coisa.

**Conclusão da Etapa 1 (primeiros princípios):**
O Campeonato Brasileiro de Kettlebell Sport não tem, hoje, um problema de marketing de conversão. Tem um problema de **categoria inexistente na mente do público**. Antes de vender uma vaga, o esporte precisa primeiro *ocupar um lugar* — dar a alguém que nunca ouviu falar dele um motivo de existência emocional imediato. Isso muda completamente o que "identidade estratégica" precisa fazer: não é sobre embelezar uma comunicação já compreendida, é sobre **criar a categoria na cabeça de quem ainda não sabe que ela existe.**

Essa conclusão já reformula — sem descartar — a tese de "comunidade" da Fase 1: pertencimento é ótimo para reter quem já entrou, mas pertencimento sozinho não resolve o problema de existência categórica para quem está do lado de fora. Isso será central no debate da Etapa 5.

---

## ETAPA 2 — MAPA DE TERRITÓRIOS EMOCIONAIS

Cada modalidade de sucesso no mercado ocupa um território emocional específico na mente do atleta — não apenas um nicho técnico. Mapeando os territórios já ocupados (com base na leitura da Fase 1) e os vazios:

### Territórios já ocupados (evitar confronto direto)

| Território emocional | Quem já domina |
|---|---|
| Performance extrema / "o mais em forma da Terra" | CrossFit |
| Democratização do desempenho atlético / "para todo corpo" | HYROX |
| Superação primal / guerreiro / transformação pelo sofrimento | Spartan / OCR |
| Jornada pessoal / odisseia / conquista de vida | Ironman, Maratonas |
| Força bruta mensurável / "os números não mentem" | Powerlifting |
| Maestria técnica / prestígio olímpico | Weightlifting |
| Transformação estética / corpo como resultado visível | Bodybuilding/Fisiculturismo |
| Equilíbrio e bem-estar | Yoga, mobilidade |

### Territórios vazios ou subexplorados (oportunidade legítima)

- **Força controlada, não caótica** — nenhuma marca grande ocupa o oposto do "caos"/sofrimento extremo de CrossFit e Spartan. Há espaço para um território de domínio, respiração, ritmo — força como disciplina, não como descontrole.
- **Herança ancestral reinventada** — o kettlebell tem raiz histórica real (tradição russa militar e popular). Nenhum concorrente do benchmark tem uma narrativa de origem tão rica e nenhum a está usando.
- **Resistência da composição, não da explosão** — o formato de série contínua de até 10 minutos é psicologicamente distinto de 1-rep-max (powerlifting) ou WODs curtos (CrossFit). É um território de "sustentar a calma sob fadiga prolongada" que ninguém comunica.
- **Drama interior testemunhado** — nenhuma marca do benchmark transforma a tensão psicológica da prova (a luta contra si mesmo, visível no rosto e na respiração do atleta) no centro da narrativa.
- **Elite acessível** — weightlifting tem prestígio técnico mas pouca acessibilidade; HYROX tem acessibilidade mas pouco prestígio técnico. A combinação dos dois ainda não tem dono claro no Brasil.

**Conclusão da Etapa 2:** o Kettlebell Sport tem, na verdade, *múltiplos* territórios legitimamente disponíveis — o que é bom (opcionalidade) e arriscado (dispersão, se tentar ocupar todos ao mesmo tempo). A Etapa 3 transforma cada território em uma alternativa de posicionamento completa e testável.

---

## ETAPA 3 — SEIS ALTERNATIVAS DE POSICIONAMENTO

### Alternativa 1 — "Força Controlada"
**Ideia central:** o esporte não é sobre força bruta nem sofrimento extremo, mas sobre controle, ritmo e respiração sob carga — o oposto do caos.
**Promessa:** "Aqui, força é disciplina — não descontrole."
**Emoção predominante:** calma confiante, domínio.
**Transformação prometida:** de corpo reativo/indisciplinado para atleta controlado — "domina o peso, domina a mente".
**Público mais atraído:** adultos que valorizam técnica, público mais maduro, quem se afasta da cultura de treino caótico/extremo, praticantes de artes marciais.
**Público menos atraído:** buscadores de adrenalina e espetáculo, público jovem que consome conteúdo de alta intensidade.
**Vantagens:** diferenciação forte frente a CrossFit/Spartan; fiel à natureza técnica real do esporte; menor risco de lesão como narrativa (atrai público mais velho); sustentável.
**Desvantagens:** visualmente menos "explosivo" para redes sociais; difícil gerar hype e urgência.
**Riscos:** pode soar "sem energia" para quem busca intensidade — maioria do público de fitness em redes sociais.
**Potencial de diferenciação:** alto. **Crescimento longo prazo:** moderado-alto, mas lento. **Compatibilidade Brasil:** alta (mercado saturado de hype busca alternativa). **Compatibilidade Fase 1:** alta (dialoga com "traduzir tecnicidade em desejo").

### Alternativa 2 — "Tradição Reinventada"
**Ideia central:** o kettlebell tem raiz histórica real (tradição russa militar/popular) — posicionar o esporte como uma disciplina ancestral revivida para o atleta moderno.
**Promessa:** "Antes de ser esporte, era sobrevivência. Continue essa história."
**Emoção predominante:** reverência, orgulho de pertencer a algo maior que si.
**Transformação prometida:** de praticante de academia desconectado para portador de um ofício ancestral.
**Público mais atraído:** pessoas interessadas em cultura/história, treinadores que valorizam linhagem, quem busca sentido além da estética.
**Público menos atraído:** público jovem orientado a tendência e resultado imediato.
**Vantagens:** território totalmente livre; material riquíssimo de storytelling (história, ritual, ofício); diferenciação radical frente a marcas nascidas nos EUA (CrossFit, HYROX, Spartan).
**Desvantagens:** risco de soar acadêmico ou distante da cultura brasileira, já que a herança é russa, não nacional; difícil parecer "urgente" ou "agora".
**Riscos:** exotização, dissonância cultural — pode não converter emocionalmente sem uma execução muito cuidadosa.
**Potencial de diferenciação:** muito alto. **Crescimento longo prazo:** moderado (nicho cultural pode ter teto). **Compatibilidade Brasil:** média. **Compatibilidade Fase 1:** média-alta.

### Alternativa 3 — "Cabe na Sua Vida"
**Ideia central:** espelhar a lógica de democratização do HYROX, mas apoiada na vantagem real do kettlebell — pouco equipamento, adaptável a qualquer espaço, ideal para adultos com rotina real.
**Promessa:** "Você não precisa ser atleta profissional para ser um atleta."
**Emoção predominante:** orgulho de conquistar algo dentro da vida real, não apesar dela.
**Transformação prometida:** de "pessoa comum" para atleta competidor, sem abandonar a rotina.
**Público mais atraído:** adultos 30–50 anos, pais, iniciantes, quem se sente intimidado pela intensidade de culto do CrossFit.
**Público menos atraído:** atletas já competitivos que buscam exclusividade e prestígio.
**Vantagens:** maximiza mercado endereçável; segue fórmula já comprovada pelo HYROX; baixa barreira de entrada.
**Desvantagens:** risco de diluir prestígio para atletas avançados; pouco diferenciado do HYROX.
**Riscos:** território já fortemente ocupado — pode soar genérico.
**Potencial de diferenciação:** baixo-médio. **Crescimento longo prazo:** alto. **Compatibilidade Brasil:** alta. **Compatibilidade Fase 1:** média (conflita com "prestígio técnico" valorizado na Fase 1).

### Alternativa 4 — "O Campeonato-Casa" (tese original da Fase 1)
**Ideia central:** tratar o campeonato como um retorno anual — identidade, ritual, memória — não apenas um evento com data.
**Promessa:** "Não é uma prova. É um lugar que te espera todo ano."
**Emoção predominante:** pertencimento, saudade antecipada, orgulho coletivo.
**Transformação prometida:** de praticante isolado para membro de uma tribo com história.
**Público mais atraído:** comunidade já engajada, treinadores/donos de box, quem busca pertencimento.
**Público menos atraído:** atletas puramente competitivos e transacionais, indiferentes ao aspecto social.
**Vantagens:** difícil de copiar (vantagem estrutural de evento pequeno, per Fase 1); constrói retenção real.
**Desvantagens:** risco de se tornar insular/fechado, afastando novatos que se sentem "de fora de uma família já formada"; difícil escalar sem perder intimidade.
**Riscos:** pode estagnar o crescimento se a comunidade parecer fechada; depende inteiramente de execução de rituais reais — fácil de prometer, difícil de entregar.
**Potencial de diferenciação:** média-alta. **Crescimento longo prazo:** alto se bem executado, com risco real de teto se insular. **Compatibilidade Brasil:** alta (cultura brasileira valoriza calor humano/comunidade). **Compatibilidade Fase 1:** altíssima — é a tese original.

### Alternativa 5 — "O Laboratório da Performance Invisível"
**Ideia central:** posicionar o kettlebell sport como o esporte de força mais mensurável e "engenheirado" que existe — apelo a um público orientado a dados e otimização contínua.
**Promessa:** "Aqui, cada repetição é medida. Cada segundo, otimizado."
**Emoção predominante:** satisfação intelectual, controle, orgulho de maestria mensurável.
**Transformação prometida:** de quem treina sem entender por quê para atleta que domina o próprio corpo através de dados.
**Público mais atraído:** atletas analíticos, treinadores, profissionais de perfil técnico/engenharia, praticantes do "quantified self".
**Público menos atraído:** atletas casuais/sociais que não se importam com métricas.
**Vantagens:** forte diferenciação frente a concorrentes emocionais; conecta com tendência crescente de autoconhecimento por dados; atrai patrocínio de marcas de tecnologia/wearables.
**Desvantagens:** risco de soar frio, elitista, excludente para iniciantes; pouco material de storytelling emocional.
**Riscos:** reforça exatamente a percepção "técnica/fechada" que a Fase 1 identificou como barreira.
**Potencial de diferenciação:** alto. **Crescimento longo prazo:** médio (nicho analítico é menor). **Compatibilidade Brasil:** média (cultura brasileira é historicamente mais emocional que analítica no esporte). **Compatibilidade Fase 1:** baixa-média.

### Alternativa 6 — "O Duelo Silencioso"
**Ideia central:** a disputa real de uma série contínua de até 10 minutos não é contra o adversário — é contra a própria mente sob fadiga prolongada. O esporte é, no fundo, um confronto íntimo e visível.
**Promessa:** "A disputa real não é contra o adversário. É contra os últimos três minutos dentro de você."
**Emoção predominante:** tensão contida, coragem silenciosa, vulnerabilidade admirável.
**Transformação prometida:** de quem evita o desconforto para quem já se encontrou sob pressão e não quebrou.
**Público mais atraído:** pessoas que se identificam com narrativas de força mental, apreciadores de drama esportivo, público que consome conteúdo em vídeo.
**Público menos atraído:** quem busca uma experiência puramente social/leve, sem carga dramática.
**Vantagens:** potencial de storytelling e conteúdo audiovisual altíssimo (respiração, olhar, tensão); diferenciação total; usa o próprio formato real da prova (série longa e contínua) como dispositivo dramático — extremamente autêntico, não inventado.
**Desvantagens:** mais difícil de comunicar para quem nunca assistiu a uma prova; mais abstrato como "gancho" para iniciante.
**Riscos:** pode soar poético demais/vago sem execução visual de alto nível.
**Potencial de diferenciação:** altíssimo — nenhum concorrente usa essa moldura. **Crescimento longo prazo:** alto (excelente para imprensa e compartilhamento). **Compatibilidade Brasil:** alta (público brasileiro responde bem a narrativa emocional/drama). **Compatibilidade Fase 1:** alta — reforça reconhecimento individual e adiciona camada de drama pessoal.

---

## ETAPA 4 — MATRIZ COMPARATIVA (NOTAS 0–10)

| Critério | Alt.1 Força Controlada | Alt.2 Tradição Reinventada | Alt.3 Cabe na Sua Vida | Alt.4 Campeonato-Casa | Alt.5 Lab. Performance | Alt.6 Duelo Silencioso |
|---|---|---|---|---|---|---|
| Diferenciação | 8 | 9 | 4 | 7 | 8 | 10 |
| Memorabilidade | 6 | 7 | 5 | 9 | 5 | 9 |
| Escalabilidade | 6 | 5 | 9 | 5 | 5 | 7 |
| Autenticidade | 9 | 8 | 7 | 8 | 7 | 9 |
| Facilidade de comunicação | 6 | 5 | 9 | 6 | 4 | 6 |
| Potencial de comunidade | 6 | 6 | 7 | 10 | 4 | 7 |
| Potencial de patrocínio | 6 | 5 | 7 | 5 | 8 | 7 |
| Potencial de imprensa | 5 | 6 | 5 | 6 | 4 | 9 |
| Potencial de crescimento | 6 | 5 | 9 | 6 | 5 | 8 |
| Sustentabilidade longo prazo | 8 | 6 | 7 | 9 | 6 | 8 |
| **TOTAL (0–100)** | **66** | **62** | **69** | **71** | **56** | **80** |

**Justificativas-chave das notas mais decisivas:**

- **Diferenciação:** Alt.6 recebe nota máxima porque nenhum concorrente do benchmark usa o drama interior da prova como eixo central — é território genuinamente livre. Alt.3 recebe a nota mais baixa porque replica quase literalmente o posicionamento já consolidado do HYROX.
- **Potencial de comunidade:** Alt.4 recebe nota máxima porque é, por definição, a alternativa desenhada inteiramente em torno de pertencimento — mas isso não significa que vença sozinha, como o debate da Etapa 5 vai mostrar.
- **Potencial de imprensa:** Alt.6 se destaca porque drama humano é o material mais naturalmente "noticiável" e compartilhável entre as seis opções — imprensa e criadores de conteúdo gravitam para tensão narrativa visível.
- **Escalabilidade:** Alt.3 lidera porque tem a barreira de entrada mais baixa de todas — mas escalabilidade alta não compensa a baixa diferenciação nesse caso.
- **Sustentabilidade longo prazo:** Alt.4 e Alt.6 dividem a liderança — comunidade sustenta retenção; drama bem contado sustenta relevância cultural. Isso já é um indício de que a resposta final pode não estar em uma alternativa isolada.

A matriz aponta uma vencedora numérica clara (Alt.6, "Duelo Silencioso"), com Alt.4 ("Campeonato-Casa") em segundo lugar próximo. Isso por si só já é revelador — mas notas quantitativas nunca substituem debate qualitativo. É isso que a Etapa 5 faz.

---

## ETAPA 5 — O DEBATE

*(Cada especialista defende genuinamente uma posição. O objetivo aqui não é chegar a consenso rápido — é expor as tensões reais entre as alternativas.)*

**Branding** abre defendendo a Alternativa 6: "Território livre, autêntico ao formato real da prova, com potencial de imprensa altíssimo. Nenhuma outra opção cria uma marca tão impossível de confundir com concorrente."

**Marketing Esportivo** contesta: "Bonito no papel, mas abstrato demais como gancho de aquisição. Ninguém que nunca viu uma prova de kettlebell sport vai se emocionar com 'os últimos três minutos dentro de você' sem já ter assistido a uma competição. Isso funciona depois que a pessoa já está dentro — não antes. Eu defendo a Alternativa 3: é a única que resolve o problema real identificado na Etapa 1, que é *existência categórica*. Se ninguém sabe que o esporte existe, o primeiro trabalho é baixar a barreira de entrada, não aprofundar a poesia."

**Sociologia do Esporte** entra em defesa parcial da Marketing Esportivo, mas ataca a Alternativa 6 por outro ângulo: "Há um problema cultural na Alternativa 6 que ninguém mencionou: ela individualiza a competição — 'a luta é dentro de você'. Isso é uma moldura tipicamente americana, de individualismo heroico. O esporte brasileiro historicamente se organiza em torno de coletivo — torcida, clube, comunidade que sofre e vibra junto. Um posicionamento centrado no indivíduo isolado pode soar deslocado da forma como o brasileiro vive esporte."

**Branding** rebate: "Discordo que seja excludente ao coletivo. O duelo é individual, mas é *testemunhado* — alguém luta sozinho, mas na frente de quem conhece seu nome e sua história. Isso não é o lone wolf americano. É proximidade + drama. Aliás, essa combinação é exatamente onde a Alternativa 4 e a Alternativa 6 podem se encontrar, não competir."

**Construção de Comunidades** intervém defendendo a Alternativa 4 com convicção: "A Fase 1 já provou, com base comparativa sólida, que a maior vantagem estrutural de um evento pequeno é a intimidade que gigantes globais não conseguem replicar. Descartar 'Campeonato-Casa' agora, só porque uma matriz de pontos deu números um pouco maiores para outra opção, é ignorar a vantagem competitiva mais defensável que este projeto tem."

**Estratégia Competitiva** interrompe: "Concordo que 'Campeonato-Casa' é defensável — mas ela sozinha não resolve o problema fundamental da Etapa 1. Comunidade retém quem já entrou. Ela não faz ninguém de fora saber que o esporte existe. É uma estratégia de retenção travestida de identidade de aquisição. Aliás, dois riscos que a Fase 1 já sinalizou se aplicam aqui: risco de soar genérico ('mais um evento de nicho com comunidade bacana') e risco de insularidade."

**Psicologia do Consumidor** entra a favor da Alt.1 ("Força Controlada"): "Estou surpresa que ninguém tenha defendido com mais força a alternativa que menos depende de hype. O consumidor de fitness brasileiro está saturado de intensidade extrema como linguagem — CrossFit, Spartan, HYROX competem todos no mesmo território de 'sofra e prove'. Uma marca que promete controle, calma e domínio é psicologicamente contraintuitiva o suficiente para chamar atenção por contraste, sem depender de produção cara."

**Economia Comportamental** responde: "Controle e calma são ótimos para retenção e hábito — pessoas que valorizam maestria tendem a manter comportamento por motivação intrínseca, sem precisar de gatilhos artificiais de urgência. Mas, para aquisição inicial, esse tipo de mensagem tem baixa saliência: não gera desejo imediato, porque não ativa nenhuma emoção de alta intensidade. Isso combina mal com o problema real identificado na Etapa 1, que exige *criar uma categoria nova na cabeça de alguém* — isso normalmente exige uma emoção forte no primeiro contato, não sutileza."

**Storytelling** retoma a defesa da Alternativa 6, mas incorpora a crítica da Sociologia do Esporte: "E se o duelo silencioso não for vendido como solidão, mas como coragem *reconhecida*? A cena não é 'atleta sozinho contra si mesmo' — é 'atleta sob pressão, na frente de gente que sabe seu nome e torce por ele'. Isso muda tudo: vira uma história coletiva sobre um momento individual. Isso resolve a objeção da Sociologia e ainda aproveita a força estrutural que a Construção de Comunidades está defendendo com a Alternativa 4."

**Design de Experiência** formaliza a síntese que está emergindo: "O que estou ouvindo é que ninguém aqui está realmente defendendo uma alternativa pura sozinha — cada especialista está defendendo um *elemento* que a alternativa representa. Marketing Esportivo quer baixa barreira de entrada. Sociologia quer coletivo, não indivíduo isolado. Construção de Comunidades quer retenção e intimidade. Branding e Storytelling querem drama diferenciado e conteúdo forte. Psicologia do Consumidor quer contraste de tom. Isso não é sinal de indecisão — é sinal de que a resposta certa provavelmente não é escolher uma linha da matriz, é definir qual elemento é o núcleo emocional (a alma) e quais elementos são a estrutura que sustenta esse núcleo."

**Gestão de Grandes Eventos** faz a última objeção prática, endereçada a toda a mesa: "Um adendo operacional, para não perdermos o pé no chão: seja qual for a escolha, a Fase 1 já alertou que não temos aparato de mídia para imitar CrossFit. A boa notícia é que a Alternativa 6, ao contrário do que parece, é a mais barata de produzir bem — não exige um estúdio, exige uma câmera boa em cima do rosto e da respiração de quem está competindo. Isso é mais viável, hoje, do que qualquer aparato de produção em escala."

Nenhum especialista muda de posição por educação ou cansaço — a convergência que aparece no fim é genuína: quase todos concordam que o núcleo emocional mais forte é o drama do duelo (Alt.6), mas quase todos também concordam que esse núcleo, sozinho e sem camada coletiva/estrutural, tem um ponto cego real (excesso de individualismo, abstração para quem nunca viu a prova, ausência de mecanismo de retenção).

---

## ETAPA 6 — RECOMENDAÇÃO FINAL

Nenhuma das seis alternativas isoladas é suficientemente forte para ser, sozinha, a identidade estratégica completa do campeonato. A Alternativa 6 vence a matriz quantitativa e o debate qualitativo como *núcleo emocional* — mas o próprio debate expôs um ponto cego real: sozinha, ela corre risco de soar individualista e abstrata demais para quem ainda não conhece o esporte, e não resolve por si só o problema de retenção e pertencimento que a Fase 1 identificou como vantagem estrutural real do projeto.

Por isso, a recomendação final é uma **sétima alternativa, síntese deliberada — não uma média das seis, mas uma arquitetura de camadas**, em que cada elemento tem uma função clara:

### Alternativa 7 (síntese) — "O Duelo Testemunhado"

**Ideia central:** a competição de kettlebell sport é, na essência, um confronto silencioso e pessoal contra a própria fadiga e dúvida — mas esse confronto nunca é solitário: ele acontece diante de uma comunidade que conhece o nome, a história e a trajetória de quem está competindo. A coragem é individual; o reconhecimento é coletivo.

**Promessa:** "Você enfrenta sozinho. Mas nunca sozinho de verdade — porque aqui, todo mundo sabe seu nome."

**Núcleo emocional (de onde vem a diferenciação, a memorabilidade e o potencial de imprensa):** o drama contido do duelo interior — herdado da Alternativa 6.

**Camada estrutural (de onde vem a retenção e a vantagem competitiva de longo prazo):** o campeonato como "casa" — ritual anual, reconhecimento pessoal, camadas de pertencimento (atleta, coach, box, cidade) — herdado da Alternativa 4 e diretamente alinhado à tese central da Fase 1.

**Camada de tom/registro (de onde vem a diferenciação de linguagem frente a CrossFit/Spartan):** controle, disciplina e composição em vez de caos e sofrimento extremo — herdado da Alternativa 1, usado como *estilo de comunicação*, não como posicionamento central.

**Elementos conscientemente descartados como núcleo (mas preserváveis como camadas secundárias de conteúdo, não de identidade):**
- *Tradição Reinventada* (Alt.2): rica demais para descartar completamente, mas arriscada como base — vira material narrativo esporádico (uma "origem" contada de tempos em tempos), não a espinha dorsal da marca.
- *Cabe na Sua Vida* (Alt.3): útil como mensagem de porta de entrada para iniciantes dentro da comunicação, mas perigosa como identidade central por já pertencer ao HYROX.
- *Laboratório da Performance* (Alt.5): mantida como linguagem específica para o público avançado/analítico (rankings, métricas de evolução), mas não como tom geral — o frio demais para ser a alma da marca.

**Por que essa síntese é superior às seis alternativas isoladas:**

1. Resolve diretamente o problema de raiz identificado na Etapa 1 (existência categórica): o drama do duelo testemunhado é um gancho emocional forte o bastante para fazer alguém que nunca ouviu falar do esporte parar e prestar atenção — algo que "Campeonato-Casa" sozinho não faz tão bem, porque comunidade só se sente depois que já se está dentro.
2. Resolve o ponto cego identificado no debate (individualismo excessivo): ao testemunhar o duelo dentro de uma comunidade que reconhece o atleta pelo nome, a narrativa deixa de ser "eu contra mim mesmo" e passa a ser "eu, visto e sustentado por quem me conhece" — compatível com a cultura esportiva coletivista brasileira apontada pela Sociologia do Esporte.
3. Preserva a vantagem estrutural mais defensável identificada na Fase 1 (intimidade impossível de replicar em escala) como *mecanismo de retenção*, sem depender dela como único gancho de aquisição.
4. É operacionalmente viável no estágio atual do projeto — não exige aparato de mídia de escala CrossFit; exige apenas produção de vídeo bem executada em cima de rostos, respiração e tensão real da prova, algo já reconhecido como acessível pela Gestão de Grandes Eventos no debate.
5. Evita os dois riscos mais citados no benchmark da Fase 1 — soar genérico (evitado por não copiar o território já ocupado pelo HYROX) e soar elitista/intimidador (evitado por manter o tom de controle/disciplina em vez de sofisticação técnica fria).

---

## SÍNTESE DA FASE 2 — O DNA ESTRATÉGICO

**Identidade estratégica recomendada:** *O Duelo Testemunhado* — um esporte onde a coragem é individual, mas o reconhecimento é coletivo; onde a força se expressa como controle e disciplina, não como caos; e onde cada atleta é lembrado pelo nome, ano após ano, por uma comunidade que sabe exatamente o que aquele duelo custou.

Este DNA — não uma campanha, não um slogan, não um calendário — passa a ser a referência oficial para todas as próximas fases do projeto, em conjunto com o documento da Fase 1.
