# MANUAL DO DASHBOARD EXECUTIVO
### Campeonato Brasileiro de Kettlebell Sport
### Manual Operacional Permanente

*Opera dentro dos princípios dos Projetos 01, 06, 07, 08, 09, 10 e 11, e de toda a Constituição anterior — sem autoridade para alterá-los. Este manual não cria dashboards, telas, gráficos ou banco de dados — cria o sistema permanente que qualquer Dashboard Executivo futuro, em qualquer plataforma de BI, deve seguir.*

---

## 1. FILOSOFIA DO DASHBOARD

**Objetivo:** reduzir incerteza na tomada de decisão — o dashboard não existe para medir tudo o que é possível medir, existe para medir exatamente aquilo que ajuda alguém a decidir melhor.

**Papel institucional:** ser a fonte única de leitura executiva consolidada de todos os sistemas já constitucionais (Projetos 06 a 11), evitando que diferentes áreas operem com números divergentes sobre a mesma realidade.

**Como apoia decisões:** cada indicador exibido está formalmente vinculado a uma decisão real de algum sistema já existente — nunca um número solto "porque é interessante saber".

**Como protege a marca:** ao priorizar indicadores de profundidade (retenção, precisão de previsão, completude de memória) sobre métricas de vaidade (alcance bruto isolado), o dashboard reforça, na prática diária de gestão, a mesma filosofia de longo prazo já estabelecida desde a Fase 1.

**O que nunca deve acontecer:** indicador sem responsável definido; indicador sem interpretação clara; indicador que existe apenas porque é fácil de medir, não porque é útil; qualquer decisão relevante tomada ignorando o dashboard em favor de percepção informal não verificada.

---

## 2. ARQUITETURA GERAL

**Níveis de informação:**
1. **Resumo executivo** — poucos números, os mais decisivos, no topo de qualquer visualização.
2. **Tático** — indicadores por área (Capítulo 3), acessados conforme a função de quem consulta.
3. **Detalhamento (drill-down)** — possibilidade de aprofundar qualquer número até sua origem, sem exigir isso por padrão.
4. **Histórico** — comparação com edições anteriores, sempre disponível, nunca escondida.

**Hierarquia:** a posição e o destaque visual de um indicador refletem sua importância real para decisão, nunca apenas disponibilidade técnica do dado.

**Relacionamentos:** indicadores de diferentes áreas são conectados quando relevantes (ex: interesse pré-inscrição relacionado a dimensionamento operacional), nunca apresentados como painéis isolados sem relação entre si.

---

## 3. PERFIS DE USUÁRIO

| Perfil | Decisões que precisa tomar |
|---|---|
| Presidência | Direção estratégica geral, aprovação de investimento maior, avaliação de saúde institucional. |
| Coordenação Geral | Integração entre áreas, resolução de conflito de prioridade entre centros (Projeto 09). |
| Marketing | Ajuste de comunicação e mobilização (Projeto 10). |
| Comercial | Priorização de negociação, argumento de valor real a patrocinadores (Projeto 06). |
| Operação | Dimensionamento físico e logístico (Projeto 09). |
| Produção | Ajuste de recursos técnicos de montagem e execução. |
| Comunicação | Calibração de conteúdo e canais (Projeto 01/10). |
| Patrocínio | Avaliação de retorno e renovação (Projeto 05). |
| Arbitragem | Monitoramento de consistência técnica (Fase 5). |
| Memória | Completude e qualidade do acervo histórico (Projeto 08). |
| Inteligência | Precisão de previsão e qualidade de dado (Projeto 11). |

---

## 4. ARQUITETURA DOS INDICADORES

- **Estratégicos:** usados pela Presidência e Governança de Marca, refletem saúde institucional de longo prazo (Fase 6).
- **Táticos:** usados por diretores de área, apoiam decisões de médio prazo dentro de um ciclo de edição.
- **Operacionais:** usados em tempo real durante a operação do evento (Projeto 09), exigem atualização imediata.
- **Históricos:** comparam edições ao longo do tempo (Projeto 08), fundamentam decisões de tendência.
- **Preditivos:** projeções baseadas no Sistema de Inteligência Pré-Inscrição (Projeto 11), usadas para planejamento antecipado.

Cada indicador pertence a exatamente uma dessas categorias, evitando ambiguidade sobre seu uso pretendido.

---

## 5. CATÁLOGO DE KPIs — PRINCÍPIOS POR INDICADOR

Cada KPI listado obedece à mesma estrutura obrigatória de definição:

- **Interesse pré-inscrição** — definição: volume de manifestação de interesse válida (Projeto 11); objetivo: antecipar demanda; interpretação: sempre lida junto à taxa de conversão histórica, nunca isoladamente; frequência: diária durante a macrofase de Escuta (Projeto 10); responsável: Inteligência; decisão associada: calibração de comunicação regional e dimensionamento preliminar.
- **Conversão** — definição: proporção de interesse que se torna inscrição confirmada; objetivo: medir eficácia e alinhamento de expectativa; interpretação: queda abrupta pode indicar desalinhamento de comunicação, não apenas fraqueza comercial; frequência: semanal; responsável: Marketing/Comercial; decisão: ajuste de mensagem ou de processo de inscrição.
- **Distribuição geográfica** — definição: participação por estado/cidade/região; objetivo: orientar logística e expansão; interpretação: sempre comparada ao histórico (Projeto 08); frequência: semanal, tempo real próximo à abertura; responsável: Operação/Inteligência; decisão: dimensionamento e priorização regional.
- **Crescimento da comunidade** — definição: variação de interesse e participação ano a ano; objetivo: medir saúde de longo prazo; interpretação: sempre lida junto à retenção, nunca isoladamente; frequência: por edição/anual; responsável: Governança de Marca; decisão: estratégica, de expansão (Fase 5).
- **Participação por categoria/modalidade** — definição: volume por categoria técnica; objetivo: dimensionar operação técnica; interpretação: concentração excessiva sinaliza risco operacional (Projeto 09); frequência: semanal, próximo à abertura; responsável: Coordenação Técnica; decisão: ajuste de formato/logística.
- **Atletas estreantes vs. recorrentes** — definição: proporção de novos e retornantes; objetivo: distinguir crescimento real de simples retenção; interpretação: os dois são positivos, mas exigem leitura estratégica diferente; frequência: por edição; responsável: Governança de Marca; decisão: calibração de investimento em aquisição vs. retenção.
- **Retenção** — definição: proporção de atletas que retornam em edições subsequentes; objetivo: indicador central de saúde de longo prazo (Fase 6); interpretação: mais importante que crescimento bruto isolado; frequência: por edição; responsável: Governança de Marca; decisão: revisão de experiência (Projeto 07) se em queda.
- **Patrocínios** — definição: taxa de renovação e satisfação (Projeto 05/06); objetivo: sustentabilidade financeira; interpretação: sempre lida junto ao ROI institucional, não apenas financeiro; frequência: por ciclo contratual; responsável: Comercial; decisão: ajuste de proposta de valor.
- **Engajamento** — definição: interação real com conteúdo institucional; objetivo: medir conexão genuína, não alcance passivo; interpretação: sempre contextualizada por tipo de conteúdo (Projeto 10, Capítulo 6); frequência: semanal; responsável: Comunicação; decisão: ajuste de linha editorial.
- **Alcance** — definição: volume bruto de visualização; objetivo: indicador de menor peso relativo, nunca decisório isoladamente; interpretação: sempre lido junto a engajamento e conversão; frequência: semanal; responsável: Comunicação; decisão: apoio secundário, nunca decisão isolada.
- **Operação** — definição: aderência a marcos operacionais (Projeto 09, Capítulo 18); objetivo: confiabilidade de execução; interpretação: desvio sinaliza risco imediato; frequência: tempo real durante evento; responsável: Direção Geral; decisão: intervenção operacional imediata.
- **Experiência** — definição: satisfação e memorabilidade (Projeto 07, Capítulo 18); objetivo: medir cumprimento da promessa central da marca; interpretação: queda exige investigação qualitativa, não apenas numérica; frequência: por edição; responsável: Coordenação de Experiência; decisão: ajuste de rituais/logística de experiência.
- **Memória** — definição: completude do acervo histórico (Projeto 08, Capítulo 17); objetivo: garantir cumprimento da promessa "nós guardamos"; interpretação: lacunas indicam falha operacional de captação, não apenas administrativa; frequência: por edição; responsável: Curadoria; decisão: reforço de captação na edição seguinte.

---

## 6. SISTEMA DE ALERTAS

**Quando gerar um alerta:** desvio significativo e confirmado entre previsão e realidade (Projeto 11, Capítulo 9); categoria se aproximando do limite operacional previsto (Projeto 09); queda abrupta e não explicada de indicador crítico (retenção, conversão).

**Quando não gerar um alerta:** flutuação dentro da margem histórica normal de variação — alertas excessivamente sensíveis geram fadiga de alerta e reduzem a atenção real dada aos alertas que de fato importam.

**Limiares:** definidos tecnicamente por indicador (Capítulo 5), sempre calibrados com base em dado histórico real, nunca em valor arbitrário sem lastro.

**Anomalias e tendências:** distinguidas explicitamente — uma anomalia é um desvio pontual; uma tendência é um padrão sustentado ao longo de múltiplas leituras. O sistema trata as duas de forma diferente, nunca reagindo a um único ponto fora da curva como se fosse tendência confirmada.

---

## 7. SISTEMA DE VISUALIZAÇÃO

Os mesmos princípios de honestidade estatística já formalizados no Manual dos Stories Baseados em Dados se aplicam integralmente aqui, com o mesmo rigor: gráficos sem distorção de eixo, mapas com proporção fiel, comparações sempre rotuladas, percentuais sempre com base declarada. Cartões de indicador exibem sempre número **e** contexto mínimo (nunca apenas o número isolado). Cores têm significado consistente e nunca decorativo — uma cor de alerta significa sempre a mesma coisa em qualquer painel do sistema. **Prioridade permanente:** clareza e precisão acima de qualquer consideração estética.

---

## 8. STORYTELLING EXECUTIVO

Toda apresentação de dados a um gestor responde, nesta ordem: **o que aconteceu** (fato objetivo) → **por que aconteceu** (contexto e causa, quando disponível) → **quais impactos existem** (conexão com outras áreas e indicadores, Capítulo 2) → **quais decisões são recomendadas** (ação concreta, nunca apenas dado bruto entregue sem direção). Um dashboard executivo que entrega apenas o primeiro passo desta sequência está incompleto, mesmo que tecnicamente correto.

---

## 9. INTEGRAÇÃO

Este dashboard consolida, sem duplicar, os dados já produzidos pelos Projetos 06 a 11 — nunca recoleta o que outro sistema já captura. **Princípio de fonte única:** cada dado tem exatamente uma origem primária rastreável, mesmo quando aparece em múltiplos painéis, mesmo princípio já fixado no Projeto 11, Capítulo 8.

---

## 10. GOVERNANÇA DOS DADOS

**Origem:** todo indicador é rastreável até seu sistema-fonte primário (CRM, Sistema de Memória, Sistema de Inscrições, etc.).

**Responsáveis:** cada indicador tem um responsável nomeado (Capítulo 5), nunca "a equipe" de forma genérica.

**Validação:** segue o mesmo protocolo já constitucional (Projeto 11, Capítulo 5) antes de qualquer exibição executiva.

**Atualização e versionamento:** conforme frequência definida (Capítulo 12), com histórico de mudança de definição de indicador sempre preservado, nunca sobrescrito silenciosamente.

**Auditorias:** revisão periódica formal (Capítulo 18).

**Confiabilidade e rastreabilidade:** nenhum número aparece no dashboard sem poder ser explicado, até sua fonte primária, por quem o consulta.

---

## 11. QUALIDADE DOS INDICADORES

Medida por: **completude** (dado disponível para todo o período relevante) · **consistência** (mesma definição aplicada uniformemente) · **precisão** (proximidade entre indicador e realidade) · **atualização** (aderência à frequência definida) · **confiabilidade** (ausência de erro sistemático) · **relevância** (ainda apoia decisão real, Capítulo 15) · **comparabilidade** (metodologia estável ao longo do tempo, Projeto 11, Capítulo 14).

---

## 12. FREQUÊNCIA DE ATUALIZAÇÃO

- **Tempo real:** indicadores operacionais durante a execução do evento (Projeto 09).
- **Diariamente:** interesse pré-inscrição durante a macrofase de Escuta (Projeto 10/11).
- **Semanalmente:** engajamento, conversão, distribuição geográfica.
- **Mensalmente:** KPIs de marca de acompanhamento contínuo (Fase 6).
- **Por edição:** retenção, experiência, memória, patrocínio.
- **Anualmente:** inteligência de mercado de longo prazo (Projeto 10, Capítulo 9).

Cada frequência é justificada pela velocidade real de mudança do fenômeno medido — nunca por conveniência técnica de coleta.

---

## 13. SISTEMA DE TOMADA DE DECISÃO

- **Quando agir:** desvio crítico confirmado (não apenas um ponto isolado) em indicador com decisão associada clara (Capítulo 5).
- **Quando monitorar:** desvio leve, ainda dentro do aceitável, mas digno de acompanhamento próximo.
- **Quando investigar:** padrão anômalo sem explicação evidente — antes de qualquer ação, entender a causa.
- **Quando comunicar:** marco relevante, positivo ou negativo, que afeta percepção de múltiplas áreas.
- **Quando escalar:** qualquer desvio que toque em elemento constitucional protegido (rituais, valores, promessas centrais) sobe imediatamente à Governança de Marca, mesma lógica já aplicada em toda a Constituição.

---

## 14. SEGURANÇA E ACESSO

**Níveis de acesso:** definidos por perfil (Capítulo 3), nunca acesso irrestrito universal.

**Permissões:** visualizar, exportar e editar são níveis distintos — a maioria dos perfis visualiza; exportação é restrita e registrada; edição de definição de indicador é exclusiva da função de Inteligência, sob validação da Governança de Marca.

**Proteção de dados e LGPD:** nenhum dado pessoal identificável aparece em visão agregada executiva sem necessidade real — a maioria das decisões estratégicas não exige saber o nome individual por trás de um número, apenas o padrão agregado.

**Compartilhamento:** apenas dentro do escopo formalmente aprovado; versões para patrocinadores seguem tratamento específico (Capítulo 17).

**Exportação:** sempre registrada, nunca anônima.

**Registro de acessos:** log formal de quem acessou qual informação e quando, coerente com o princípio de rastreabilidade (Capítulo 10).

---

## 15. ROADMAP DE EVOLUÇÃO

**Como incorporar novo indicador:** aplicando o mesmo teste de propósito já usado em todo o sistema — "isso apoia uma decisão real que hoje não é apoiada?"

**Como aposentar indicador:** quando deixa de gerar decisão real ao longo do tempo, documentando formalmente a descontinuação, nunca apenas removendo silenciosamente.

**Como manter comparabilidade histórica:** qualquer mudança de metodologia preserva a série histórica anterior de forma explícita e documentada, nunca substituindo silenciosamente o significado de um indicador já usado por anos.

---

## 16. ROADMAP DE IMPLEMENTAÇÃO

**Dependências:** implementação real depende de que as fontes de dado (CRM, Sistema de Memória, Sistema de Inteligência Pré-Inscrição) estejam minimamente maduras e integradas (Projeto 11, Capítulo 15) — um dashboard não pode ser mais confiável do que suas fontes.

**Boas práticas:** nenhuma ferramenta específica de BI é exigida por este manual — qualquer plataforma que suporte os princípios de rastreabilidade (Capítulo 10) e níveis de acesso (Capítulo 14) é compatível, mesmo princípio de não-dependência de fornecedor único já usado nos Projetos 08 e 09.

**Critérios de implantação:** validação com um perfil de usuário real (Capítulo 3) antes de expansão para todos os perfis simultaneamente, permitindo ajuste com base em uso real, não apenas desenho teórico.

---

## 17. CASOS ESPECIAIS

- **Presidência/Conselho:** visão mais alta possível, menor volume de detalhe, foco total em indicadores estratégicos (Capítulo 4).
- **Patrocinadores:** nunca recebem acesso direto ao dashboard interno completo — recebem versão adaptada e exportável, seguindo as mesmas regras de compartilhamento de dado já definidas no Sistema de Patrocínios (Projeto 05/06).
- **Coordenação Técnica:** foco em indicadores de integridade competitiva (arbitragem, categorias).
- **Marketing/Comercial/Operação:** conforme perfis já detalhados no Capítulo 3.
- **Memória:** foco em indicadores históricos e de completude patrimonial (Projeto 08).
- **Comunidade (público geral):** nunca acessa o dashboard bruto — recebe dados já tratados e contextualizados exclusivamente pelo Manual dos Stories Baseados em Dados, preservando a distinção entre informação executiva interna e comunicação pública.

---

## 18. SISTEMA DE AUDITORIA

**Como auditar dashboards:** revisão periódica formal de se cada indicador ainda apoia decisão real (Capítulo 15), não apenas se os números continuam tecnicamente corretos.

**Como validar indicadores:** reconferência de cálculo contra a fonte primária (Capítulo 10).

**Como detectar erros:** comparação sistemática entre o valor exibido e a fonte primária original.

**Como revisar definições:** processo formal e documentado de ajuste de definição de KPI ao longo dos anos, nunca alteração informal.

**Como manter consistência entre edições:** aplicação da mesma metodologia (Capítulo 11), auditada a cada novo ciclo.

---

## 19. ROADMAP DE DOCUMENTOS DERIVADOS

1. **Manual dos KPIs** — aprofundamento técnico completo do Capítulo 5.
2. **Manual dos Indicadores Operacionais** — aprofundamento específico do Projeto 09.
3. **Manual dos Indicadores Comerciais** — aprofundamento específico dos Projetos 05/06.
4. **Manual dos Indicadores de Marketing** — aprofundamento específico dos Projetos 01/10.
5. **Manual dos Indicadores da Experiência** — aprofundamento específico do Projeto 07.
6. **Manual de Visualização de Dados** — aprofundamento técnico do Capítulo 7.
7. **Manual de Storytelling Executivo** — aprofundamento técnico do Capítulo 8.
8. **Manual de Governança dos Dados** — aprofundamento técnico do Capítulo 10.

**Prioridade de desenvolvimento:** **prioridade 1** — Manual dos KPIs e Manual de Governança dos Dados, pré-requisitos técnicos de qualquer implementação real; **prioridade 2** — Manuais de Indicadores Operacionais, Comerciais, de Marketing e de Experiência, que aprofundam cada área específica; **prioridade 3** — Manual de Visualização de Dados e Manual de Storytelling Executivo, que tornam a informação já validada acessível e compreensível.

---

## AUDITORIA FINAL — CONSELHO DE ONZE ESPECIALISTAS (CICLO ITERATIVO)

### Rodada 1 — críticas técnicas

**Business Intelligence:** "A Arquitetura Geral em níveis (Capítulo 2) e o princípio de fonte única (Capítulo 9) são exatamente as decisões estruturais corretas para evitar o problema mais comum de dashboards executivos — múltiplas versões da verdade circulando simultaneamente. Nenhuma inconsistência estrutural."

**Ciência de Dados:** "O Sistema de Alertas (Capítulo 6), com distinção explícita entre anomalia pontual e tendência sustentada, é tecnicamente correto e evita o erro comum de reagir a ruído estatístico como se fosse sinal real. Nenhuma inconsistência."

**Analytics:** "O Catálogo de KPIs (Capítulo 5) está completo e bem estruturado. Recomendo apenas que fique explícito como lidar com um KPI que, ao longo do tempo, revela correlação forte com outro já existente — hoje o documento não define se KPIs redundantes devem ser consolidados."

**Estatística:** "A qualidade dos indicadores (Capítulo 11) cobre bem as dimensões técnicas relevantes. Sugiro que a 'precisão' explicitamente inclua menção a margem de erro ou intervalo de confiança quando aplicável a indicadores preditivos (Capítulo 4), não apenas a indicadores descritivos."

**UX para Dashboards:** "O Storytelling Executivo (Capítulo 8) é uma estrutura sólida e replicável. Nenhuma inconsistência."

**Gestão Estratégica:** "A vinculação obrigatória entre cada indicador e uma decisão real (Capítulo 1) é a decisão filosófica mais importante do documento — evita a armadilha comum de dashboards que impressionam mas não orientam nada. Nenhuma inconsistência."

**Data Storytelling:** "A ordem fixa 'o que, por que, impacto, decisão' (Capítulo 8) é coerente com boas práticas reais de comunicação executiva de dados. Nenhuma inconsistência."

**Governança de Dados:** "O Capítulo 10 está bem alinhado aos princípios já estabelecidos no Projeto 11. Recomendo reforçar que a rastreabilidade (todo número explicável até a fonte) deve ser tecnicamente verificável a qualquer momento por auditoria, não apenas uma promessa declarativa — já implícito, mas vale explicitar como requisito de auditoria formal (Capítulo 18)."

**Marketing Esportivo:** "A separação clara entre dashboard interno completo e versão adaptada para patrocinadores (Capítulo 17) protege corretamente tanto a confidencialidade interna quanto a relação comercial. Nenhuma inconsistência."

**Inteligência de Mercado:** "A distinção de frequência entre inteligência de mercado anual (Capítulo 12) e inteligência pré-inscrição mais frequente está coerente com o que já foi definido no Projeto 10/11. Nenhuma inconsistência."

**Design da Informação:** "O Sistema de Visualização (Capítulo 7), com cores de significado consistente entre painéis, é uma boa prática frequentemente negligenciada em sistemas reais. Nenhuma inconsistência."

### Ajustes incorporados após a Rodada 1

- **Capítulo 5** passa a prever que, quando dois KPIs revelarem correlação forte e sustentada ao longo de múltiplos ciclos, a Governança de Marca avalia formalmente se devem ser consolidados ou mantidos separados por servirem decisões distintas — nunca uma decisão automática, sempre avaliada caso a caso.
- **Capítulo 11** passa a incluir explicitamente que indicadores preditivos (Capítulo 4) devem comunicar margem de erro ou grau de confiança junto ao valor projetado, nunca apresentando uma previsão como se tivesse a mesma certeza de um dado descritivo já consolidado.
- **Capítulo 18** passa a exigir explicitamente que a rastreabilidade de qualquer número (Capítulo 10) seja tecnicamente verificável em auditoria formal, não apenas declarada como princípio — toda auditoria deve incluir teste real de rastreamento de amostra de indicadores até a fonte primária.

### Rodada 2 — segunda leitura crítica após ajustes

**Analytics:** "O processo formal de avaliação de KPIs correlacionados resolve minha observação — evita tanto a duplicação desnecessária quanto a eliminação precipitada de indicadores que podem servir propósitos distintos apesar da correlação."

**Estatística:** "A exigência de margem de erro ou grau de confiança em indicadores preditivos resolve exatamente o ponto que levantei. Tecnicamente correto."

**Governança de Dados:** "A exigência de teste real de rastreamento em auditoria formal, não apenas declaração de princípio, transforma rastreabilidade de promessa em prática verificável. Resolve minha observação."

**Consolidação final:** a segunda rodada não identificou nenhuma inconsistência estrutural relevante remanescente. Todos os ajustes da primeira rodada foram incorporados como princípios formais, reforçando tanto o rigor técnico quanto a utilidade decisória do sistema. O ciclo iterativo é encerrado nesta rodada.

---

*Fim do Manual do Dashboard Executivo. Documento oficial, fundamentado em toda a Constituição do projeto (Fases 1-6, Projetos 01-11), servindo como padrão permanente para qualquer Dashboard Executivo do Campeonato Brasileiro de Kettlebell Sport.*
