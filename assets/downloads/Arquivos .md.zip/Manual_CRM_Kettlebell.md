# MANUAL DO CRM
### Campeonato Brasileiro de Kettlebell Sport
### Manual Operacional Permanente

*Opera dentro dos princípios dos Projetos 01, 06, 07, 08, 09, 10 e 11, e de toda a Constituição anterior — sem autoridade para alterá-los. Este manual não escolhe plataforma, não cria automação nem integração técnica — cria o sistema permanente que qualquer CRM futuro, em qualquer tecnologia, deve seguir.*

---

## 1. FILOSOFIA DO CRM

**Objetivo:** o CRM não é uma lista de contatos — é o registro vivo do relacionamento entre a organização e cada pessoa que já se envolveu com o campeonato, em qualquer papel.

**Papel institucional:** é o sistema nervoso central de relacionamento, conectando tecnicamente tudo o que os Projetos 06 a 11 já definiram como princípio.

**Como fortalece a comunidade:** garantindo que ninguém precise se apresentar duas vezes — o sistema já reconhece quem a pessoa é e o que já viveu com o campeonato, aplicação direta e literal da promessa "nós guardamos" (Fase 3).

**Como protege a memória institucional:** o CRM alimenta e é alimentado pelo Sistema de Memória (Projeto 08) — relacionamento presente e patrimônio histórico são a mesma coisa vista em momentos diferentes do tempo.

**O que nunca deve acontecer:** uma pessoa ser tratada como número ou "lead" genérico; histórico de relacionamento perdido por falha técnica ou trocas de plataforma; qualquer dado usado fora do propósito pelo qual foi coletado.

---

## 2. ARQUITETURA GERAL

**Entidades centrais:** **Pessoa** (unidade central de todo o sistema, mesmo princípio já constitucional desde o Projeto 08, Capítulo 2) · **Organização** (boxes, patrocinadores, parceiros, federações) · **Edição/Evento** · **Interação** (todo contato registrado).

**Relacionamentos:** uma pessoa pode acumular múltiplos papéis ao longo do tempo (ser atleta e também treinador, ou voluntário e também árbitro) — o sistema nunca cria cadastros duplicados por papel; um único registro de pessoa acumula todos os papéis que ela já exerceu.

**Hierarquia:** a Pessoa está sempre acima do perfil funcional (Capítulo 3) — o perfil é um atributo da pessoa, nunca o contrário.

**Princípio geral:** nenhuma entidade existe isolada — toda organização, edição e interação está conectada a pelo menos uma pessoa, coerente com a arquitetura já estabelecida no Sistema de Memória.

---

## 3. PERFIS CADASTRADOS

- **Atletas:** finalidade — histórico competitivo completo, base do Sistema de Ranking (Fase 5) e do Livro de Nomes (Projeto 08).
- **Treinadores:** finalidade — reconhecimento técnico formal e vínculo com atletas formados.
- **Boxes:** finalidade — reconhecimento territorial e parceria estrutural (Fase 5).
- **Árbitros:** finalidade — histórico de certificação e atuação técnica (Fase 5/Projeto 09).
- **Voluntários:** finalidade — reconhecimento de trajetória de contribuição operacional (Projeto 07/09).
- **Patrocinadores:** finalidade — histórico de relacionamento comercial e institucional (Projeto 05/06).
- **Imprensa:** finalidade — relacionamento editorial contínuo (Projeto 01/07).
- **Parceiros institucionais:** finalidade — relacionamento de longo prazo com federações, universidades e órgãos públicos (Fase 5).
- **Autoridades:** finalidade — relacionamento institucional formal, geralmente fora do funil comercial padrão.
- **Fornecedores:** finalidade — histórico operacional de prestação de serviço (Projeto 09).

---

## 4. JORNADA DO RELACIONAMENTO

1. **Primeiro contato** — registro mínimo (Projeto 11, Capítulo 4).
2. **Manifestação de interesse** — status atualizado conforme o Sistema de Inteligência Pré-Inscrição.
3. **Pré-inscrição** — dados progressivamente completados (Manual do Formulário de Manifestação de Interesse).
4. **Inscrição** — conversão formal de status, sem reentrada de dado já fornecido.
5. **Competição** — registro de participação e resultado, alimentando diretamente o Sistema de Memória.
6. **Pós-evento** — reconhecimento e contato de continuidade (Projeto 07, Capítulo 2).
7. **Relacionamento contínuo** — presença ativa entre edições (Fase 5).
8. **Retorno na próxima edição** — histórico acumulado reconhecido automaticamente, nunca tratado como novo relacionamento.
9. **Memória histórica** — a trajetória completa da pessoa permanece acessível e preservada permanentemente (Projeto 08).

Cada etapa é uma mudança de status dentro do mesmo registro único de pessoa — nunca a criação de um novo cadastro desconectado do anterior.

---

## 5. ARQUITETURA DOS DADOS

**O que deve existir:** apenas dados com propósito institucional claro, aplicando o mesmo teste de propósito já constitucional desde o Projeto 11, Capítulo 1.

**O que nunca deve existir:** dado sensível sem finalidade declarada; dado duplicado sem necessidade técnica real; qualquer campo mantido apenas "por precaução".

**Dados permanentes:** nome, histórico de participação, trajetória — nunca expiram, formam a espinha dorsal da pessoa no sistema.

**Dados temporários:** informações específicas de um ciclo (ex: necessidade de hospedagem de uma edição específica) — relevantes apenas naquele contexto, mas preservados como registro histórico após o uso, nunca simplesmente descartados.

**Dados históricos:** arquivados de forma permanente, nunca deletados por conveniência operacional, alimentando diretamente o Projeto 08.

**Metadados:** cada dado carrega proveniência, data de coleta e nível de confiabilidade, mesma lógica já formalizada no Projeto 08, Capítulo 11.

**Relacionamentos:** estruturados como grafo (Capítulo 2), nunca como campos isolados sem conexão.

---

## 6. SEGMENTAÇÃO

A segmentação por estado, cidade, box, treinador, categoria, modalidade, experiência, tempo de relacionamento, participações, interesses e perfil competitivo serve, no CRM, a um propósito distinto e complementar ao da comunicação em massa (Projeto 10, Capítulo 10): aqui, a segmentação orienta **relacionamento individualizado** — cada segmento recebe abordagem de contato apropriada à sua trajetória real, nunca tratamento genérico de massa.

---

## 7. HISTÓRICO

Interações, participações, contatos, eventos, premiações, recordes, ações institucionais e comunicações são todos registrados de forma permanente e nunca sobrescritos — qualquer atualização gera novo registro versionado, preservando o histórico completo, mesmo princípio já constitucional desde o Projeto 08, Capítulo 11. O histórico de relacionamento é, ele mesmo, um dos ativos mais valiosos do sistema — perdê-lo equivale a quebrar a promessa central da marca.

---

## 8. INTEGRAÇÃO

O CRM é a fonte primária de dado de pessoa para todos os demais sistemas: alimenta o Sistema Comercial (Projeto 06) com histórico de relacionamento; alimenta o Sistema de Experiência (Projeto 07) com reconhecimento de trajetória; alimenta o Sistema de Memória (Projeto 08) com registro permanente; alimenta o Sistema Operacional (Projeto 09) com dados de credenciamento e dimensionamento; alimenta o Sistema de Lançamento (Projeto 10) e o Sistema de Inteligência Pré-Inscrição (Projeto 11) com histórico de conversão; alimenta o Dashboard Executivo com indicadores de relacionamento (Capítulo 12). Nenhum desses sistemas mantém uma base de pessoa paralela e desconectada do CRM.

---

## 9. GOVERNANÇA DOS DADOS

**Quem cria:** qualquer ponto de contato oficial (formulário, comercial, credenciamento) gera ou atualiza um registro — nunca criação informal fora do sistema.

**Quem altera:** a própria pessoa, via autoatualização (Projeto 11, Capítulo 5), ou a equipe responsável pela área correspondente (Capítulo 3).

**Quem consulta:** conforme níveis de acesso por perfil (Capítulo 13).

**Quem aprova mudança estrutural:** qualquer alteração de arquitetura de dados (Capítulo 5) exige aprovação da Governança de Marca.

**Quem exporta:** função restrita e sempre registrada.

**Quem exclui:** ninguém isoladamente — exclusão de dado pessoal segue processo formal (Capítulo 11), enquanto exclusão de registro histórico de participação segue as regras de excepcionalidade já definidas no Projeto 08, Capítulo 13.

**Versionamento e auditorias:** mesma lógica formal já padronizada desde o Projeto 04.

---

## 10. QUALIDADE DA BASE

Medida por: **duplicidade** (cruzamento automático, mesmo protocolo do Projeto 11, Capítulo 5, incluindo tratamento de casos inconclusivos) · **completude** (proporção de campos relevantes preenchidos) · **atualização** (tempo desde a última confirmação de dado) · **consistência** (mesma pessoa representada de forma única em todo o sistema) · **confiabilidade** (proporção de dado validado versus não validado) · **obsolescência** (dado que não é mais operacionalmente relevante, mas que permanece preservado como histórico — nunca deletado apenas por estar desatualizado, apenas despriorizado do uso ativo).

---

## 11. LGPD

**Consentimento:** granular e específico por finalidade, mesmo padrão já constitucional desde o Manual do Formulário de Manifestação de Interesse.

**Finalidade:** declarada no momento da coleta original, preservada como metadado permanente do próprio dado.

**Retenção:** dados de contato e relacionamento seguem prazo definido e revisável; dados de resultado esportivo oficial (informação pública de competição) seguem o regime de preservação permanente do Sistema de Memória (Capítulo 16 trata a tensão entre os dois regimes).

**Anonimização:** aplicada a relatórios agregados e análises, nunca ao registro histórico nominal central do Livro de Nomes, que é, por definição e por consentimento original informado, público e nominal.

**Exclusão e direito ao esquecimento:** aplicável integralmente a dados de contato, comerciais e de relacionamento ativo — tratado com a mesma seriedade já definida no Projeto 10, Capítulo 16, e no Projeto 11, Capítulo 13.

**Direitos do titular:** acesso, correção, portabilidade e exclusão de dado pessoal de contato, sempre disponíveis e de fácil exercício.

**Compartilhamento:** nunca fora do escopo declarado, exceto consentimento específico e separado por finalidade.

**Auditorias:** periódicas, com foco especial na coerência entre este capítulo e o Capítulo 16 (Casos Especiais), onde a tensão entre exclusão de dado pessoal e preservação de patrimônio histórico é mais sensível.

---

## 12. INDICADORES

- **Crescimento da comunidade:** volume total de pessoas relacionadas ao ecossistema ao longo do tempo — decisão associada: estratégia de expansão (Fase 5).
- **Retenção:** proporção de pessoas que mantêm relacionamento ativo entre edições — decisão: prioridade de investimento em experiência (Projeto 07).
- **Recorrência:** frequência de retorno de atletas, treinadores e voluntários — decisão: calibração de reconhecimento de trajetória.
- **Atualização cadastral:** proporção de perfis com dado recente e confiável — decisão: priorização de campanhas de atualização de dado.
- **Participação por edição:** volume ativo por ciclo — decisão: dimensionamento operacional (Projeto 09).
- **Relacionamento por perfil:** volume ativo por tipo de perfil (Capítulo 3) — decisão: alocação de recursos de relacionamento por área.
- **Qualidade da base:** conforme Capítulo 10 — decisão: priorização de manutenção técnica.
- **Engajamento:** interação real registrada ao longo do relacionamento — decisão: calibração de comunicação individualizada (Capítulo 6).

---

## 13. SEGURANÇA

**Perfis de acesso:** definidos por função institucional (Capítulo 3 e estrutura organizacional da Fase 6), nunca acesso irrestrito universal.

**Permissões:** visualizar, editar e exportar são níveis distintos, mesma lógica já aplicada no Dashboard Executivo.

**Registro de alterações:** log formal de toda mudança relevante em qualquer registro de pessoa.

**Backup:** redundância geográfica e tecnológica, mesmo princípio já constitucional desde o Projeto 08, Capítulo 12.

**Continuidade:** o sistema nunca depende de uma única pessoa ou de um único fornecedor tecnológico, mesmo princípio de continuidade institucional já aplicado em todos os sistemas anteriores.

**Proteção da informação:** medidas técnicas de segurança proporcionais à sensibilidade do dado armazenado.

---

## 14. ROADMAP DE EVOLUÇÃO

**Como o CRM deve evoluir:** por incorporação de novos módulos sempre testados pelo mesmo princípio de propósito real (Capítulo 5), nunca por tendência de mercado não avaliada.

**Como incorporar novos módulos:** com aprovação da Governança de Marca para qualquer mudança estrutural (Capítulo 9).

**Como manter compatibilidade histórica:** nenhuma evolução técnica pode resultar em perda de dado histórico já acumulado — migração de plataforma nunca é motivo para descarte de registro.

**Como preservar a memória institucional:** o CRM e o Sistema de Memória (Projeto 08) crescem sempre juntos — nenhuma decisão de evolução do CRM pode enfraquecer a completude do patrimônio histórico.

---

## 15. ROADMAP DE IMPLEMENTAÇÃO

**Etapas:** (1) mapeamento formal das entidades reais (Capítulo 2) antes de qualquer escolha técnica; (2) definição de estrutura de campos conforme a Arquitetura dos Dados (Capítulo 5); (3) planejamento de integração com os sistemas já constitucionais (Capítulo 8); (4) migração de qualquer dado legado já existente, com preservação obrigatória de histórico; (5) testes com grupo reduzido antes de expansão total; (6) implantação plena, seguindo a Governança (Capítulo 9).

**Dependências:** o CRM depende do Sistema de Memória e do Sistema de Inteligência Pré-Inscrição estarem minimamente definidos (já estão, por esta própria Constituição) — a implementação técnica não precisa esperar novos princípios, apenas aplicar os já existentes.

**Critérios de implantação:** validação com um perfil de usuário real antes de expansão total (mesmo critério já usado no Dashboard Executivo).

**Boas práticas:** nenhuma tecnologia específica é exigida — qualquer plataforma que suporte os princípios de arquitetura de dados (Capítulo 5), histórico permanente (Capítulo 7) e segurança (Capítulo 13) é compatível, mesmo princípio de não-dependência de fornecedor único já usado nos Projetos 08 e 09.

---

## 16. CASOS ESPECIAIS

- **Atletas internacionais:** seguem as mesmas regras de qualquer atleta, com campos adaptados de documentação (mesmo princípio do Projeto 05, Capítulo 15).
- **Menores de idade:** consentimento parental explícito e coleta mínima reforçada (Projeto 08, Capítulo 16; Projeto 10, Capítulo 16).
- **Boxes encerrados:** o registro histórico do box e de sua relação com atletas é preservado permanentemente, mesmo que o box não exista mais operacionalmente — a história não se apaga porque a organização que a viveu deixou de existir.
- **Mudança de treinador:** o vínculo histórico com o treinador anterior é preservado, não substituído — a trajetória do atleta é documentada de forma cumulativa, nunca reescrita.
- **Mudança de estado/cidade:** o dado atual é atualizado; o histórico de localização anterior é preservado como parte da trajetória, não apagado.
- **Falecimento:** o perfil nunca é simplesmente "excluído" ou tratado como encerramento comum de relacionamento — torna-se um registro permanente de reconhecimento e memória, tratado com o mesmo cuidado e dignidade do Sistema de Memória (Projeto 08), incluindo possível reconhecimento formal no Livro de Nomes ou Hall da Fama quando aplicável.
- **Desligamento institucional (dirigentes/staff):** o registro de contribuição é preservado como parte da história organizacional, independentemente do motivo do desligamento.
- **Patrocinadores históricos:** os "guardiões fundadores" (Projeto 05, Capítulo 11) permanecem no CRM como parte permanente do patrimônio institucional, mesmo após o encerramento do contrato comercial ativo.
- **Registros permanentes vs. direito ao esquecimento:** o presente manual reconhece explicitamente a tensão entre o direito de exclusão de dado pessoal (Capítulo 11) e a preservação de registro histórico de participação esportiva pública (Projeto 08). A resolução formal é: **dados de contato, comerciais e de relacionamento privado** podem ser excluídos mediante solicitação; **o registro nominal de participação esportiva pública** (nome, resultado, edição) é tratado como informação de competição pública, preservada permanentemente no Sistema de Memória, com essa distinção comunicada de forma clara e transparente no momento do consentimento original — nunca como surpresa posterior.

---

## 17. SISTEMA DE AUDITORIA

**Como auditar o CRM:** revisão periódica formal da aderência aos princípios deste manual, especialmente Capítulos 5, 10 e 11.

**Como validar informações:** reconferência de amostras contra fonte primária, mesmo princípio já aplicado no Dashboard Executivo.

**Como detectar inconsistências:** cruzamento sistemático entre registros relacionados (ex: um mesmo atleta aparecendo com dados divergentes em contextos diferentes).

**Como revisar registros:** processo formal e documentado, nunca alteração silenciosa de dado histórico relevante.

**Como manter qualidade ao longo dos anos:** auditoria periódica obrigatória, com resultado formalmente reportado à Governança de Marca.

---

## 18. ROADMAP DE DOCUMENTOS DERIVADOS

1. **Manual de Segmentação** — aprofundamento técnico do Capítulo 6.
2. **Manual de Automações** — regras técnicas de automação de relacionamento, sempre respeitando os limites éticos já constitucionais (Projeto 10, Capítulo 16).
3. **Manual de Relacionamento** — protocolo prático de contato por perfil (Capítulo 3).
4. **Manual de Qualidade dos Dados** — aprofundamento técnico do Capítulo 10.
5. **Manual de LGPD** — aprofundamento jurídico-operacional do Capítulo 11.
6. **Manual de Integrações** — especificação técnica do Capítulo 8.
7. **Manual de Migração** — protocolo técnico de migração de plataforma preservando histórico (Capítulo 14).
8. **Manual de Atendimento** — protocolo de suporte direto a qualquer perfil cadastrado.

**Prioridade de desenvolvimento:** **prioridade 1** — Manual de LGPD e Manual de Qualidade dos Dados, pré-requisitos de conformidade e confiabilidade antes de qualquer operação em escala; **prioridade 2** — Manual de Integrações e Manual de Segmentação, necessários para conectar o CRM aos demais sistemas constitucionais; **prioridade 3** — Manual de Relacionamento e Manual de Atendimento, que operacionalizam o uso cotidiano; **prioridade 4** — Manual de Automações e Manual de Migração, que amadurecem a partir do uso já consolidado do sistema.

---

## AUDITORIA FINAL — CONSELHO DE ONZE ESPECIALISTAS (CICLO ITERATIVO)

### Rodada 1 — críticas técnicas

**CRM:** "A decisão de tratar Pessoa como entidade central acima de qualquer perfil funcional (Capítulo 2) é tecnicamente correta e evita o erro mais comum de sistemas de relacionamento esportivo — múltiplos cadastros fragmentados da mesma pessoa em papéis diferentes. Nenhuma inconsistência estrutural."

**Customer Success:** "A Jornada do Relacionamento (Capítulo 4), tratando cada etapa como mudança de status de um único registro, é coerente com boas práticas reais de gestão de relacionamento de longo prazo. Nenhuma inconsistência."

**Growth Marketing:** "A Segmentação (Capítulo 6) corretamente distingue uso para relacionamento individualizado de uso para comunicação em massa (Projeto 10). Nenhuma inconsistência."

**Ciência de Dados:** "A Arquitetura dos Dados (Capítulo 5), com distinção clara entre dados permanentes, temporários e históricos, está bem estruturada. Nenhuma inconsistência nova."

**Governança de Dados:** "O Capítulo 9 está bem alinhado à governança já constitucional. Recomendo apenas que o processo de 'quem exclui' explicite que, mesmo dentro da equipe autorizada, exclusão de dado sensível deve exigir dupla aprovação (não uma única pessoa), dado o risco irreversível dessa ação."

**LGPD:** "O Capítulo 16, ao enfrentar diretamente a tensão entre direito ao esquecimento e preservação de registro histórico esportivo público, é o ponto mais importante e mais bem resolvido de todo o documento — a maioria dos sistemas evita essa discussão explícita. A resolução proposta (distinção entre dado de contato/comercial excluível e registro público de competição preservado) está juridicamente defensável, desde que a transparência no consentimento original (já exigida) seja de fato cumprida na prática. Nenhuma inconsistência estrutural."

**Marketing Esportivo:** "O tratamento de patrocinadores históricos como parte permanente do patrimônio (Capítulo 16) reforça corretamente a lógica de 'guardiões fundadores' já estabelecida no Projeto 05. Nenhuma inconsistência."

**Comunidades:** "O tratamento de boxes encerrados e do caso de falecimento (Capítulo 16) demonstra um cuidado humano raro em manuais técnicos de CRM — a maioria trataria esses casos apenas como 'churn' ou 'registro inativo'. Nenhuma inconsistência, e reforço que este é um diferencial real de identidade."

**Business Intelligence:** "Os indicadores (Capítulo 12) estão bem vinculados a decisões reais, seguindo a mesma disciplina já aplicada no Dashboard Executivo. Nenhuma inconsistência."

**Arquitetura da Informação:** "A estrutura de entidades e relacionamentos (Capítulo 2) é sólida e replicável em qualquer tecnologia. Nenhuma inconsistência estrutural."

**Gestão de Relacionamento:** "O documento trata relacionamento como patrimônio de longo prazo de forma consistente do início ao fim. Recomendo apenas que o Capítulo 4 explicite o que acontece quando uma pessoa interrompe o relacionamento por múltiplos ciclos e depois retorna — hoje o fluxo assume continuidade linear, sem tratar explicitamente hiato prolongado."

### Ajustes incorporados após a Rodada 1

- **Capítulo 9** passa a exigir dupla aprovação formal para qualquer exclusão de dado pessoal sensível, mesmo dentro da equipe já autorizada — nenhuma exclusão irreversível depende de decisão de uma única pessoa.
- **Capítulo 4** passa a prever explicitamente o cenário de retorno após hiato prolongado: o histórico permanece intacto e é reconhecido normalmente, sem qualquer penalização ou "reinício" do relacionamento — a pessoa retoma exatamente de onde sua trajetória documentada parou, por mais longo que tenha sido o intervalo.

### Rodada 2 — segunda leitura crítica após ajustes

**Governança de Dados:** "A exigência de dupla aprovação para exclusão sensível resolve exatamente o risco que apontei — reduz a chance de erro irreversível por decisão isolada."

**Gestão de Relacionamento:** "O tratamento explícito do retorno após hiato prolongado, sem penalização, resolve minha observação e reforça a coerência com o valor de 'trajetória contínua' já constitucional."

**LGPD:** "Mantenho minha avaliação da Rodada 1 — nenhum ajuste adicional necessário no Capítulo 16, que já estava tecnicamente bem resolvido."

**Consolidação final:** a segunda rodada não identificou nenhuma inconsistência estrutural relevante remanescente. Os dois ajustes da primeira rodada foram incorporados como princípios formais, e a resolução da tensão entre LGPD e preservação histórica (Capítulo 16) permanece como um dos pontos mais tecnicamente sólidos de todo o documento. O ciclo iterativo é encerrado nesta rodada.

---

*Fim do Manual do CRM. Documento oficial, fundamentado em toda a Constituição do projeto (Fases 1-6, Projetos 01-11), servindo como padrão permanente para qualquer CRM utilizado pelo Campeonato Brasileiro de Kettlebell Sport.*
