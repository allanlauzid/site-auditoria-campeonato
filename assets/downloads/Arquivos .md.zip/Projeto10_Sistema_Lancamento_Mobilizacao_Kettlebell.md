# PROJETO 10 — SISTEMA DE LANÇAMENTO E MOBILIZAÇÃO DO CAMPEONATO
### Campeonato Brasileiro de Kettlebell Sport
### Constituição Permanente do Lançamento das Inscrições

*Fases 1-6 e Projetos 01-09 são Constituição definitiva e têm prioridade absoluta. Este documento não cria posts, copies, anúncios ou cronograma anual — cria o sistema permanente que transforma cada abertura de inscrições em movimento nacional, nunca em campanha de vendas.*

---

## 1. FILOSOFIA DO LANÇAMENTO

**Por que existe:** porque a abertura de inscrições é o momento em que a comunidade se torna visível a si mesma — não apenas uma transação, mas a prova pública de que o Kettlebell Sport brasileiro está crescendo, ano após ano.

**Qual sua função:** transformar expectativa dispersa (pessoas que gostariam de competir, mas ainda não sabem quando) em mobilização coletiva coordenada, sem jamais recorrer a mecanismos que contradigam os valores já definidos desde a Fase 3.

**O que nunca deve acontecer:** urgência fabricada, escassez artificial, contadores regressivos sem lastro real, uso de dados de interesse para pressionar psicologicamente em vez de informar genuinamente, ou qualquer mecanismo de gatilho que a Fase 3 já identificou como incompatível com a marca.

**Como proteger a identidade da marca:** toda ação de mobilização passa pelo mesmo filtro já usado em toda a Constituição — se o mecanismo depende de manipulação ou pressão artificial para funcionar, ele não pertence a este sistema, independente de quão eficaz pareça no curto prazo.

---

## 2. ARQUITETURA DO LANÇAMENTO

**Macrofases permanentes:**

1. **Escuta** — antes de qualquer comunicação de mobilização, o sistema mede interesse real (Capítulo 8), sem ainda pedir nada em troca além de intenção declarada.
2. **Aquecimento e Mobilização** — storytelling em camadas (Capítulo 4) ativa comunidade, boxes, treinadores e imprensa, ainda antes da abertura oficial.
3. **Anúncio da Abertura** — transição transparente e comunicada com antecedência real, nunca surpresa artificial.
4. **Confirmação** — o processo de inscrição em si, operacionalizado pelos sistemas já definidos (Projeto 01, Fase 4).
5. **Consolidação Pós-Abertura** — sustentação do movimento e transição para a fase de Preparação (Fase 4, Capítulo 6), mantendo comunidade mobilizada até o evento.

**Objetivos por macrofase:** Escuta (dados confiáveis de previsão) · Aquecimento (pertencimento antecipado) · Anúncio (clareza e transparência) · Confirmação (conversão honesta) · Consolidação (retenção de energia coletiva).

**Transições e critérios para avançar:** cada macrofase avança para a seguinte apenas quando cumpre um critério mínimo de maturidade (ex: Escuta só avança para Aquecimento quando há volume mínimo de dados confiáveis para orientar a comunicação; Aquecimento só avança para Anúncio quando a comunidade já demonstra engajamento genuíno mensurável) — nunca apenas por data no calendário.

---

## 3. JORNADA DO ATLETA (DESCOBERTA → CONFIRMAÇÃO)

1. **Descoberta da próxima edição:** expectativa contida, curiosidade — reforçada por conteúdo histórico e institucional (Capítulo 4).
2. **Interesse declarado:** o atleta se cadastra em lista de interesse (Capítulo 7), sem compromisso, mas com sinalização real.
3. **Engajamento comunitário:** interação com conteúdo e comunidade (Capítulo 12), aprofundando pertencimento antes mesmo da inscrição existir formalmente.
4. **Anúncio oficial:** clareza total sobre datas, processo e expectativas.
5. **Decisão:** o atleta decide se inscrever com informação completa, nunca sob pressão de tempo artificial.
6. **Confirmação:** conclusão do processo de inscrição, com reconhecimento imediato (mesmo princípio de acolhimento já definido no Projeto 07).

**Emoções:** curiosidade → pertencimento antecipado → clareza → confiança → orgulho de decisão.
**Necessidades:** informação clara, sensação de que sua intenção já importa antes mesmo de pagar qualquer valor, reconhecimento de continuidade se já for atleta recorrente.
**Momentos críticos:** o instante do anúncio oficial — se a transição da Escuta/Aquecimento para o Anúncio for abrupta ou pouco clara, quebra a confiança construída nas fases anteriores.
**Momentos memoráveis:** o momento em que o atleta percebe que seu interesse declarado antecipadamente já foi, de alguma forma, reconhecido pela organização (Capítulo 11).

---

## 4. SISTEMA DE STORYTELLING

- **Narrativa institucional:** o campeonato como instituição permanente (Fase 3), não apenas evento anual.
- **Narrativa emocional:** o território do "Duelo Testemunhado" (Fase 2/Projeto 02), usado para reacender desejo antes da abertura.
- **Narrativa esportiva:** conteúdo técnico traduzido (território "Bastidor Técnico", Projeto 02), reduzindo barreira para novos públicos.
- **Narrativa histórica:** ancorada no Sistema de Memória (Projeto 08) — Livro de Nomes, Hall da Fama, recordes — provando que há continuidade real por trás do próximo capítulo.
- **Narrativa da cidade-sede:** quando aplicável, conexão genuína com a identidade cultural local da cidade que sedia a edição, sem nunca sobrepor-se à identidade central da marca.
- **Narrativa da comunidade:** histórias reais de boxes, treinadores e atletas, coerente com a camada de pertencimento definida desde a Fase 2.

**Como se integram:** cada narrativa é ativada com ênfase diferente conforme a macrofase (Capítulo 2) — a narrativa histórica e institucional dominam a Escuta e o Aquecimento; a narrativa esportiva e técnica ganha peso perto do Anúncio; a narrativa da comunidade permanece ativa do início ao fim, como fio condutor.

---

## 5. SISTEMA DE MOBILIZAÇÃO

Cada público é mobilizado por meio de valor genuíno e informação real, nunca manipulação:

- **Atletas:** mobilizados por reconhecimento antecipado e clareza de processo (Capítulos 3 e 11).
- **Boxes:** mobilizados como parceiros territoriais (Fase 5), recebendo material e reconhecimento próprio, não apenas repassando comunicação de terceiros.
- **Treinadores:** mobilizados por crédito técnico público (Projeto 01, Capítulo 2).
- **Árbitros:** mobilizados por reconhecimento formal de seu papel na integridade da competição (Fase 5/Projeto 07).
- **Federações:** mobilizadas via relacionamento institucional contínuo (Fase 5), não apenas convite pontual.
- **Voluntários:** mobilizados por pertencimento genuíno (Projeto 07, Capítulo 8), nunca apenas recrutamento operacional.
- **Patrocinadores:** mobilizados com dados reais de previsão (Capítulo 8), permitindo decisão comercial informada, coerente com o Sistema Comercial (Projeto 06).
- **Imprensa:** mobilizada com acesso privilegiado a conteúdo documental real (Projeto 01, Capítulo 10), nunca apenas releases genéricos.

---

## 6. SISTEMA DE CONTEÚDO

| Tipo | Função | Macrofase dominante |
|---|---|---|
| Educativo | Reduzir barreira técnica, traduzir o esporte | Escuta/Aquecimento |
| Emocional | Reacender desejo através do território "Duelo Testemunhado" | Aquecimento |
| Técnico | Informar regras, formato, critérios | Anúncio/Confirmação |
| Institucional | Reforçar permanência e propósito (Fase 3) | Todas, com menor intensidade |
| Histórico | Ativar Sistema de Memória como prova social legítima | Aquecimento/Anúncio |
| Social | Amplificar vozes reais da comunidade | Todas |
| Bastidores | Humanizar preparação e operação (Projeto 09) | Aquecimento/Consolidação |

---

## 7. SISTEMA DE INTERAÇÃO

- **Listas de interesse:** usadas desde a macrofase de Escuta — mecanismo central de captação de dados reais (Capítulo 8).
- **Enquetes e quizzes:** usados no Aquecimento, com função educativa (ex: "você conhece as regras do kettlebell sport?"), nunca apenas entretenimento vazio.
- **Caixas de perguntas:** usadas para captar dúvidas reais e alimentar conteúdo educativo subsequente.
- **Formulários:** usados para captação estruturada de dados de previsão (Capítulo 8), sempre com propósito declarado.
- **Contadores:** usados exclusivamente para marcos reais e já anunciados (ex: contagem para uma data de abertura já confirmada publicamente) — nunca para criar senso de escassez fabricada.
- **Desafios e votações:** usados no Sistema de Comunidade (Capítulo 12) para gerar interação genuína entre participantes.
- **Confirmações de presença:** usadas quando aplicável a eventos de mobilização prévios (ex: transmissão de anúncio), sempre voluntárias.
- **Pesquisas rápidas:** usadas para captar percepção qualitativa complementar aos dados estruturados do Capítulo 8.

---

## 8. SISTEMA DE INTELIGÊNCIA PRÉVIA

**Objetivo:** medir interesse real antes da abertura de inscrições, permitindo prever o tamanho e o perfil do campeonato com antecedência suficiente para orientar toda a operação (Projeto 09), o comercial (Projeto 06) e a comunicação (Projeto 01).

**Dados coletados (sempre com consentimento e propósito declarado, Capítulo 16):** interesse geral · intenção declarada de inscrição · estado e cidade · box de origem · categoria pretendida · idade · sexo · modalidade/prova pretendida · dias de competição desejados · necessidade de hospedagem · necessidade de transporte · tempo estimado de viagem · participação em grupo (mesmo box/cidade) · se é primeira participação ou atleta recorrente.

**Como utilizar:** os dados são consolidados em um panorama de previsão que orienta decisões concretas — dimensionamento de arena e logística (Projeto 09), argumentos comerciais baseados em projeção real, não estimativa vaga (Projeto 06), e priorização de comunicação regional (Capítulo 10).

**Princípio de precisão:** a precisão da previsão (diferença entre o projetado e o realizado) é, ela mesma, um indicador formal de qualidade do sistema (Capítulo 13), tratado com a mesma seriedade de qualquer outro KPI institucional.

---

## 9. SISTEMA DE INTELIGÊNCIA DE MERCADO

Diferente do Capítulo 8 (previsão de uma edição específica), este sistema analisa tendências de médio e longo prazo: crescimento da modalidade no Brasil como um todo, distribuição regional ao longo de múltiplas edições, engajamento e retenção agregados (conectando-se diretamente aos KPIs já definidos na Fase 6), proporção de atletas novos versus recorrentes, e ritmo real de expansão do campeonato comparado ao planejamento da Fase 6.

Esta inteligência de mercado é insumo direto para decisões estratégicas de expansão geográfica (Fase 5) e para calibração dos cenários orçamentários (Fase 6, Capítulo 8) com dados reais acumulados, em vez de apenas projeções proporcionais iniciais.

---

## 10. SISTEMA DE SEGMENTAÇÃO

A comunicação é segmentada por estado, cidade, box, categoria, nível de experiência, faixa etária, objetivo declarado e perfil competitivo — sempre com o propósito de tornar a comunicação mais relevante e útil para quem a recebe, nunca para explorar vulnerabilidade específica de um segmento. Um atleta estreante recebe ênfase educativa (Capítulo 6); um atleta recorrente recebe ênfase de continuidade e reconhecimento histórico (Projeto 08) — a segmentação nunca varia o grau de honestidade ou transparência, apenas a ênfase de conteúdo.

---

## 11. SISTEMA DE SOCIAL PROOF

**Princípio central:** prova social é sempre real, nunca fabricada — nenhum número de interesse, participação ou engajamento é inflado ou apresentado fora de contexto.

**Fontes legítimas de prova social:**
- Interesse genuinamente demonstrado (Capítulo 8), comunicado com transparência sobre o que representa.
- Histórias reais de atletas e participações anteriores.
- Recordes oficiais (Fase 5/Projeto 08).
- Depoimentos autênticos, sempre com consentimento explícito.
- O próprio Livro de Nomes e o Hall da Fama (Projeto 08), como prova social institucional de longo prazo — talvez o ativo de prova social mais forte e mais difícil de copiar que o campeonato possui.

**O que nunca é feito:** exibir contadores fabricados, extrapolar dados parciais como se fossem definitivos, ou insinuar demanda maior do que a real para pressionar decisão.

---

## 12. SISTEMA DE COMUNIDADE

**Como fortalecer relações entre atletas:** criando espaços de conversa genuína (não apenas broadcast institucional) entre pessoas que já demonstraram interesse (Capítulo 8), permitindo que a comunidade se reconheça mutuamente antes mesmo do evento acontecer.

**Como estimular conversas:** por meio de conteúdo que convida participação real (desafios, votações, Capítulo 7), nunca apenas conteúdo de consumo passivo.

**Como aumentar pertencimento:** reforçando reconhecimento nominal mesmo nesta fase pré-competitiva — quem demonstra interesse já começa a ser tratado como parte da comunidade, não apenas como lead comercial.

**Como integrar novos atletas:** por meio da narrativa educativa (Capítulo 4/6), reduzindo a sensação de que é preciso já ser experiente para pertencer.

**Como integrar atletas experientes:** por meio de reconhecimento de trajetória (Projeto 08), convidando-os a atuar como referência e ponte para novos atletas dentro da própria comunidade.

---

## 13. SISTEMA DE INDICADORES

- **Engajamento:** interação real com conteúdo de mobilização (Capítulo 6), por macrofase.
- **Conversão:** proporção de interesse declarado (Capítulo 8) que se converte em inscrição confirmada.
- **Interesse e intenção:** volume absoluto e qualificado de interesse captado antes da abertura.
- **Participação:** volume final de inscrições, sempre lido em conjunto com os dados de previsão.
- **Distribuição regional:** aderência real à distribuição prevista (Capítulo 8), informando logística futura.
- **Crescimento:** variação de interesse e inscrição edição a edição.
- **Retenção:** proporção de atletas recorrentes dentro do volume total, conforme já definido na Fase 6.
- **Precisão das previsões:** diferença entre o projetado (Capítulo 8) e o realizado — indicador de maturidade do próprio sistema de inteligência.

---

## 14. SISTEMA DE DASHBOARDS

- **Dashboard de Interesse (tempo real):** consolida os dados do Capítulo 8, usado pela Direção Geral (Projeto 09) e pelo Comercial (Projeto 06) para decisões de dimensionamento e negociação.
- **Dashboard de Comunidade:** mede engajamento e interação (Capítulo 12), usado pela equipe de Comunicação (Projeto 01).
- **Dashboard Comercial:** traduz interesse e previsão em argumento de valor para patrocinadores (Projeto 05/06).
- **Dashboard Operacional:** alimenta diretamente o planejamento logístico (Projeto 09) com dados reais de volume e distribuição esperados.
- **Dashboard de Mercado:** consolida tendências de médio/longo prazo (Capítulo 9), usado pela Governança de Marca e liderança executiva (Fase 6) para decisões estratégicas.

**Como apoiam decisões:** nenhum dashboard existe apenas para visualização — cada um está formalmente vinculado a uma decisão real de outro sistema já constitucional (operação, comercial, comunicação, estratégia).

---

## 15. SISTEMA DE INTEGRAÇÃO

- **Projeto 01 (Comunicação):** todo conteúdo de mobilização segue o tom, vocabulário e territórios já definidos.
- **Projeto 02 (Criativo):** a narrativa emocional (Capítulo 4) usa exclusivamente os territórios criativos já constitucionais.
- **Projeto 05/06 (Patrocínio/Comercial):** os dados de previsão (Capítulo 8) alimentam diretamente propostas e negociações reais, nunca estimativas genéricas.
- **Projeto 07 (Experiência):** a mobilização nunca promete uma experiência diferente da que o Sistema de Experiência efetivamente entrega — nenhuma expectativa é criada além do que é constitucionalmente garantido.
- **Projeto 08 (Memória):** fonte central de prova social legítima (Capítulo 11) e de narrativa histórica (Capítulo 4).
- **Projeto 09 (Operação):** os dados de previsão (Capítulo 8) são insumo formal e obrigatório do planejamento operacional, antes de qualquer decisão de dimensionamento física.

**Princípio geral:** nenhuma ação deste sistema é aprovada isoladamente — toda mobilização é verificada contra a Constituição completa antes de ser executada.

---

## 16. SISTEMA ÉTICO

**Limites:** este sistema nunca utiliza gatilhos psicológicos de pressão, urgência artificial ou manipulação de percepção — mesmo quando tecnicamente eficazes, são incompatíveis com os valores definidos desde a Fase 3.

**Transparência:** todo dado coletado (Capítulo 8) tem propósito declarado de forma clara ao atleta no momento da coleta.

**Uso de dados:** exclusivamente para os fins descritos neste documento — nunca vendido, compartilhado ou usado para finalidade não comunicada.

**Privacidade e consentimento:** coleta sempre opcional e consentida, com possibilidade de revisão ou remoção pelo próprio titular do dado, alinhada aos mesmos princípios éticos já estabelecidos no Projeto 08, Capítulo 16.

**Comunicação responsável:** nenhuma comunicação de mobilização insinua obrigação, exclusão social ou medo de "ficar de fora" como gatilho central — o convite é sempre baseado em desejo genuíno, nunca em ansiedade induzida.

**Uso correto de estatísticas:** dados parciais nunca são apresentados como conclusivos; projeções são sempre comunicadas como projeções, nunca como certeza.

---

## 17. SISTEMA DE APRENDIZADO

**Como registrar resultados:** todo ciclo de lançamento gera registro formal comparando previsão (Capítulo 8) e resultado real, avaliação de engajamento por tipo de conteúdo (Capítulo 6) e por canal (Capítulo 15).

**Como aprender com cada edição:** revisão formal obrigatória antes do planejamento do próximo ciclo de lançamento, seguindo a mesma lógica de debriefing já estabelecida no Projeto 09.

**Como melhorar continuamente:** ajustes de sistema (não de princípio) são incorporados a partir de evidência real acumulada, nunca por intuição isolada ou tendência de mercado não verificada.

**Como preservar conhecimento:** documentação formal de processo, alimentando o Sistema de Memória institucional (Projeto 08) como parte da própria história organizacional do campeonato.

---

## 18. SISTEMA DE ESCALABILIDADE

O sistema de lançamento é desenhado para funcionar de forma proporcional em eventos pequenos, médios, grandes ou eventualmente internacionais — os princípios éticos (Capítulo 16), a arquitetura de macrofases (Capítulo 2) e a lógica de inteligência prévia (Capítulo 8) permanecem idênticos em qualquer escala; o que muda é apenas a complexidade dos dashboards (Capítulo 14) e o volume de segmentação (Capítulo 10) necessários para processar os dados coletados.

---

## 19. GOVERNANÇA

**Quem protege o sistema:** a Governança de Marca, com apoio técnico do Diretor Comercial e do Diretor de Comunicação (Fase 6) na aplicação prática cotidiana.

**Quem pode alterar:** apenas a Governança de Marca altera os princípios permanentes deste documento; ajustes operacionais de ferramentas e canais são de responsabilidade das áreas técnicas correspondentes.

**Quem aprova mudanças:** qualquer alteração de princípio segue o mesmo fluxo constitucional já utilizado em todos os documentos anteriores.

**Como documentar alterações:** changelog formal e versionado.

**Versionamento:** este documento nunca é sobrescrito — cada revisão preserva histórico completo.

**Auditorias:** revisão periódica, com atenção especial ao Sistema Ético (Capítulo 16), garantindo que nenhuma prática de mobilização tenha, ao longo do tempo, se aproximado de mecanismos de manipulação por pressão de resultado de curto prazo.

---

## 20. ROADMAP DE DESDOBRAMENTO — DOCUMENTOS FUTUROS

1. **Manual do Lançamento** — consolidador prático de todos os demais, aplicado a um ciclo específico.
2. **Manual de Pesquisa com Atletas** — protocolo detalhado de coleta de dados do Capítulo 8.
3. **Manual de CRM** — operacionalização técnica da base de interesse e relacionamento.
4. **Manual Editorial** — linha editorial detalhada de conteúdo por macrofase (Capítulo 6).
5. **Manual de Conteúdo** — biblioteca de formatos e diretrizes práticas de produção.
6. **Manual de Instagram / Manual de Stories** — aplicação prática por canal (Projeto 04, Capítulo 11).
7. **Manual de WhatsApp** — protocolo de proximidade e comunidade (Capítulo 12).
8. **Manual de E-mail** — protocolo de nutrição e memória formal (Projeto 01, Capítulo 10).
9. **Manual de Landing Pages** — especificação de conversão transparente (Capítulo 7).
10. **Manual de Dashboards** — especificação técnica dos painéis do Capítulo 14.
11. **Manual de Inteligência de Mercado** — aprofundamento técnico do Capítulo 9.
12. **Manual de Automações** — regras técnicas de automação de comunicação, sempre respeitando o Sistema Ético (Capítulo 16).
13. **Manual de Relatórios** — formato padrão de entrega de resultados a patrocinadores e diretoria.
14. **Manual de Comunidade** — aprofundamento prático do Capítulo 12.
15. **Manual de Métricas** — especificação técnica completa dos indicadores do Capítulo 13.

**Ordem ideal de desenvolvimento:** **prioridade 1** — Manual de Pesquisa com Atletas e Manual de CRM, pré-requisitos técnicos de todo o Sistema de Inteligência Prévia (Capítulo 8); **prioridade 2** — Manual Editorial e Manual de Conteúdo, necessários para qualquer mobilização real começar; **prioridade 3** — manuais específicos de canal (Instagram, Stories, WhatsApp, E-mail, Landing Pages); **prioridade 4** — Manual de Dashboards, Métricas, Relatórios e Inteligência de Mercado, que consolidam e analisam os dados gerados pelas camadas anteriores; **prioridade 5** — Manual de Automações e Manual de Comunidade, que amadurecem a partir da prática acumulada das fases anteriores.

---

## AUDITORIA FINAL — CONSELHO DE ONZE ESPECIALISTAS (CICLO ITERATIVO)

### Rodada 1 — críticas técnicas

**Marketing Esportivo:** "A Arquitetura do Lançamento (Capítulo 2), com a macrofase de Escuta antecedendo qualquer mobilização ativa, é uma inversão inteligente da lógica tradicional de lançamento — a maioria dos eventos começa comunicando, não medindo. Nenhuma inconsistência estrutural."

**Branding:** "A integração explícita com todos os projetos anteriores (Capítulo 15) mantém a coerência total da Constituição. O Sistema de Storytelling (Capítulo 4) usa corretamente os territórios já validados, sem criar narrativa nova não autorizada."

**Storytelling:** "A narrativa da cidade-sede (Capítulo 4) é uma adição bem-vinda que nenhum documento anterior havia explorado — mas fica pouco desenvolvida aqui. Recomendo reforçar como ela nunca deve competir com a identidade central, já que cidades-sede podem variar a cada edição."

**Economia Comportamental:** "A proibição explícita de contadores fabricados e urgência artificial (Capítulos 1, 7, 11 e 16) é rara e corajosa para um sistema de lançamento — a maioria dos frameworks de growth recomenda exatamente o oposto. Isso é coerente com toda a Constituição já construída."

**Psicologia do Consumidor:** "O uso de reconhecimento nominal já na fase de interesse declarado (Capítulo 12) é psicologicamente bem fundamentado para gerar pertencimento precoce. Nenhuma inconsistência."

**CRM:** "O Sistema de Inteligência Prévia (Capítulo 8) é tecnicamente ambicioso e bem estruturado, mas falta clareza sobre o que acontece quando um atleta declara interesse e depois **não** se inscreve — o sistema não define se e como esse dado permanece útil (para aprendizado, Capítulo 17) sem virar uso indevido (Capítulo 16)."

**Growth Marketing:** "A conexão entre o Dashboard de Interesse e decisões reais de operação e comercial (Capítulo 14) é o ponto mais forte do documento — poucos sistemas de lançamento amarram dado de intenção a decisão operacional real dessa forma. Recomendo apenas que o Capítulo 13 inclua um indicador específico de 'taxa de não conversão declarada' (interesse que não virou inscrição), útil tanto para aprendizado quanto para ajuste de comunicação futura."

**Comunidades:** "O Sistema de Comunidade (Capítulo 12) trata bem a integração de novos e experientes. Ponto de atenção: não há menção a como moderar espaços de conversa genuína (grupos, comentários) para manter o mesmo padrão de respeito e controle que rege toda a marca — comunidade real também exige moderação real."

**Ciência de Dados:** "O Sistema de Inteligência de Mercado (Capítulo 9) está bem conectado aos KPIs da Fase 6. Recomendo que o documento explicite um período mínimo de maturação de dados (número de edições) antes que a inteligência de mercado seja considerada estatisticamente confiável para decisões estratégicas maiores, evitando decisões precipitadas com poucos ciclos de dado."

**Inteligência de Mercado:** "Concordo com Ciência de Dados. Além disso, o Capítulo 9 poderia esclarecer que dados de mercado eventualmente adquiridos de fontes externas (não apenas do próprio campeonato) também podem alimentar esse sistema, e não apenas dados internos."

**Ética em Marketing:** "O Sistema Ético (Capítulo 16) é robusto e consistente com toda a Constituição. Recomendo apenas incluir explicitamente o direito do atleta de ser esquecido/removido da base de interesse a qualquer momento, complementando o direito de revisão já mencionado — uma distinção técnica importante em termos de proteção de dados."

### Ajustes incorporados após a Rodada 1

- **Capítulo 4** passa a explicitar que a narrativa da cidade-sede é sempre subordinada e nunca substitui a identidade central da marca — usada como camada de contexto local, nunca como narrativa dominante de nenhuma edição.
- **Capítulo 8** passa a determinar que dados de interesse que não se convertem em inscrição são preservados, de forma anonimizada quando apropriado, exclusivamente para fins de aprendizado agregado (Capítulo 17) — nunca reutilizados para abordagem individual insistente ou pressão renovada sem novo consentimento.
- **Capítulo 13** passa a incluir explicitamente a "taxa de não conversão declarada" (interesse que não se tornou inscrição) como indicador formal, usado tanto para aprendizado quanto para calibração futura de comunicação.
- **Capítulo 12** passa a prever princípios formais de moderação de espaços de comunidade, alinhados ao mesmo padrão de respeito e controle que rege toda a voz da marca (Projeto 01).
- **Capítulo 9** passa a determinar um período mínimo recomendado de maturação de dados (múltiplas edições) antes que a inteligência de mercado seja usada como base isolada para decisões estratégicas de maior porte, sempre em conjunto com outras fontes de evidência já estabelecidas (Fase 1).
- **Capítulo 9** passa a admitir explicitamente a incorporação futura de dados de mercado de fontes externas complementares, não apenas dados internos do campeonato.
- **Capítulo 16** passa a incluir explicitamente o direito de remoção completa ("direito ao esquecimento") da base de interesse, complementar ao direito de revisão já previsto.

### Rodada 2 — segunda leitura crítica após ajustes

**Storytelling:** "A subordinação explícita da narrativa da cidade-sede à identidade central resolve minha preocupação — evita que uma edição futura, em uma cidade com identidade cultural forte, acabe diluindo a marca."

**CRM e Growth Marketing (avaliação conjunta):** "O tratamento de dados de interesse não convertido e a nova métrica de taxa de não conversão resolvem exatamente as lacunas que apontamos. O sistema está pronto para orientar implementação técnica real."

**Comunidades:** "Os princípios de moderação alinhados à voz da marca resolvem meu ponto de atenção."

**Ciência de Dados e Inteligência de Mercado (avaliação conjunta):** "O período mínimo de maturação de dados e a admissão de fontes externas complementares resolvem nossas observações técnicas."

**Ética em Marketing:** "O direito ao esquecimento agora está formalmente incluído, complementando corretamente o direito de revisão. Nenhuma nova inconsistência identificada."

**Consolidação final:** a segunda rodada não identificou nenhuma inconsistência estrutural relevante remanescente. Todos os ajustes da primeira rodada foram incorporados como princípios formais, protegendo simultaneamente a integridade ética do sistema e sua utilidade prática real. O ciclo iterativo é encerrado nesta rodada.

---

*Fim do Projeto 10 — Sistema de Lançamento e Mobilização do Campeonato. Documento oficial, fundamentado nas Fases 1-6 e nos Projetos 01-09, servindo como Constituição Permanente do Lançamento das Inscrições do Campeonato Brasileiro de Kettlebell Sport pelos próximos 100 anos.*
