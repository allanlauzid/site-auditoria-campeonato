# PROJETO 03 — SISTEMA DE IDENTIDADE VISUAL
### Campeonato Brasileiro de Kettlebell Sport
### Constituição Visual Oficial

*Fases 1-6 e Projetos 01-02 tratados como Constituição definitiva, com prioridade absoluta sobre qualquer decisão aqui contida. Este documento não cria logo, peças, mockups ou campanhas — cria o sistema visual permanente. Toda decisão abaixo é justificada por sua função em servir os seis conceitos-guia: Sustentar, Guardar, Memória, Tempo, Nome, Autenticidade, Contenção.*

---

## 1. FILOSOFIA VISUAL

A marca deve ser percebida visualmente como algo **feito para durar, não para impressionar rapidamente**. Cada decisão visual prioriza permanência sobre tendência — o objetivo não é parecer "moderna" em 2026, mas parecer igualmente correta em 2046, porque nunca tentou competir por modismo.

**Sensações que a identidade deve transmitir:** peso real (não decorativo), quietude sob controle, presença humana genuína, dignidade documental (a sensação de estar diante de um arquivo importante, não de uma peça publicitária descartável).

**Sensações que a identidade nunca deve transmitir:** urgência, caos visual, agressividade, artificialidade high-tech futurista, humor debochado, glamour de estúdio de suplemento alimentar.

Esta filosofia é a tradução direta, para o campo visual, da personalidade contida definida na Fase 3 e do princípio de autenticidade reforçado no Projeto 02.

---

## 2. DNA VISUAL

Elementos permanentes que tornam qualquer peça reconhecível, independente de quem a produza:

- **Presença de nomes reais em texto, sempre visível e nunca decorativo** — legendas de identificação (nome, box, cidade) fazem parte do sistema visual, não são acréscimo opcional.
- **Paleta de baixa saturação, alto significado** (Capítulo 3) — nenhuma cor é usada apenas por ser "vibrante".
- **Espaço negativo generoso** — respiro visual como equivalente gráfico direto do "silêncio" definido no Projeto 02.
- **Textura material (ferro, papel, pele) sobre textura digital/sintética** — reforça autenticidade e tempo.
- **Tipografia com peso editorial/documental**, nunca tipografia técno-futurista genérica de e-sports ou fitness digital.
- **Ausência total de elementos decorativos sem função** (sem faíscas, raios, explosões gráficas, textos em ângulo agressivo).

Uma peça só é considerada consistente com a marca quando a maioria desses elementos coexiste — nenhum isoladamente basta.

---

## 3. SISTEMA CROMÁTICO

**Lógica geral:** a paleta nasce do material literal do esporte (ferro fundido) e do corpo humano (pele, esforço), não de convenções genéricas de "energia esportiva" (vermelhos e laranjas vibrantes já ocupados por CrossFit/HYROX/Spartan).

| Cor | Referência | Papel | Justificativa psicológica |
|---|---|---|---|
| **Ferro** — `#2B2E30` | grafite escuro do próprio kettlebell | Cor dominante institucional | Peso, seriedade, permanência — literalmente a cor do objeto que sustenta o esporte. |
| **Terracota Queimada** — `#B5502C` | barro/terra queimada | Cor de destaque humano | Calor humano, identidade brasileira, contraponto orgânico ao frio do ferro — usada em nomes, destaques, reconhecimento. |
| **Osso** — `#EDE7DD` | papel envelhecido/arquivo | Fundo institucional e documental | Remete a registro, arquivo, memória — nunca branco puro, que soa clínico e sem tempo. |
| **Carvão** — `#141414` | quase-preto | Texto principal e contraste máximo | Legibilidade e seriedade sem recorrer a preto absoluto artificial. |

**Paleta secundária (apoio, uso limitado):** `#6B6F73` (cinza-ferro médio, para hierarquia textual secundária) e `#7A8073` (verde-oliva acinzentado, usado apenas em contextos técnicos/dados, nunca como cor de destaque emocional).

**Paleta institucional:** restrita a Ferro, Osso e Carvão — usada em documentos formais, regulamentos, apresentações a patrocinadores, garantindo sobriedade máxima.

**Paleta digital:** as mesmas cores, com uma variação de contraste ajustada (Osso levemente mais claro em telas escuras, Ferro levemente mais claro em telas OLED) para preservar legibilidade sem alterar a identidade cromática.

**Paleta para patrocinadores (coexistência):** campo neutro obrigatório em Osso ou Ferro sólido ao redor de qualquer logotipo de patrocinador, nunca Terracota — a cor de destaque da marca nunca compete visualmente com identidade de terceiros.

**Paleta para impressos:** conversão CMYK das quatro cores centrais, com Terracota calibrada para não derivar para tons alaranjados excessivamente vibrantes na impressão offset.

**Paleta monocromática:** versão integral do sistema em escala de cinza (derivada do Carvão ao Osso) — obrigatória para usos gravados, cunhados ou de baixo custo de reprodução (ex: medalhas, carimbos, o objeto ritual "Peso Testemunha" da Fase 3).

**Versões positivas e negativas:** versão positiva = Carvão/Ferro sobre Osso; versão negativa = Osso sobre Ferro/Carvão. Terracota nunca vira fundo — é sempre elemento de destaque pontual, nunca área extensa.

**Contraste mínimo:** relação de contraste mínima de 4.5:1 entre texto e fundo em qualquer aplicação digital (ver também Capítulo 17).

**Hierarquia entre cores:** Ferro e Carvão dominam volume (fundo/estrutura); Osso domina espaço negativo; Terracota é usada em no máximo 10–15% da composição total de qualquer peça — reforçando contenção.

**Quando usar Terracota:** nomes próprios, marcos de reconhecimento, elementos de destaque humano.
**Quando evitar Terracota:** grandes áreas de fundo, textos longos, qualquer contexto que exija neutralidade (documentos institucionais, coexistência com patrocinador).

---

## 4. TIPOGRAFIA

**Lógica geral:** a marca não usa tipografia técno-futurista de academia digital (comum em CrossFit/HYROX). Usa tipografia com caráter editorial/documental — como se cada peça pudesse, um dia, ser arquivada e lida como registro histórico.

- **Fonte principal (títulos/headline):** uma serifada humanista com presença monumental discreta — referência de caráter: *Tiempos Headline* (comercial) ou *Source Serif 4* (alternativa gratuita).
- **Fonte secundária (corpo de texto/UI):** uma sans-serif humanista de alta legibilidade — referência: *GT America* (comercial) ou *Inter* (alternativa gratuita).
- **Fonte para números e placares:** monoespaçada com algarismos tabulares, para leitura consistente em rankings — referência: *GT Pressura Mono* (comercial) ou *IBM Plex Mono* (alternativa gratuita).
- **Fonte para documentos formais:** a mesma serifada de títulos, em peso regular, garantindo unidade entre comunicação e documentação institucional.

**Hierarquia tipográfica:** título (serifada, peso Bold/Semibold) → subtítulo (sans, peso Medium) → corpo (sans, peso Regular) → legendas/nome de atleta (sans, peso Semibold, sempre em destaque equivalente ou superior ao corpo de texto — nunca menor, reforçando o valor "nome importa").

**Espaçamentos e entrelinhas:** entrelinha mínima de 1.4x o corpo do texto para leitura confortável; espaçamento generoso entre blocos, nunca comprimido — a contenção visual se aplica também ao respiro tipográfico.

**Pesos:** uso preferencial de pesos Regular, Medium e Semibold; pesos Ultra-bold e Ultra-thin são evitados — os primeiros por soarem agressivos, os segundos por comprometerem legibilidade e transmitirem fragilidade incompatível com a marca.

**Erros comuns a evitar:** uso de caixa alta extensa em blocos de texto (soa como grito, incompatível com o tom contido); condensar tipografia para "caber mais texto" (sacrifica legibilidade); misturar mais de duas famílias tipográficas em uma mesma peça.

---

## 5. SISTEMA DE LOGOTIPO (ESTRUTURA, NÃO DESENHO)

**Estrutura:** o sistema prevê três formas de assinatura — (1) lockup completo (símbolo + nome), (2) símbolo isolado (para aplicações pequenas/sociais), (3) wordmark apenas (para contextos institucionais/documentais onde o símbolo seria redundante).

**Proporções:** toda a estrutura é construída sobre uma unidade modular própria ("U"), derivada da proporção real de um kettlebell (razão entre alça e corpo) — essa unidade define espaçamento interno, altura relativa entre símbolo e texto, e não deve ser alterada por quem aplicar a marca.

**Área de proteção:** espaço livre mínimo ao redor do logotipo equivalente a 1U em todas as direções — nenhum elemento (texto, imagem, outro logotipo) pode invadir essa área.

**Reduções:** tamanho mínimo definido para garantir legibilidade do wordmark em qualquer suporte (a ser especificado em milímetros/pixels na fase de aplicação); abaixo do mínimo, usa-se exclusivamente o símbolo isolado.

**Versões:** cor cheia (Ferro/Terracota sobre Osso), monocromática positiva, monocromática negativa, versão gravada/cunhada (para medalhas e o objeto ritual Peso Testemunha).

**Usos proibidos:** distorcer proporções; aplicar sobre fotografia sem proteção de contraste adequada (Capítulo 17); adicionar sombras, gradientes, brilhos ou efeitos 3D não previstos no sistema; recolorir fora da paleta oficial; rotacionar o lockup.

**Assinaturas e co-branding:** em qualquer coexistência com marcas parceiras ou patrocinadoras, o logotipo do campeonato mantém posição dominante em eventos próprios, separado por linha divisória neutra (nunca fusão visual dos dois símbolos) — regra detalhada no Capítulo 16.

---

## 6. SISTEMA DE GRID

**Grid editorial (documentos, relatórios):** margens amplas (mínimo equivalente a 2U), coluna única ou dupla, nunca grid denso de revista — reforça contenção e legibilidade institucional.

**Grid digital (site):** sistema modular de 12 colunas responsivo, com gutters generosos; hierarquia visual construída por espaçamento, não por excesso de elementos por seção.

**Grid para redes sociais:** template modular fixo com zona de proteção reservada para legendas de nome/identificação (nunca sobrepor rosto ou informação central) — consistente em todos os formatos (feed, stories, capa de vídeo).

**Grid institucional (apresentações, propostas):** estrutura fixa de cabeçalho (logotipo + contexto), corpo (conteúdo) e rodapé (referência/data), replicada de forma idêntica em toda comunicação formal.

**Ritmo visual e espaçamento:** toda a família de grids segue múltiplos da unidade modular "U" definida no Capítulo 5, garantindo que logotipo, tipografia e layout compartilhem a mesma lógica matemática subjacente.

---

## 7. SISTEMA FOTOGRÁFICO

**Enquadramento:** preferência por planos médios e fechados que capturam rosto e tensão corporal; planos abertos usados apenas para estabelecer contexto de local, nunca como recurso de espetáculo.
**Distâncias e lentes:** distâncias focais naturais (aproximadamente 35mm–85mm), evitando grande-angular extremo (que distorce e "vende" drama artificial) e teleobjetivas excessivas (que despersonalizam o sujeito).
**Iluminação:** luz natural ou disponível sempre que possível; quando artificial, iluminação suave e direcional, nunca flash frontal duro ou setup de estúdio glamouroso.
**Textura:** grão sutil aceito e até desejável — reforça caráter documental sobre polimento publicitário.
**Profundidade:** rasa em retratos (isolamento do sujeito, intimidade); mais ampla em registros de contexto/arquivo.
**Contraste:** moderado a alto, sem saturação artificial tipo HDR.
**Movimento:** desfoque de movimento é aceito para comunicar esforço real; recursos de "freeze-frame" dramático genérico são evitados.
**Retratos:** contato visual direto sempre que possível, nome sempre disponível como legenda associada.
**Competição:** foco em rosto, mãos, postura — não apenas no equipamento.
**Bastidores:** estética deliberadamente menos tratada, reforçando autenticidade.
**Premiação:** dignidade e sobriedade, sem poses artificiais de "explosão de comemoração" genérica.
**Público:** captura de reações reais, nunca produção encenada de torcida.
**Patrocinadores:** registros institucionais sóbrios, sem estética publicitária destoante do restante do sistema.
**Documentação histórica:** prioridade de arquivo em alta resolução e metadados completos (nome, data, edição) — insumo direto do Sistema de Memória.
**O que nunca fazer:** retoque que remova suor, tensão muscular real ou expressões de esforço; poses artificiais tipo anúncio de suplemento; fundo infinito de estúdio associado a fotografia publicitária genérica de fitness.

---

## 8. SISTEMA DE VÍDEO

**Linguagem visual:** documental controlada — a câmera testemunha, não dirige artificialmente a emoção.
**Movimentos de câmera:** estáveis mas não artificialmente suaves; handheld controlado é preferível a grua/drone como recurso padrão (drone reservado para contexto, não para abertura espetacular).
**Ritmo e cortes:** pausado, com tomadas mais longas do que o padrão de mídia social tradicional — alinhado ao território "Respiração Contida" do Projeto 02.
**Estabilização:** moderada; pequena imperfeição de movimento é aceitável e reforça autenticidade.
**Composição:** centralizada e íntima em retratos; regra dos terços em planos de contexto.
**Lentes:** mesma lógica do sistema fotográfico.
**Iluminação:** natural sempre que possível.
**Color grading:** tons neutros-quentes derivados da paleta oficial (Capítulo 3); evitar o grading cinematográfico "teal-and-orange" genérico de publicidade esportiva.
**Tratamento:** textura/grão preservados, evitando aspecto digital "limpo demais".
**Motion e lettering:** mínimo, funcional — texto em tela usado para nome/identificação, nunca como recurso decorativo.
**Legendas:** sempre disponíveis para acessibilidade (Capítulo 17), com tipografia do sistema oficial.
**Lower thirds:** formato fixo — nome, box, cidade — nunca apenas nome isolado sem contexto de pertencimento.
**Vinhetas:** curtas, discretas, conduzidas por som real (respiração, ambiente) mais do que por efeito sonoro artificial.
**Encerramentos:** fecham preferencialmente em nome/referência de arquivo, não em selo de logotipo espetacular.

---

## 9. SISTEMA DE ÍCONES

**Estilo:** linear (outline), nunca preenchido em bloco sólido — reforça leveza e contenção.
**Espessura:** consistente em todo o sistema, moderada (nem ultra-fina, nem espessa).
**Raio de curvatura:** levemente arredondado nos vértices, o suficiente para transmitir humanidade sem parecer infantil ou lúdico.
**Geometria:** base modular alinhada à mesma unidade "U" da tipografia e do logotipo.
**Peso visual:** equilibrado — os ícones nunca competem visualmente com tipografia ou fotografia na mesma composição.
**Aplicações:** sinalização de evento, interface digital, indicadores de categoria/ranking.
**Famílias:** ícones técnicos-esportivos (categorias, critérios de pontuação), ícones de wayfinding (sinalização física de evento), ícones de status/sistema (plataforma digital/arquivo).

---

## 10. SISTEMA DE ILUSTRAÇÕES

**Quando usar:** exclusivamente em contextos de arquivo histórico, linha do tempo, infográficos educativos — nunca como recurso principal de campanhas de aquisição.
**Quando evitar:** qualquer aplicação que substitua fotografia real de pessoas reais (viola diretamente o princípio de autenticidade).
**Traço:** linear, referenciando gravura/estampa — reforça a ideia de "registro permanente" (conexão direta com "Guardar").
**Volume:** predominantemente bidimensional, evitando efeitos de volume 3D ou renderização realista, que soariam artificiais.
**Textura:** sutil, análoga à textura de impressão/gravação, nunca digital lisa.
**Nível de realismo:** estilizado o suficiente para não competir com fotografia, mas nunca cartunesco ou infantilizado.

---

## 11. SISTEMA DE INFOGRÁFICOS

**Hierarquia:** nome e contexto humano sempre precedem o dado numérico — a marca nunca comunica número antes de nome.
**Gráficos:** formatos simples (barra, linha), sem elementos decorativos tridimensionais ou "chart junk".
**Linhas:** finas, na cor Ferro ou Carvão, nunca coloridas apenas por decoração.
**Tabelas:** espaçamento generoso, alinhamento consistente, tipografia tabular (Capítulo 4).
**Comparativos:** usados exclusivamente para comparação histórica interna (edição a edição, atleta ao longo do tempo) — nunca para comparação direta e depreciativa com outras modalidades, conforme território proibido definido na Fase 3.
**Dados e resultados:** sempre vinculados ao nome do atleta/box/cidade correspondente.
**Rankings:** nome em destaque tipográfico igual ou superior à posição numérica.

---

## 12. SISTEMA DE MOTION DESIGN

**Transições:** cortes diretos e dissolves simples; transições 3D, "whoosh" ou efeitos chamativos são evitados.
**Animações:** curvas de aceleração suaves e deliberadas (easing), nunca bounce cartunesco ou movimento robótico abrupto.
**Velocidade:** moderada por padrão, refletindo o ritmo pausado definido no Sistema de Comunicação.
**Aceleração:** speed ramps e efeitos de "hype" são usados apenas em momentos raros e deliberados de ênfase, nunca como recurso padrão.
**Tempo:** espaçamento temporal generoso entre elementos animados — nada aparece e desaparece de forma frenética.
**Movimentos:** lineares e controlados.
**Partículas:** evitadas por padrão; se usadas, limitadas a texturas sutis (poeira de giz, referência tátil ao ambiente de treino), nunca faíscas, fogo ou explosões de energia.
**Elementos gráficos:** acentos geométricos mínimos, sempre derivados do sistema de ícones (Capítulo 9).

---

## 13. SISTEMA PARA REDES SOCIAIS

**Instagram:** canal principal de aplicação do território "Nome Próprio" — grid de feed com identidade visual consistente; Stories reservados a bastidor mais informal, ainda assim dentro da paleta oficial.
**Facebook:** tom institucional, textos mais longos, apoio a relacionamento com público de faixa etária mais madura e imprensa.
**LinkedIn:** aplicação mais formal do sistema — predominância da paleta institucional (Capítulo 3), foco em conteúdo para patrocinadores e parceiros.
**YouTube:** miniaturas com rosto real, nome em tipografia do sistema, sem setas, círculos vermelhos ou recursos de clickbait.
**TikTok:** uso criterioso — a lógica de tendência acelerada do formato tensiona diretamente com o princípio de contenção; quando usado, mantém ritmo mais pausado que o padrão da plataforma, priorizando autenticidade sobre viralização por efeito.
**Stories/Shorts/Reels:** formato curto segue as mesmas regras de identificação nominal obrigatória e paleta oficial.
**Carrosséis:** aplicação preferencial para conteúdo educativo/bastidor técnico (território "Bastidor Técnico", Projeto 02).
**Miniaturas e capas:** template consistente — rosto real, nome em destaque tipográfico, sem excesso de elementos gráficos sobrepostos.

---

## 14. SISTEMA EDITORIAL

**PDF e apresentações institucionais:** capa com lockup do logotipo, título, data/edição; corpo seguindo grid editorial (Capítulo 6); rodapé com referência de arquivo.
**Relatórios e propostas comerciais:** tom sóbrio, paleta institucional, tipografia serifada para credibilidade documental.
**Ofícios e regulamentos:** linguagem e diagramação neutras, sem elementos de marketing — o regulamento é documento técnico, não peça promocional.
**Certificados e diplomas:** nome do atleta/participante em destaque tipográfico máximo da peça — aplicação mais literal possível do valor "seu nome importa aqui".
**Credenciais:** foco em legibilidade funcional e hierarquia clara de informação (nome, função, acesso), mantendo a paleta e tipografia oficiais mesmo em peças puramente operacionais.

---

## 15. SISTEMA PARA EVENTOS

**Backdrop:** desenhado para valorizar quem está na frente dele (o atleta), não para ser um mural repetitivo de logotipos — aplicação do logotipo é discreta e espaçada, nunca em padrão saturado tipo "step and repeat" publicitário.
**Pódio:** design digno e sóbrio, sem elementos néon ou iluminação espetacular artificial.
**Faixas e painéis de sinalização:** hierarquia visual clara, tipografia legível a distância, paleta institucional.
**Credenciamento:** funcional, legível, com identificação nominal clara — reforça reconhecimento também na operação, não apenas na comunicação.
**Uniformes e camisas:** paleta discreta (Ferro/Osso predominantes), marca aplicada em escala pequena — a marca nunca "veste" a pessoa de forma ostensiva.
**Medalhas e troféus:** materiais e acabamento que sugerem permanência (metal, gravação), com espaço físico reservado para nome gravado — ligação direta ao objeto ritual "Peso Testemunha" da Fase 3.
**Numeração de peito/identificação:** tipografia tabular do sistema (Capítulo 4), sempre de alto contraste e legibilidade.
**Sinalização geral:** hierarquia de wayfinding consistente com o sistema de ícones (Capítulo 9).

---

## 16. SISTEMA PARA PATROCINADORES

**Hierarquia:** em eventos e comunicações próprias da marca, o logotipo do campeonato mantém posição dominante; patrocinadores ocupam zona secundária claramente delimitada.
**Coexistência:** nunca fusão visual entre símbolos — sempre separação por linha neutra ou espaçamento equivalente à área de proteção (Capítulo 5).
**Espaçamentos e reduções:** cada patrocinador recebe área proporcional de aplicação definida por nível de parceria (a ser detalhada em anexo comercial específico, conforme já sinalizado no Projeto 01).
**Contraste:** logotipos de patrocinadores aplicados apenas sobre campo neutro (Osso ou Ferro sólido), nunca sobre fotografia ou textura complexa.
**Co-branding:** permitido apenas em nível de "apresenta" (ex: "Campeonato X, apresentado por Y"), nunca como lockup fundido em um único símbolo.

---

## 17. SISTEMA DE ACESSIBILIDADE

**Contraste:** mínimo de 4.5:1 para texto padrão e 3:1 para texto grande, em conformidade com diretrizes WCAG AA, aplicável a toda peça digital.
**Daltonismo:** a paleta oficial (Ferro/Terracota/Osso/Carvão) foi construída com diferenciação suficiente de luminância para permanecer legível em simulações de daltonismo comuns (protanopia, deuteranopia); nenhuma informação crítica depende exclusivamente de diferenciação por cor.
**Legibilidade:** tamanho mínimo de texto definido por suporte (digital, impresso, sinalização de longa distância), nunca abaixo do limiar de conforto de leitura.
**Leitura:** largura de linha controlada (idealmente 50-75 caracteres por linha) em qualquer material editorial extenso.
**Fontes:** pesos ultra-finos evitados em corpo de texto pequeno, exatamente pelo motivo já citado no Capítulo 4.
**Responsividade:** todo o sistema de grid (Capítulo 6) é construído para adaptação fluida entre formatos, sem perda de hierarquia.
**Acessibilidade digital:** disciplina obrigatória de texto alternativo (alt text) em toda imagem publicada, incluindo, sempre que possível, o nome da pessoa retratada — a acessibilidade é tratada como extensão direta do valor "nome importa", não apenas como exigência técnica.

---

## 18. SISTEMA DE CONSISTÊNCIA — CHECKLIST DE VALIDAÇÃO

| Critério | Peso | Erro crítico se ausente |
|---|---|---|
| Paleta oficial respeitada (Capítulo 3) | Alto | Sim |
| Tipografia oficial aplicada corretamente (Capítulo 4) | Alto | Sim |
| Logotipo dentro da área de proteção e sem distorção (Capítulo 5) | Alto | Sim |
| Nome de pessoa real presente e legível, quando aplicável | Alto | Sim |
| Ausência de elementos decorativos sem função (Capítulo 2) | Médio | Não |
| Contraste de acessibilidade dentro do padrão (Capítulo 17) | Alto | Sim |
| Coexistência correta com patrocinadores (Capítulo 16), quando aplicável | Médio | Não |
| Alinhamento ao grid modular (Capítulo 6) | Médio | Não |

**Pontuação de aprovação:** qualquer peça com um ou mais "erros críticos" é automaticamente reprovada, independentemente da pontuação geral nos demais critérios — réplica direta da lógica de nota mínima simultânea já aplicada no Projeto 02.

---

## 19. GOVERNANÇA VISUAL

**Quem pode alterar o sistema:** apenas a Governança de Marca (Fases 5 e 6), com o Diretor de Marca como responsável técnico principal.
**Quem aprova aplicações do dia a dia:** Diretor de Arte/Design, seguindo o checklist do Capítulo 18; casos de dúvida ou exceção sobem à Governança de Marca.
**Como o sistema evolui:** qualquer proposta de mudança passa pelo mesmo Sistema de Inovação já definido no Projeto 02 — testada antes de virar prática recorrente, nunca implementada por decisão isolada de um único profissional ou fornecedor.
**Como documentar mudanças:** este manual é versionado formalmente; toda alteração aprovada gera um registro de changelog público internamente, preservando o histórico de decisões — aplicação direta do valor "Guardar" ao próprio processo de gestão da marca.
**Como proteger a identidade:** registro formal de marca (logotipo, nome) junto aos órgãos competentes; monitoramento de uso indevido por terceiros; nenhuma aplicação externa (patrocinador, parceiro, imprensa) usa qualquer elemento do sistema sem aprovação prévia documentada.

---

## 20. AUDITORIA FINAL — CONSELHO DE ONZE ESPECIALISTAS (CICLO ITERATIVO)

### Rodada 1 — críticas técnicas

**Diretor de Branding:** "A lógica de derivação de cada decisão a partir dos seis conceitos-guia é rara e bem executada — a maioria dos manuais de marca começa pela estética e tenta justificar depois. Aqui é o oposto, e isso é o que vai proteger a consistência a longo prazo."

**Diretor de Arte:** "Ponto de atenção real: o Capítulo 3 define hex codes específicos, o que é bom para consistência, mas o documento não define ainda uma escala de variação tonal (tints/shades) de cada cor para uso em UI digital com múltiplos estados (hover, disabled, etc.). Isso vai faltar na primeira aplicação prática."

**Designer Editorial:** "O grid editorial (Capítulo 6) está descrito em princípio, mas sem sistema de colunas numérico específico — 'margens amplas' e 'coluna única ou dupla' são orientação, não sistema replicável por qualquer designer sem interpretação pessoal."

**Designer Digital:** "Concordo com o ponto do Diretor de Arte. Além disso, o sistema de acessibilidade (Capítulo 17) está correto em princípio, mas falta relação explícita entre a paleta cromática (Capítulo 3) e os níveis de contraste — isso deveria estar amarrado tecnicamente, não apenas mencionado em capítulos separados."

**Motion Designer:** "O Capítulo 12 é sólido em princípios de movimento, mas não define durações de referência (ex: transições padrão entre X e Y milissegundos) — sem isso, cada motion designer vai interpretar 'moderado' de forma diferente."

**Fotógrafo:** "Já sinalizado no Projeto 02, mas reforço aqui no nível técnico: 'luz natural sempre que possível' precisa de uma exceção documentada para ambientes de arena fechada com iluminação artificial fixa, que é a realidade operacional mais provável de eventos de kettlebell sport indoor."

**Videomaker:** "O sistema de vídeo é coerente com o sistema fotográfico, o que facilita minha vida como profissional trabalhando nos dois formatos. Falta apenas orientação sobre frame rate/formato de entrega padrão — detalhe técnico, mas relevante para consistência entre fornecedores diferentes."

**Especialista em UX:** "O grid digital (Capítulo 6) e o sistema de acessibilidade (Capítulo 17) precisam estar mais integrados — hoje estão descritos como sistemas paralelos, quando deveriam ser tratados como uma única camada técnica no momento da implementação."

**Diretor de Marketing:** "A separação clara de paleta institucional para patrocinadores (Capítulo 3) e as regras de coexistência (Capítulo 16) me dão segurança de que a marca não vai se diluir comercialmente — isso é exatamente o que faltava nos documentos anteriores em nível mais operacional."

**Patrocinador:** "Gosto de ver regras explícitas de não-fusão de logotipos (Capítulo 16) — protege minha marca tanto quanto protege a do campeonato. Sugiro apenas que a 'área proporcional por nível de parceria' mencionada seja formalizada com mais urgência, não apenas citada como pendência futura."

**Atleta:** "Fiquei feliz em ver reconhecimento nominal presente até no sistema de credenciamento e nos infográficos de ranking (Capítulo 11) — não é só uma promessa de comunicação, está desenhada na estrutura visual em si."

### Ajustes incorporados após a Rodada 1

- **Capítulo 3** passa a prever explicitamente a necessidade de uma escala de variação tonal (tints/shades) de cada cor central, a ser especificada tecnicamente na fase de aplicação prática (fora do escopo deste manual constitucional, mas registrada como pendência formal obrigatória).
- **Capítulo 6** passa a indicar que o sistema numérico específico de colunas (grid editorial e digital) deve ser formalizado como anexo técnico complementar antes da primeira aplicação real, para eliminar ambiguidade de interpretação entre designers.
- **Capítulo 12** passa a indicar que durações de referência para transições e animações devem ser especificadas em anexo técnico de motion, mantendo aqui apenas os princípios de ritmo.
- **Capítulo 7** incorpora nota de exceção controlada para ambientes de arena fechada com iluminação artificial fixa, preservando o princípio de luz natural como padrão preferencial, não absoluto.
- **Capítulo 16** eleva a formalização da "área proporcional por nível de parceria" de menção secundária a pendência prioritária explícita, a ser resolvida antes da primeira negociação comercial relevante.
- **Capítulos 6 e 17** passam a ser tratados, na nota de governança, como uma camada técnica integrada (grid + acessibilidade) a ser especificada conjuntamente na fase de implementação digital, evitando inconsistência entre os dois sistemas.

### Rodada 2 — segunda leitura crítica após ajustes

**Diretor de Branding:** "Os ajustes resolvem as lacunas técnicas apontadas sem comprometer a filosofia constitucional do documento — que é, corretamente, definir princípio e função, não especificação de produção final."

**Especialista em UX:** "A integração explícita entre grid e acessibilidade como camada única de implementação resolve minha objeção. Não vejo mais inconsistência estrutural relevante neste nível de documento."

**Diretor de Arte:** "Como os anexos técnicos complementares (escala tonal, sistema de colunas, durações de motion) ficaram formalmente registrados como pendências obrigatórias — e não apenas esquecidos — considero que o documento está pronto para orientar a próxima fase de aplicação prática sem risco de ambiguidade grave."

**Consolidação final:** a segunda rodada não identificou nenhuma inconsistência estrutural adicional relevante — apenas confirma que as lacunas técnicas remanescentes (escalas tonais, sistema numérico de grid, durações de motion, área proporcional de patrocínio) são, corretamente, de natureza de *especificação de produção* e não de *decisão constitucional*, e por isso permanecem registradas como anexos técnicos obrigatórios a serem desenvolvidos na fase de aplicação, sem exigir nova revisão do sistema aqui construído. O ciclo iterativo é encerrado nesta rodada.

---

*Fim do Projeto 03 — Sistema de Identidade Visual. Documento oficial, fundamentado nas Fases 1-6 e nos Projetos 01-02, servindo como Constituição Visual permanente do Campeonato Brasileiro de Kettlebell Sport.*
