# PROJETO 01 — SISTEMA DE COMUNICAÇÃO
### Campeonato Brasileiro de Kettlebell Sport
### Manual Oficial de Comunicação

*Fases 1 a 6 tratadas como Constituição definitiva. Este documento não cria campanhas, posts ou calendário — cria o sistema permanente do qual toda comunicação futura deve ser derivada.*

---

## 1. FILOSOFIA DA COMUNICAÇÃO

**Como a marca deve comunicar:** com controle, precisão e nomes próprios. Toda comunicação parte do princípio de que o público já é inteligente e merece ser tratado com respeito, não convencido por volume ou urgência. A marca fala pouco e com peso — prefere uma frase precisa a dez frases genéricas. Ela mostra, mais do que declara: em vez de dizer "somos incríveis", mostra um nome, uma trajetória, um momento real de esforço sustentado.

**Como a marca nunca deve comunicar:** com euforia artificial, urgência fabricada, comparação depreciativa com outras modalidades, ou linguagem que trata o público como massa anônima a ser convertida. A marca nunca comunica como quem está pedindo atenção — comunica como quem já tem algo genuíno para mostrar e confia que isso basta.

Esta filosofia deriva diretamente da personalidade definida na Fase 3 (Capítulo 7): madura, contida, precisa. Qualquer material que soe "como qualquer marca de fitness" já falhou no primeiro filtro deste sistema.

---

## 2. OBJETIVOS DE COMUNICAÇÃO POR PÚBLICO

- **Atletas:** fazer sentir que sua trajetória é vista, nomeada e registrada — não apenas seu resultado.
- **Iniciantes:** reduzir intimidação técnica, mostrando que competir é possível sem ser atleta de elite.
- **Treinadores:** garantir reconhecimento público do trabalho técnico, não apenas menção de rodapé.
- **Boxes:** posicionar como parceiros e vitrine, nunca como concorrência.
- **Patrocinadores:** demonstrar território de marca defensável e crescente, com indicadores de profundidade traduzidos em linguagem clara.
- **Imprensa:** oferecer ângulo humano genuíno, não apenas dado técnico de nicho.
- **Comunidade:** sustentar pertencimento contínuo entre edições, não apenas comunicação sazonal.
- **Familiares:** traduzir o esforço técnico em algo emocionalmente compreensível e admirável.
- **Público geral:** fazer a categoria "Kettlebell Sport" existir, pela primeira vez, como opção legítima na cabeça de quem nunca ouviu falar — resolução direta do problema de existência categórica identificado na Fase 2.

---

## 3. ARQUITETURA DAS MENSAGENS

**Mensagem central (a única que nunca muda):**
**"Você sustenta. Nós guardamos."**
Operacionaliza a Big Idea da Fase 3 como mensagem comunicável — é a mensagem-mãe da qual todas as outras derivam.

**Mensagens secundárias (pilares permanentes de apoio):**
1. "Força é controle, não caos." — diferenciação de tom.
2. "Seu nome importa aqui." — promessa de reconhecimento.
3. "Você nunca compete sozinho de verdade." — camada de comunidade/testemunho.
4. "A técnica leva mais longe que a intensidade." — prestígio técnico acessível.
5. "Isso não é um evento. É uma trajetória." — calendário afetivo/temporada contínua.

**Mensagens específicas por público:**
- Atleta: "Sua trajetória fica registrada, edição após edição."
- Treinador: "Seu trabalho técnico tem nome e crédito público aqui."
- Box: "Vocês são vitrine, não concorrência."
- Patrocinador: "Associação a um território único, não a mais um evento genérico."
- Imprensa: "Há uma história humana real por trás de cada série de dez minutos."
- Espectador: "Você vai sentir a tensão, mesmo sem entender todas as regras."
- Voluntário/Árbitro: "Quem sustenta esse campeonato também é lembrado por nome."

---

## 4. STORYTELLING PERMANENTE

**Histórias que a marca contará durante os próximos anos:**
- A história do esforço sustentado e silencioso de um atleta específico durante uma série — o núcleo dramático do "Duelo Testemunhado".
- Histórias de retorno — atletas que competem pela segunda, terceira, quinta vez, mostrando trajetória acumulada.
- Histórias de origem técnica — o trabalho de treinadores e boxes na formação de atletas.
- Histórias de bastidor técnico — como se treina, como se julga, como se pontua, traduzidas para quem não entende o esporte.
- Histórias de integridade — árbitros, critérios, transparência de processo, reforçando o valor de honestidade competitiva.
- Ocasionalmente, histórias de herança e origem histórica do kettlebell (tradição russa), usadas com cuidado cultural, como camada secundária de profundidade — nunca como narrativa central.

**Histórias que a marca nunca contará:**
- Sofrimento físico extremo ou lesão tratados como prova de valor.
- Comparações depreciativas com CrossFit, HYROX, Spartan ou qualquer outra modalidade.
- Urgência ou escassez fabricada ("últimas vagas" quando não é real).
- Qualquer narrativa que trate um atleta como número, estatística ou massa anônima.
- Qualquer conteúdo político-partidário ou de exploração estética/emagrecimento comparativo.

---

## 5. TOM DE VOZ

**Personalidade:** madura, contida, precisa — a mesma pessoa descrita na Fase 3 (Capítulo 7), que fala pouco, mas é ouvida.
**Ritmo:** pausado e deliberado. Frases curtas. Parágrafos respiráveis. A pontuação nunca sugere pressa.
**Intensidade:** contida por padrão, permitindo picos emocionais pontuais apenas em momentos de real significado (ex: reconhecimento de um atleta, fechamento de uma edição) — nunca como tom constante.
**Linguagem:** concreta e sensorial, ligada ao corpo e ao tempo — nunca abstrata ou genérica de "marketing de fitness".
**Formalidade:** sóbria, mas calorosa — nunca corporativa fria, nunca informal excessiva (sem gírias forçadas ou excesso de emojis).
**Humor:** raro e nunca irônico ou debochado; quando presente, é sutil e humano, nunca usado para gerar viralização barata.
**Emoção predominante:** orgulho contido, admiração, tensão respeitosa — nunca euforia genérica ou drama artificial.

---

## 6. VOCABULÁRIO OFICIAL

**Palavras obrigatórias (ancoram a identidade, devem aparecer com frequência):**
Nome, sustentar, guardar, testemunha, trajetória.
*Motivo: são a tradução direta da essência e da Big Idea da marca — sem elas, a comunicação perde identidade mesmo que o tom esteja correto.*

**Palavras recomendadas:**
Controle, domínio, presença, prova, continuar, reconhecer, memória, disciplina.
*Motivo: reforçam o território de "força controlada" e a personalidade contida definida na Fase 3.*

**Palavras neutras (podem ser usadas sem risco, mas não carregam identidade própria):**
Treino, competição, resultado, categoria, série, prova técnica.
*Motivo: vocabulário funcional do esporte, necessário para clareza, mas não diferenciador.*

**Palavras proibidas:**
Insano, brutal, destruir, guerra, "beast mode", "no pain no gain", "sem limites".
*Motivo: contradizem diretamente o valor de "controle acima do caos" (Fase 3, Capítulo 5) e reproduzem linguagem já ocupada por concorrentes diretos (CrossFit, Spartan).*

---

## 7. NARRATIVAS ESTRATÉGICAS

- **"O Duelo Testemunhado"** — narrativa central, usada em conteúdo de descoberta e em qualquer material que precise capturar atenção de quem ainda não conhece o esporte.
- **"A Casa que Espera"** — usada em comunicação de comunidade e retenção, entre edições, reforçando o calendário afetivo.
- **"Trajetória Documentada"** — usada em conteúdo de retorno de atletas e em material de legado/arquivo histórico.
- **"Bastidor Técnico"** — usada em conteúdo educativo voltado a iniciantes e a públicos que não entendem o esporte.
- **"Tradição Reinventada"** — usada esporadicamente, como camada de profundidade cultural, nunca como narrativa de largada de nenhuma campanha.

Cada narrativa é ativada de acordo com o estágio da jornada de comunicação (Capítulo 9): "Duelo Testemunhado" domina os estágios iniciais (descoberta), "Bastidor Técnico" domina os estágios de compreensão, "Casa que Espera" e "Trajetória Documentada" dominam os estágios de pertencimento e retorno.

---

## 8. SISTEMA DE MENSAGENS POR PÚBLICO

- **Atleta:** mensagem central + ênfase em reconhecimento nominal e registro de trajetória.
- **Treinador:** mensagem central + ênfase em crédito técnico público.
- **Box:** mensagem central + ênfase em parceria e vitrine territorial.
- **Patrocinador:** mensagem central + ênfase em território de marca defensável e indicadores de profundidade.
- **Imprensa:** mensagem central + ênfase em história humana concreta, não em dado técnico isolado.
- **Espectador:** mensagem central + ênfase em tensão emocional acessível sem conhecimento prévio de regras.
- **Voluntário:** mensagem central + ênfase em reconhecimento formal de quem sustenta a operação.
- **Árbitro:** mensagem central + ênfase em integridade e responsabilidade técnica reconhecida publicamente.

Em todos os casos, a mensagem central ("Você sustenta. Nós guardamos.") nunca é substituída — apenas ganha ênfase diferente conforme o público.

---

## 9. JORNADA DE COMUNICAÇÃO

1. **Nunca ouvi falar → Conheci:** comunicação de pura descoberta, sem pedir nada — narrativa "Duelo Testemunhado" em formato curto e visualmente impactante.
2. **Conheci → Gostei:** comunicação educativa, traduzindo tecnicidade em fascínio — narrativa "Bastidor Técnico".
3. **Gostei → Confiei:** comunicação de prova social genuína — histórias reais de atletas, treinadores, boxes, com nomes reais.
4. **Confiei → Participei:** comunicação transparente de processo (inscrição, regras, expectativa realista) — sem urgência artificial.
5. **Participei → Voltei:** comunicação de reconhecimento pós-evento e contato contínuo — narrativa "Casa que Espera".
6. **Voltei → Indiquei:** comunicação que reforça pertencimento territorial (box, cidade) o suficiente para gerar indicação espontânea.
7. **Indiquei → Defendo a marca:** comunicação que trata o indivíduo como parte da história institucional — narrativa "Trajetória Documentada", reforçando identidade de longo prazo.

Em cada etapa, o tom permanece o mesmo (Capítulo 5) — o que muda é a função da mensagem: descobrir, educar, provar, converter, reter, expandir, consolidar.

---

## 10. PAPEL DOS CANAIS

- **Instagram:** descoberta visual e narrativa curta — porta de entrada da jornada.
- **YouTube:** aprofundamento documental — único canal capaz de sustentar o drama contido do "Duelo Testemunhado" em formato longo.
- **LinkedIn:** comunicação institucional voltada a patrocinadores, parceiros e imprensa especializada — tom mais formal, indicadores e resultados.
- **WhatsApp:** proximidade e pertencimento real entre edições — comunidade, não broadcast de massa.
- **Email:** memória formal e arquivo pessoal do atleta — reforça diretamente a promessa "nós guardamos".
- **Site institucional:** casa permanente do Livro de Nomes e do arquivo histórico.
- **Landing pages:** conversão pontual e transparente, usada apenas em momentos de decisão concreta.
- **Assessoria de imprensa:** legitimidade externa, resolvendo o problema de existência categórica.
- **Eventos presenciais:** entrega definitiva e inegável de toda promessa da marca.

---

## 11. SISTEMA DE CONTEÚDO (TIPOS, NÃO PEÇAS)

- **Conteúdo de Descoberta:** curto, visual, sem pedir ação — função: iniciar a jornada para quem nunca ouviu falar.
- **Conteúdo Documental/Dramático:** formato longo, foco em tensão e respiração real de competição — função: aprofundar fascínio e diferenciação.
- **Conteúdo Técnico-Educativo:** traduz regras, critérios e técnica em linguagem acessível — função: reduzir intimidação, converter curiosidade em compreensão.
- **Conteúdo de Memória/Arquivo:** revisita nomes, histórias e trajetórias já registradas — função: sustentar retenção e pertencimento de longo prazo.
- **Conteúdo Institucional:** indicadores, resultados, apresentações formais — função: sustentar relacionamento com patrocinadores, parceiros e imprensa.
- **Conteúdo de Comunidade/Bastidor:** cotidiano de boxes, treinadores, voluntários — função: reforçar camadas de pertencimento fora da janela de competição.

Esses seis tipos se conectam de forma cíclica: o Conteúdo de Descoberta alimenta a entrada de novos públicos; o Técnico-Educativo os converte em compreensão; o Documental aprofunda desejo; o de Comunidade sustenta pertencimento contínuo; o de Memória fecha o ciclo transformando participação em legado; o Institucional sustenta financeiramente todo o sistema.

---

## 12. GESTÃO DE CRISES

**Princípio geral:** a marca responde a qualquer crise com o mesmo valor que exige de seus atletas — controle, não caos.

- **Críticas:** reconhecidas publicamente com transparência direta, sem tom defensivo ou espetáculo de justificativa.
- **Erros:** admitidos de forma objetiva, com plano de correção comunicado — nunca minimizados ou silenciados.
- **Acidentes:** comunicação prioriza segurança e cuidado humano antes de qualquer preocupação de imagem; informações são atualizadas conforme fatos confirmados, nunca especulação.
- **Cancelamentos:** comunicados com antecedência máxima possível e explicação honesta do motivo — nunca escondidos até o último momento.
- **Polêmicas:** avaliadas primeiro internamente pela Governança de Marca (Fase 5/6) antes de qualquer resposta pública, garantindo que a resposta esteja alinhada aos valores e não seja reativa.

Nenhuma resposta de crise usa linguagem de marketing ou tom promocional — o registro é sempre institucional, direto e humano.

---

## 13. COMUNICAÇÃO PARA PATROCINADORES

Comunicar valor a patrocinadores exige traduzir os indicadores de profundidade definidos nas Fases 4 e 6 (retenção, território de marca, completude de arquivo) em linguagem que comitês de patrocínio tradicionais também reconheçam — sem abandonar a lógica de profundidade em favor de métricas vazias de alcance bruto.

**Como traduzir indicadores:** cada indicador de profundidade é sempre acompanhado de uma métrica equivalente em linguagem comercial tradicional (ex: retenção de atletas traduzida como "taxa de recompra de experiência"; completude de arquivo histórico traduzida como "ativo de conteúdo de longo prazo apropriável pela marca patrocinadora").

**Como apresentar resultados:** relatórios formais combinam dado quantitativo (alcance, engajamento, renovação) com narrativa qualitativa real (histórias documentadas, nomes reconhecidos) — nunca apenas planilha, nunca apenas discurso emocional isolado.

---

## 14. COMUNICAÇÃO INTERNA

Toda a equipe, independentemente da função, deve conhecer profundamente a Constituição do projeto (Fases 1 a 6) antes de produzir qualquer material — não apenas o time de comunicação. Isso é garantido por:

- Onboarding obrigatório baseado neste Sistema de Comunicação e na Plataforma de Marca (Fase 3) para qualquer novo integrante da equipe.
- Reuniões periódicas de alinhamento (ligadas aos rituais de governança definidos na Fase 6) revisando casos reais de aplicação correta e incorreta da voz da marca.
- Acesso permanente e centralizado a este documento como referência viva, não apenas material de indução inicial.

---

## 15. AUDITORIA DE COMUNICAÇÃO — CHECKLIST PRÉ-PUBLICAÇÃO

Antes de qualquer material ser publicado, deve responder "sim" a todas as perguntas abaixo:

1. Este material usa a mensagem central ou uma das mensagens secundárias como base?
2. O tom está de acordo com a personalidade contida e precisa definida no Capítulo 5?
3. Nenhuma palavra proibida (Capítulo 6) foi usada?
4. Alguma pessoa real está sendo nomeada, quando aplicável?
5. Não há nenhuma escassez, urgência ou exclusividade fabricada?
6. O material está alinhado a algum dos Territórios da Marca definidos na Fase 3, e não fala sobre nenhum território proibido?
7. Um iniciante entenderia o conteúdo sem se sentir excluído?
8. Este material poderia ser confundido com o de um concorrente direto (CrossFit, HYROX, Spartan)? Se sim, revisar.

---

## 16. SISTEMA DE APROVAÇÃO

- **Quem revisa:** Diretor de Comunicação (Fase 6), responsável pela primeira revisão de qualquer material.
- **Quem aprova:** Diretor de Comunicação aprova materiais operacionais do dia a dia; materiais institucionais de maior visibilidade (campanhas de lançamento, comunicação de crise, material para patrocinadores) exigem aprovação conjunta com o Diretor Executivo.
- **Quem pode publicar:** apenas integrantes formalmente autorizados dentro do Programa de Comunicação (Fase 6), nunca publicação direta sem passar pelo checklist do Capítulo 15.
- **Quem possui poder de veto:** o Diretor de Marca, na função de Governança de Marca (Fases 5 e 6) — pode barrar qualquer material, mesmo já aprovado operacionalmente, se identificar contradição com a Constituição do projeto.

---

## 17. INDICADORES DE QUALIDADE DE COMUNICAÇÃO

- **Compreensão:** percentual de público que, em pesquisa informal ou comentários, demonstra entender corretamente o que é o esporte e o campeonato após consumir conteúdo educativo.
- **Confiança:** ausência de reclamações relacionadas a promessas não cumpridas (ex: reconhecimento prometido e não entregue).
- **Pertencimento:** frequência de interação espontânea da comunidade nos canais de proximidade (WhatsApp, comentários, presença recorrente).
- **Reputação:** proporção de menções espontâneas de imprensa e criadores de conteúdo que utilizam corretamente a linguagem e o território da marca (vocabulário oficial, Capítulo 6).
- **Retenção:** percentual de público que avança de fato ao longo da jornada de comunicação (Capítulo 9), não apenas volume de alcance em cada publicação isolada.

Estes indicadores são medidos em conjunto com os KPIs de Comunicação já definidos na Fase 6 — este capítulo aprofunda a leitura qualitativa que os KPIs quantitativos, sozinhos, não capturam.

---

## 18. AUDITORIA FINAL — CONSELHO DE SETE ESPECIALISTAS

**Diretor de Branding:** "O sistema traduz com fidelidade a Plataforma de Marca da Fase 3 em ferramenta prática de uso diário — o checklist do Capítulo 15 é particularmente útil porque transforma princípios abstratos em perguntas objetivas de sim ou não."

**Diretor de Comunicação:** "Minha única ressalva operacional: com uma equipe pequena nos primeiros anos (conforme já mapeado na Fase 6), pode ser difícil sustentar revisão dupla (Diretor de Comunicação + Executivo) em todo material institucional sem gerar gargalo. Recomendo que o sistema de aprovação preveja um nível intermediário de agilidade para materiais de baixo risco."

**Jornalista Esportivo:** "A distinção entre Conteúdo Documental e Conteúdo Institucional (Capítulo 11) é exatamente o tipo de material que facilita meu trabalho como pauta — recomendo que o relacionamento de imprensa (Capítulo 10) sempre ofereça acesso direto ao Conteúdo Documental bruto, não apenas releases institucionais prontos."

**Psicólogo do Consumidor:** "O vocabulário oficial (Capítulo 6) está bem fundamentado psicologicamente — palavras concretas e ligadas ao corpo geram maior identificação emocional do que abstrações genéricas de fitness. Ponto de atenção: garantir que o tom 'contido' não seja confundido, por quem nunca viu o esporte, com frieza ou desinteresse — a linha entre contenção e indiferença é sutil e precisa de exemplos práticos de calibração."

**Patrocinador:** "A tradução de indicadores de profundidade para linguagem comercial tradicional (Capítulo 13) é exatamente o que faltava nos documentos anteriores — recomendo que essa tradução seja formalizada em um anexo específico de apresentação comercial, não apenas descrita conceitualmente aqui."

**Atleta:** "Gosto de ver que existe uma pergunta específica no checklist sobre nomear pessoas reais (pergunta 4) — isso é, na prática, o que diferencia esse projeto de qualquer outro evento em que já competi."

**Especialista em Relações Públicas:** "A Gestão de Crises (Capítulo 12) está bem alinhada aos valores da marca, mas está descrita em nível de princípio, não de processo. Recomendo que uma futura fase operacional detalhe um fluxo formal de resposta (prazo, porta-voz designado, canais de primeira resposta), especialmente para acidentes e cancelamentos, onde velocidade de resposta é crítica."

**Consolidação das críticas:** as críticas não contradizem o sistema construído — apontam refinamentos operacionais específicos, incorporados como ajustes: **(1)** o sistema de aprovação (Capítulo 16) passa a prever um nível ágil de aprovação para materiais de baixo risco, evitando gargalo em equipes pequenas; **(2)** a tradução de indicadores para patrocinadores (Capítulo 13) deve ser formalizada como anexo comercial específico em fase futura de execução; **(3)** a Gestão de Crises (Capítulo 12) deve ganhar, em fase operacional futura, um fluxo formal de resposta com prazos e porta-voz definidos, mantendo os princípios aqui estabelecidos como base inegociável.

---

*Fim do Projeto 01 — Sistema de Comunicação. Documento oficial, fundamentado nas Fases 1 a 6, servindo como Manual de Comunicação permanente do Campeonato Brasileiro de Kettlebell Sport.*
