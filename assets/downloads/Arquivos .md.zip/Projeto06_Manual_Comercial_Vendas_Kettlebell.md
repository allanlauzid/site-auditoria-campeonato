# PROJETO 06 — MANUAL COMERCIAL E SISTEMA DE VENDAS
### Campeonato Brasileiro de Kettlebell Sport
### Manual Comercial Oficial + Sponsor Kit (Sistema, não peças)

*Fases 1-6 e Projetos 01-05 são Constituição definitiva e têm prioridade absoluta. Este documento não cria preços, propostas, apresentações ou contratos — cria o sistema permanente do qual toda ação comercial deve nascer, aplicável a qualquer pessoa da equipe, em qualquer formato de venda (presencial, online, prospecção, negociação, renovação).*

---

## 1. FILOSOFIA COMERCIAL

**Como vender:** vendendo participação institucional, não espaço publicitário — a mesma filosofia já estabelecida no Projeto 05, agora aplicada à prática comercial do dia a dia. O vendedor nunca começa a conversa por preço ou por audiência; começa pelo território de marca e pela pergunta sobre o que a empresa está tentando construir a longo prazo.

**Como nunca vender:** nunca inflando números de alcance, nunca prometendo exclusividade sem aprovação formal (Projeto 05, Capítulo 12), nunca contornando o checklist de alinhamento (Fase 6, P10) sob pressão de fechar um contrato rapidamente.

**O papel do comercial:** traduzir o valor institucional construído desde a Fase 1 em linguagem que um decisor comercial reconheça — sem, em nenhum momento, ter autoridade para alterar as regras protegidas pela Governança de Marca.

**O que significa captar um patrocinador:** significa encontrar uma empresa cujos objetivos são genuinamente servidos pelo território de marca do campeonato — não apenas encontrar alguém disposto a pagar.

**Como proteger a marca durante a negociação:** o vendedor nunca tem autoridade para prometer qualquer elemento fora do inventário comercial aprovado (Capítulo 10) ou fora do checklist ético (Projeto 05, Capítulo 14) — qualquer exceção sobe formalmente à Governança de Marca antes de qualquer compromisso verbal ou escrito.

---

## 2. JORNADA COMERCIAL

1. **Prospecção** — identificação de empresas alinhadas ao ICP (Capítulo 3).
2. **Primeiro contato** — apresentação institucional breve, sem pressão de venda imediata.
3. **Diagnóstico** — aplicação do Sistema de Descoberta (Capítulo 5).
4. **Qualificação** — checagem contra ICP e contra a lista de recusa (Projeto 05, Capítulo 14).
5. **Reunião** — apresentação de valor (Capítulo 6) e narrativa comercial (Capítulo 7).
6. **Apresentação formal** — uso do material comercial adequado ao estágio (Capítulo 9).
7. **Negociação** — conforme limites e autorizações do Capítulo 13.
8. **Proposta** — estruturada conforme Capítulo 12.
9. **Follow-up** — cadência definida, nunca pressão de urgência artificial (mesmo princípio de honestidade competitiva do Projeto 05).
10. **Fechamento** — segue integralmente o fluxo de aprovação do Projeto 05, Capítulo 12, antes de qualquer assinatura.
11. **Onboarding** — entrega e explicação do Brand Book (Projeto 04) e das regras de co-branding (Projeto 05).
12. **Renovação** — conforme Capítulo 14.
13. **Encerramento** — quando aplicável, segue os princípios de transição do Projeto 05, Capítulo 17.

---

## 3. ICP — IDEAL CUSTOMER PROFILE

**Empresas que fazem sentido:** organizações com horizonte de marca de médio a longo prazo (não apenas campanha pontual), setores compatíveis com os valores da Fase 3 (performance, saúde, bem-estar sério, tecnologia esportiva, nutrição responsável, equipamentos), com maturidade de marketing suficiente para entender território emocional de marca, não apenas comprar mídia por alcance bruto.

**Empresas que não fazem sentido:** empresas que buscam apenas exposição pontual sem interesse em relacionamento contínuo; empresas cujo posicionamento de comunicação seja fundamentalmente incompatível com o tom contido da marca (ex: marcas construídas inteiramente sobre hype/urgência agressiva); qualquer empresa na lista de recusa do Projeto 05, Capítulo 14.

**Critérios:** alinhamento de valores (obrigatório) · capacidade financeira compatível com o nível pretendido (Projeto 05, Capítulo 11) · horizonte de relacionamento de pelo menos um ciclo de edição completo.

**Segmentos prioritários:** performance/saúde, equipamentos e tecnologia esportiva, nutrição/suplementação séria (não associada a discurso de atalho ou risco), instituições de ensino ligadas a educação física/saúde, órgãos públicos de esporte.

**Porte:** o sistema é desenhado para atender de pequenas empresas regionais (nível Bronze/Apoiador) a grandes empresas nacionais (Master/Ouro) — nenhum porte é excluído por padrão, apenas por desalinhamento de valores ou categoria já ocupada.

---

## 4. PERSONAS DOS PATROCINADORES

- **Grandes empresas nacionais:** ciclo de decisão longo, exigem tradução institucional robusta (Capítulo 6), maior probabilidade de contrato Master/Ouro multianual.
- **Empresas regionais:** decisão mais rápida, forte conexão com comunidade local (boxes/cidades) — perfil natural para Bronze/Apoiador e eventos paralelos regionais (Fase 5).
- **Indústrias de equipamento/fitness:** interesse técnico direto no esporte, perfil natural para o nível Fornecedor Oficial (Projeto 05, Capítulo 2).
- **Academias e boxes maiores:** relação estrutural, não necessariamente financeira — tratadas majoritariamente pelo Sistema de Boxes (Fase 5), não pelo comercial tradicional.
- **Universidades:** interesse em pesquisa, formação e legitimidade acadêmica — perfil de Parceiro institucional (Projeto 05, Capítulo 2), não patrocínio comercial padrão.
- **Órgãos públicos:** interesse em fomento esportivo e visibilidade institucional — tratados como Parceiros, com processo próprio fora da lógica comercial de cotas.
- **Startups:** ágeis na decisão, mas exigem atenção redobrada de risco financeiro (Capítulo 8, Projeto 05 — mitigação de dependência de patrocinador único/instável).
- **Empresas internacionais:** seguem as mesmas regras de qualquer patrocinador nacional, conforme Projeto 05, Capítulo 15 — sem tratamento preferencial automático por porte.

---

## 5. SISTEMA DE DESCOBERTA

Perguntas centrais de diagnóstico em qualquer primeira conversa comercial:

- Qual problema de marca ou de relacionamento com público esta empresa está tentando resolver?
- Qual foi a experiência prévia (se houver) com patrocínio esportivo — o que funcionou, o que não funcionou?
- Qual é o horizonte de tempo que a empresa considera para essa decisão (campanha pontual vs. relacionamento de longo prazo)?
- Quem decide, e qual é o ciclo orçamentário relevante?
- Qual é o momento atual da empresa (expansão, reposicionamento de marca, lançamento de produto, entrada em novo público)?
- O que a empresa entende, hoje, por "retorno" de um patrocínio — audiência bruta, associação de território, relacionamento com comunidade, ou outra métrica?

O diagnóstico determina qual camada do Sistema de Valor (Capítulo 6) deve ser enfatizada em cada conversa — não existe um pitch único para todas as empresas.

---

## 6. SISTEMA DE VALOR

**Como apresentar valor:** sempre começando pelo território de marca (o que este campeonato representa que nenhum outro evento representa), não pelo número de seguidores.

**Como apresentar diferenciais:** o Kettlebell Sport ocupa um território emocional ainda não saturado (Fase 2) — diferente de patrocinar CrossFit, HYROX ou Spartan, onde a marca do patrocinador se dilui entre dezenas de outras.

**Como apresentar ROI:** sempre em par duplo — indicador de profundidade (retenção, território, comunidade) e sua tradução em métrica comercial tradicional, exatamente conforme já formalizado no Projeto 01, Capítulo 13, e reforçado no Projeto 05, Capítulo 13.

**Como apresentar impacto institucional:** mostrando o Sistema de Memória (Fase 5) como ativo real — a empresa não está comprando uma menção passageira, está entrando em um arquivo histórico permanente.

**Como apresentar legado:** através do conceito de "guardião fundador" (Projeto 05, Capítulo 11) — para empresas que entram cedo, a mensagem central é que elas se tornam parte da história do esporte no Brasil, não apenas financiadoras de um evento anual.

---

## 7. SISTEMA DE STORYTELLING COMERCIAL

Estrutura narrativa oficial para qualquer apresentação comercial, adaptável em profundidade mas nunca em ordem lógica:

1. **Abertura:** um nome real, um momento de esforço sustentado — a mesma matéria-prima emocional usada no território "Duelo Testemunhado" (Projeto 02), agora usada para capturar atenção comercial genuína, não fabricada.
2. **Contexto:** o esporte existe, tem paixão real, mas ainda não ocupa espaço na mente do brasileiro comum — a oportunidade de entrar cedo.
3. **Problema:** a maioria dos patrocínios esportivos vende apenas exposição temporária, sem instituição real por trás.
4. **Oportunidade:** este campeonato oferece associação a um território de marca único, defensável e mensurável ao longo do tempo — não apenas um logotipo em um banner.
5. **Comunidade:** provas reais — atletas, boxes, treinadores, histórias documentadas no Sistema de Memória.
6. **Legado:** a possibilidade concreta de ser lembrado, formalmente, como parte da construção do esporte no Brasil.
7. **Encerramento e CTA:** convite a "fazer parte" — nunca "comprar espaço", reforçando a filosofia do Capítulo 1 até na última frase da apresentação.

---

## 8. SISTEMA DE OBJEÇÕES

| Objeção | Como responder |
|---|---|
| Preço | Reforçar valor de território e exclusividade (Capítulo 6); nunca reduzir preço sem processo formal (Capítulo 13). |
| Público/audiência ainda pequena | Honestidade direta: "não vendemos alcance de massa hoje — vendemos propriedade antecipada de um território que está crescendo", coerente com o valor de honestidade competitiva. |
| Retorno incerto | Apresentar indicadores híbridos (Capítulo 6) e casos de referência já avaliados (Capítulo 16). |
| Falta de exclusividade disponível | Explicar objetivamente as regras de categoria do Projeto 05, Capítulo 6 — nunca prometer exclusividade não aprovada para contornar a objeção. |
| Processo de aprovação "muito lento" | Explicar que o mesmo processo que parece lento é o que protege o próprio patrocinador de uma associação de marca instável (reformular a objeção como benefício real). |
| Concorrência com outro evento/patrocínio | Nunca comparar de forma depreciativa com outras propriedades esportivas (mesma regra de território proibido do Projeto 03) — a resposta foca no que este campeonato oferece, não no que os outros não oferecem. |
| Crise econômica / falta de orçamento | Oferecer nível de entrada compatível (Bronze/Apoiador) — nunca comprometer regras estruturais por desconto informal fora de processo. |

**Como nunca responder:** nunca prometendo algo fora do inventário aprovado (Capítulo 10); nunca inflando números para vencer uma objeção; nunca contornando o checklist ético (Projeto 05, Capítulo 14) para fechar uma venda sob pressão.

---

## 9. SISTEMA DE MATERIAIS COMERCIAIS

*(Este capítulo define a função de cada material — não cria seu conteúdo.)*

- **Sponsor Deck:** apresentação institucional completa, usada em reuniões formais — contém a narrativa do Capítulo 7 em profundidade.
- **One Page:** resumo executivo de uma página, usado em prospecção fria ou follow-up rápido.
- **Media Kit:** dados de comunidade e ativos visuais oficiais (extraídos do Brand Book, Projeto 04), usado por equipes de marketing do patrocinador.
- **PDF institucional:** versão formal e arquivável da apresentação, para envio por e-mail ou registro em processos internos do patrocinador.
- **Resumo executivo:** versão curta orientada a decisores de alto nível, com foco em território e legado (Capítulo 6), não em detalhe operacional.
- **Proposta:** documento comercial estruturado conforme Capítulo 12.
- **FAQ comercial:** respostas padronizadas às objeções mais comuns (Capítulo 8), disponível para consulta rápida da equipe.
- **Portfólio/casos de referência:** histórico de patrocinadores anteriores e seus resultados (quando disponível), sempre com consentimento do patrocinador citado.
- **Ficha técnica:** especificações objetivas de cada nível (Projeto 05, Capítulo 2), ativos incluídos, prazos e condições — material de apoio técnico à negociação, não peça de sedução comercial.

---

## 10. SISTEMA DE INVENTÁRIO COMERCIAL

Todos os ativos comercializáveis derivam diretamente da matriz de exposição do Projeto 05, Capítulo 5: espaços físicos de evento (arena, backdrop, painéis), mídias institucionais (redes sociais, site, aplicativo), presença em eventos (principal e paralelos, Fase 5), lives/streaming, hospitalidade/área VIP, networking institucional, conteúdo de marca (branded content dentro das regras do Sistema de Comunicação), experiências e ativações (Projeto 05, Capítulo 8).

**Princípio inegociável do inventário:** os elementos rituais protegidos (Chamada do Nome, Livro de Nomes, Última Respiração, Cerimônia de Reconhecimento, medalhas/certificados) **nunca fazem parte do inventário comercializável**, independentemente de demanda ou valor ofertado — esta regra vem diretamente do Projeto 05 e não pode ser reinterpretada pela equipe comercial sob nenhuma circunstância.

---

## 11. SISTEMA DE BENEFÍCIOS

**Como montar benefícios:** sempre a partir do inventário aprovado (Capítulo 10), organizados por nível conforme a matriz já definida no Projeto 05.

**Benefícios por nível:** seguem estritamente a matriz de exposição e contrapartidas do Projeto 05 (Capítulos 5 e 7) — a equipe comercial nunca cria benefícios novos fora dessa estrutura sem aprovação da Governança de Marca.

**Benefícios exclusivos:** disponíveis apenas nos níveis com exclusividade de categoria (Master/Ouro), conforme regras já definidas.

**Benefícios recorrentes:** aplicáveis a contratos multianuais, como prioridade de renovação e reconhecimento de "guardião fundador" (Capítulo 6).

**Benefícios personalizados:** possíveis apenas na forma de entrega dentro do inventário já aprovado (ex: escolha de qual ativação específica realizar), nunca na criação de um novo tipo de direito não previsto no Sistema de Patrocínios.

---

## 12. SISTEMA DE PROPOSTAS

**Como estruturar:** toda proposta segue uma base institucional fixa (contexto, território de marca, nível proposto, inventário incluído, contrapartidas, prazo) — a estrutura nunca muda de patrocinador para patrocinador.

**Como adaptar:** apenas no nível de ênfase narrativa (qual parte do Sistema de Valor, Capítulo 6, é mais relevante para aquele decisor específico, conforme o diagnóstico do Capítulo 5).

**Como personalizar:** inserindo exemplos e linguagem específicos do setor do patrocinador dentro da estrutura fixa — nunca alterando cláusulas de proteção de marca ou regras de co-branding.

**Quando personalizar:** sempre no nível de comunicação e ênfase.
**Quando manter padrão rígido:** sempre nas cláusulas de proteção de marca, checklist ético e estrutura de aprovação — nenhuma exceção comercial altera essas camadas.

---

## 13. SISTEMA DE NEGOCIAÇÃO

**Concessões permitidas dentro da alçada comercial:** prazo de pagamento, forma específica de ativação dentro do inventário já aprovado, calendário de entrega de contrapartidas.

**Trocas e permutas:** produtos ou serviços aceitos como parte do investimento apenas mediante avaliação formal de valor equivalente pela Governança Comercial (Capítulo 19) — nunca acordada informalmente entre vendedor e patrocinador.

**Descontos:** exigem processo formal de aprovação (mesmo fluxo do Projeto 05, Capítulo 12) — nenhum vendedor tem autoridade para conceder desconto unilateralmente.

**Escalonamento:** previsto para contratos multianuais, com crescimento de investimento associado ao crescimento de indicadores do campeonato (Fase 6).

**Flexibilidade e limites:** flexibilidade é sempre possível na forma de entrega; nunca na estrutura de proteção de marca, no checklist ético ou nos elementos rituais protegidos.

**Autorizações:** qualquer concessão fora da alçada padrão da equipe comercial exige aprovação expressa da Governança de Marca antes de ser comunicada ao patrocinador.

---

## 14. SISTEMA DE RENOVAÇÃO

**Quando iniciar:** com antecedência mínima suficiente para permitir avaliação completa (Capítulo 16) antes do fim da vigência contratual — nunca na última semana do contrato.

**Como medir satisfação:** através do Sistema de Avaliação já definido no Projeto 05, Capítulo 13 (ROI institucional, ROI financeiro, impacto na marca, impacto na comunidade, satisfação declarada).

**Como apresentar resultados:** relatório formal combinando dado quantitativo e narrativa qualitativa real, conforme já estabelecido no Projeto 01, Capítulo 13.

**Como aumentar investimento (upsell):** sempre baseado em indicadores de crescimento real do campeonato e do relacionamento, nunca por pressão comercial genérica.

**Como reduzir churn:** através de entrega consistente da promessa contratual e de comunicação contínua com o patrocinador fora da janela de renovação — não apenas contato quando há algo a vender.

---

## 15. SISTEMA DE CRM

**Pipeline:** espelha exatamente as etapas da Jornada Comercial (Capítulo 2).

**Status por etapa:** cada oportunidade comercial possui status objetivo (ex: "em qualificação", "proposta enviada", "aguardando aprovação da Governança", "fechado", "renovação em andamento").

**Campos mínimos obrigatórios:** nome da empresa, fit com ICP (Capítulo 3), estágio atual, responsável designado, histórico completo de contato, nível de interesse declarado, resultado do checklist ético quando aplicável.

**Histórico:** toda interação relevante é registrada — nenhuma negociação relevante acontece "fora do sistema".

**Indicadores:** conforme Capítulo 16, extraídos diretamente do CRM.

**Automações:** lembretes de follow-up, alertas de proximidade de renovação, notificação automática à Governança quando uma oportunidade atinge etapa que exige aprovação formal.

**Responsabilidades:** cada oportunidade tem um responsável único e claramente identificado — nunca corresponsabilidade difusa.

---

## 16. SISTEMA DE INDICADORES

- **Taxa de conversão por etapa do funil** — mede eficiência da jornada comercial (Capítulo 2).
- **Tempo médio de negociação** — do primeiro contato ao fechamento.
- **Taxa de renovação** — já indicador oficial desde a Fase 6, aqui detalhado a nível comercial.
- **Ticket médio** — por nível e por segmento (Capítulo 4).
- **Lifetime Value (LTV)** — valor total de um patrocinador ao longo de múltiplos ciclos de renovação.
- **CAC comercial** — custo de aquisição de cada novo patrocinador, incluindo tempo da equipe comercial.
- **ROI para o campeonato** — retorno gerado pelo investimento comercial em relação à receita captada.
- **Receita recorrente** — proporção da receita total vinda de contratos renovados/multianuais versus contratos novos — indicador direto de solidez de longo prazo, coerente com a lógica de "trajetória contínua" da marca.

---

## 17. SISTEMA DE DOCUMENTAÇÃO

**Templates:** existência formal de modelos para proposta, ata de reunião e relatório de renovação — este documento define que devem existir, sem criá-los aqui.

**Versionamento:** segue a mesma lógica de nomenclatura já definida no Projeto 04, Capítulo 17 — nenhum documento comercial relevante é sobrescrito sem preservar a versão anterior.

**Registro de reuniões:** ata mínima obrigatória para qualquer reunião de negociação relevante, arquivada no CRM.

**Registro de propostas:** toda proposta enviada é arquivada integralmente, mesmo as não aceitas — histórico de precificação e condições ofertadas é ativo institucional.

**Registro de decisões:** aprovações, recusas e exceções (especialmente recusas éticas, Projeto 05, Capítulo 14) são sempre documentadas formalmente, nunca decididas apenas verbalmente.

**Histórico centralizado:** o CRM (Capítulo 15) é a fonte única de verdade — nenhum registro comercial relevante existe apenas em e-mail pessoal ou anotação informal.

---

## 18. CHECKLIST COMERCIAL

- **Checklist da prospecção:** empresa corresponde ao ICP (Capítulo 3)? Não consta na lista de recusa (Projeto 05, Capítulo 14)?
- **Checklist da reunião:** material institucional utilizado está na versão mais atual (Capítulo 17)? Diagnóstico (Capítulo 5) foi conduzido antes da apresentação de valor?
- **Checklist da proposta:** estrutura padrão respeitada (Capítulo 12)? Inventário ofertado está dentro do aprovado (Capítulo 10)?
- **Checklist da negociação:** nenhuma concessão fora da alçada comercial (Capítulo 13) foi prometida sem aprovação?
- **Checklist do fechamento:** aprovação formal da Governança de Marca obtida antes de qualquer assinatura (Projeto 05, Capítulo 12)?
- **Checklist do onboarding:** Brand Book (Projeto 04) entregue e explicado? Regras de co-branding (Projeto 05, Capítulo 4) formalmente comunicadas?
- **Checklist da renovação:** avaliação completa (Capítulo 16, Projeto 05 Capítulo 13) revisada antes de qualquer nova proposta ser construída?

---

## 19. GOVERNANÇA COMERCIAL

**Quem vende:** equipe comercial formalmente designada, liderada pelo Diretor Comercial (Fase 6).
**Quem aprova:** Governança de Marca (poder de veto) e Diretor Executivo (aprovação final), exatamente conforme já estabelecido no Projeto 05, Capítulo 12 — este documento não cria uma segunda instância de aprovação, apenas reforça o mesmo fluxo já constitucional.
**Quem negocia:** equipe comercial, dentro dos limites do Capítulo 13; qualquer exceção sobe formalmente.
**Quem concede exceções:** exclusivamente a Governança de Marca.
**Quem altera este sistema:** Governança de Marca, com o Diretor Comercial como responsável técnico de operação (não de alteração de regra).
**Como registrar mudanças:** changelog formal e versionado, seguindo a mesma lógica documental já padronizada desde o Projeto 04.

---

## 20. ROADMAP DE IMPLEMENTAÇÃO

**Prioridade 1 (pré-requisito para qualquer prospecção séria):** CRM básico operacional (Capítulo 15) · checklist de qualificação (Capítulo 18) · versão mínima viável do Sponsor Deck e do One Page (Capítulo 9).

**Prioridade 2:** Media Kit completo · sistema de propostas modular plenamente estruturado (Capítulo 12) · treinamento formal da equipe comercial no Sistema de Objeções (Capítulo 8) e na Filosofia Comercial (Capítulo 1).

**Prioridade 3:** automações avançadas de CRM · sistema de indicadores plenamente instrumentado (Capítulo 16) · playbook maduro de renovação (Capítulo 14), construído a partir de casos reais acumulados.

**Dependências:** nenhuma etapa comercial real pode iniciar antes de o Brand Book (Projeto 04) e o Sistema de Patrocínios (Projeto 05) estarem formalmente aprovados — pré-requisito já cumprido neste ponto do projeto.

**Ferramentas:** escolha de plataforma de CRM compatível com o orçamento definido nos cenários da Fase 6; templates de documento desenvolvidos como extensão do Sistema Editorial (Projeto 04, Capítulo 9).

**Equipe necessária:** mínimo de um Diretor Comercial e um executivo de contas nos primeiros anos, coerente com a estrutura organizacional mínima já definida na Fase 6.

---

## AUDITORIA FINAL — CONSELHO DE ONZE ESPECIALISTAS (CICLO ITERATIVO)

### Rodada 1 — críticas técnicas

**Marketing Esportivo:** "O Sistema de Storytelling Comercial (Capítulo 7) é coerente com toda a construção narrativa das fases anteriores — é raro ver um manual comercial que não abandona a identidade de marca assim que chega a hora de vender. Nenhuma inconsistência estrutural."

**Patrocínio:** "A regra de que elementos rituais nunca entram no inventário comercial (Capítulo 10), reafirmada aqui mesmo sob pressão de venda, é o ponto mais importante do documento para proteger o valor de longo prazo da marca."

**Vendas Consultivas:** "O Sistema de Descoberta (Capítulo 5) está bem estruturado, mas falta um critério objetivo de pontuação de qualificação (lead scoring) — hoje as perguntas existem, mas não há forma de comparar objetivamente duas oportunidades em estágios diferentes de maturidade."

**Branding:** "A separação clara entre 'o que pode ser personalizado' e 'o que nunca pode ser personalizado' em propostas (Capítulo 12) é exatamente o que protege a marca de degradar-se sob pressão comercial individual, reunião após reunião."

**Business Development:** "O ICP (Capítulo 3) e as Personas (Capítulo 4) estão bem definidos, mas falta orientação sobre como priorizar prospecção entre múltiplos segmentos simultâneos — hoje todos os segmentos parecem ter peso igual."

**CRM:** "O Sistema de CRM (Capítulo 15) está bem desenhado em princípio, mas não define claramente o que acontece com uma oportunidade que fica parada em um estágio por tempo excessivo — falta uma regra de 'higienização de pipeline'."

**Growth:** "Gostaria de ver uma conexão mais explícita entre o Sistema de Indicadores comercial (Capítulo 16) e os KPIs de marca já definidos na Fase 6 — hoje eles existem em documentos separados sem ponte formal."

**Finanças:** "O Sistema de Negociação (Capítulo 13) corretamente exige aprovação formal para descontos e permutas — recomendo que fique explícito um teto percentual de desconto que a Governança normalmente considera antes de escalar para negociação excepcional, para agilizar decisões recorrentes de menor porte."

**Relações Institucionais:** "O tratamento diferenciado de universidades e órgãos públicos como Parceiros, não como patrocinadores comerciais tradicionais (Capítulo 4), está coerente com a Fase 5. Nenhuma inconsistência."

**Comunicação Corporativa:** "O Sistema de Materiais Comerciais (Capítulo 9) está bem descrito em função, mas seria útil indicar qual material é apropriado para qual etapa da Jornada Comercial (Capítulo 2), hoje essa relação fica implícita."

**Gestão Comercial:** "O Roadmap de Implementação (Capítulo 20) está bem priorizado. Ponto de atenção: falta menção a como a equipe comercial deve lidar com propostas que ultrapassam sua alçada em múltiplas frentes ao mesmo tempo (ex: desconto + prazo + benefício personalizado simultâneos) — hoje cada exceção é tratada isoladamente."

### Ajustes incorporados após a Rodada 1

- **Capítulo 5** passa a prever um critério objetivo de pontuação de qualificação (lead scoring), combinando fit de ICP, maturidade de decisão e alinhamento de valores, a ser formalizado operacionalmente na primeira implementação do CRM.
- **Capítulo 3** passa a indicar que a priorização entre segmentos de prospecção deve ser revisada periodicamente pela Governança Comercial, conforme o momento estratégico do campeonato (ex: priorizar Fornecedores Oficiais na Fundação, Master/Ouro na Consolidação, conforme a lógica de fases da Fase 6).
- **Capítulo 15** passa a prever uma regra de higienização de pipeline: oportunidades sem movimentação por período definido (a ser fixado operacionalmente) são sinalizadas automaticamente para revisão ou encerramento formal.
- **Capítulo 16** passa a determinar explicitamente que os indicadores comerciais devem ser reportados em conjunto com os KPIs de marca da Fase 6 no mesmo ritual de governança (reunião mensal de diretoria, Fase 6, Capítulo 11), não em relatórios paralelos desconectados.
- **Capítulo 13** passa a prever que a Governança de Marca pode pré-autorizar uma faixa percentual de desconto padrão para agilizar decisões recorrentes de menor porte, reservando o processo de aprovação plena para exceções acima dessa faixa.
- **Capítulo 9** passa a incluir uma tabela de referência associando cada material comercial à etapa correspondente da Jornada Comercial (Capítulo 2).
- **Capítulo 13** passa a esclarecer que exceções múltiplas e simultâneas (desconto + prazo + benefício personalizado, por exemplo) são sempre tratadas como um único pacote de exceção, submetido de uma vez à Governança, nunca aprovadas fragmentadamente.

### Rodada 2 — segunda leitura crítica após ajustes

**Vendas Consultivas:** "O lead scoring formalizado como pendência de implementação resolve minha objeção — não era necessário definir a fórmula exata aqui, apenas garantir que o critério existirá."

**CRM e Gestão Comercial (avaliação conjunta):** "A regra de higienização de pipeline e o tratamento de exceções múltiplas como pacote único resolvem nossos pontos. O sistema está pronto para operação real."

**Growth e Finanças (avaliação conjunta):** "A integração formal entre indicadores comerciais e KPIs de marca, e a pré-autorização de faixa de desconto padrão, resolvem as lacunas que apontamos. Nenhuma nova inconsistência identificada."

**Consolidação final:** a segunda rodada não identificou nenhuma inconsistência estrutural relevante remanescente. As pendências restantes (fórmula exata de lead scoring, prazo específico de higienização de pipeline, percentual exato de desconto pré-autorizado) são, corretamente, parâmetros operacionais a serem calibrados na primeira implementação prática, não decisões estruturais em aberto — e estão formalmente registradas como tal neste documento. O ciclo iterativo é encerrado nesta rodada.

---

*Fim do Projeto 06 — Manual Comercial e Sistema de Vendas. Documento oficial, fundamentado nas Fases 1-6 e nos Projetos 01-05, servindo como Manual Comercial permanente do Campeonato Brasileiro de Kettlebell Sport.*
